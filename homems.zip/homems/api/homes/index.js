import http from '@/global/utils/http.js'

// 用户登录
export const userlogin = (data) => {
  return http.httpRequest({
    url: 'api/login/',
    method: 'post',
  },data)
}
// 用户注册
export const userreg = (data) => {
  return http.httpRequest({
    url: 'api/regist/',
    method: 'post',
  },data)
}

//获取房源信息列表
export const gethouselist = (data) => {
  return http.httpRequest({
    url: 'api/list_houses/' ,
    method: 'get',
  },data)
}

//获取首页房屋信息列表
export const gethomehouselist = () => {
  return http.httpRequest({
    url: 'api/list_all_houses/' ,
    method: 'get',
  })
}


//发送验证码
export const sencode = (data) => {
  return http.httpRequest({
    url: 'api/code/' ,
    method: 'get',
  },data)
}

//查询收藏房屋的信息
export const collection = (data) => {
  return http.httpRequest({
    url: 'api/get_collection/' ,
    method: 'get',
  },data)
}

//收藏房屋
export const likehouseinfo = (data) => {
  return http.httpRequest({
    url: 'api/insert_collection/' ,
    method: 'post',
  },data)
}

//查询房屋的详情信息
export const housedetail = (data) => {
  return http.httpRequest({
    url: 'api/detail/' ,
    method: 'get',
  },data)
}

//获取首页轮播图
export const allslide = () => {
  return http.httpRequest({
    url: 'api/slide/' ,
    method: 'get',
  })
}


//普通用户升级为会员用户
export const become_superuser = (data) => {
  return http.httpRequest({
    url: 'api/become_superuser/' ,
    method: 'post',
  },data)
}

//用户修改密码
export const modify_password = (data) => {
  return http.httpRequest({
    url: 'api/modify_password/' ,
    method: 'post',
  },data)
}

//用户注销
export const login_out = (data) => {
  return http.httpRequest({
    url: 'api/login_out/' ,
    method: 'get',
  },data)
}

//关于我们
export const about_pandas = (data) => {
  return http.httpRequest({
    url: 'api/about_pandas/' ,
    method: 'get',
  },data)
}

//查看房屋交易记录
export const traderecord = (data) => {
  return http.httpRequest({
    url: 'api/traderecord/' ,
    method: 'get',
  },data)
}

//添加订单
export const postaddorder = (data) => {
  return http.httpRequest({
    url: 'api/add_order/' ,
    method: 'post',
  },data)
}

//删除订单
export const postdelorder = (data) => {
  return http.httpRequest({
    url: 'api/del_order/' ,
    method: 'post',
  },data)
}

//查看订单
export const get_order = (data) => {
  return http.httpRequest({
    url: 'api/get_order/' ,
    method: 'get',
  },data)
}

//查看代金券
export const cash = (data) => {
  return http.httpRequest({
    url: 'api/cash/' ,
    method: 'get',
  },data)
}
//获取用户个人信息
export const user_info = (data) => {
  return http.httpRequest({
    url: 'api/user_info/' ,
    method: 'get',
  },data)
}

//
export const add_house = (data) => {
  return http.httpTokenRequest({
    url: 'api/add/' ,
    method: 'post',
  },data)
}

