<template>
	<view>
		<block v-for="(item,index) in list_data" :key="index" >
			<view class="bg-white margin-top padding radius zaiui-trends">
				<!--用户信息-->
				<view class="cu-list menu-avatar" @click="showdetail(item,index)">
					<view class="cu-item">
						<view class="cu-avatar round" :style="[{backgroundImage:'url('+ item.house.image +')'}]" />
						<view class="content" >
							<view class="text-black">
								<view class="text-cut">{{$store.state.userName}}</view>
							</view>
							<view class="text-sm flex">
								<text>{{getdate(item.house.publish_time)}}</text>
							</view>
						</view>
						<view class="action">
							<button class="cu-btn sm bg-red"  >
								<text >已关注</text>
							</button>
						</view>
					</view>
				</view>
				
				<!--内容-->
				<view class="margin-tb text-black zaiui-text-content" >
					<text v-html="item.house.description">{{item.house.description}}</text>
					
				</view>
				
				<view class="zaiui-img-grid-col" @click="showdetail(item,index)">
					<!--单图-->
					<view class="one-img" >
						<view class="img-grid" :style="[{backgroundImage:'url('+ item.house.image +')'}]"/>
					</view>
					
	
				</view>
				
				<!--话题-->
				<view class="cu-tag light bg-red round margin-top" v-if="item.house.type" @click="showdetail(item,index)" >
					<text class="cuIcon-creativefill"></text>
					<text class="margin-left-xs">{{item.house.type}}</text>
				</view>
				
				<!--操作-->
				<!-- <view class="flex p-xs zaiui-footer-tool">
					
					<view class="flex-twice text-right">
						<button class="cu-btn sm bg-blue"  @tap="listTap('followTap',item,index)" >
							<text >查看</text>
						</button>
						
					</view>
				</view> -->
			</view>
		</block>
	</view>
</template>

<script>
	import videoRender from '@/components/zaiui-common/basics/video-render';
	import _tool from '@/static/zaiui/util/tools.js';
	import { formateDate } from '@/global/utils/utils.js';
	
	export default {
		name: 'trends-list',
		components: {
			videoRender
		},
		props: {
			list_data: {
				type: Array,
				default: () => {
					return []
				}
			},
			isMin: {
				type: Number,
				default: 0
			},
			isMax: {
				type: Number,
				default: 0
			},
			viewBtn: {
				type: Boolean,
				default: false
			}
		},
		created(){
			console.log(this.$store.state.userName);
		},
		methods: {
			showdetail(data,index){
				this.$store.state.selshopid = data.house_id;
				uni.navigateTo({
					url: "/pages/goods/goods"
				})
			},
			getdate(time){
				return formateDate(new Date(time), 'Y-M-D h:min:s');;
			},
			listTap(tap,data,index) {
				this.$emit(tap, {
					data,
					index
				});
			},
			imgTap(img,arr,index) {
				this.$emit('imgTap', {
					img,
					arr,
					index
				});
			},
			
			videoErrorCallback(e) {
				uni.showToast({
				    title: e.target.errMsg,
				    duration: 2000,
					icon: 'none'
				});
			}
		}
	}
</script>

<style lang="scss" scoped>
	.zaiui-trends {
		border-radius: 18.18rpx;
		.cu-list {
			.cu-item {
				padding-right: 0;
				height: 99.99rpx;
				.cu-avatar {
					left: 0;
					width: 81.81rpx;
					height: 81.81rpx;
				}
				.content {
					left: 99.99rpx;
					line-height: 1.5em;
				}
				.action {
					width: 154.54rpx;
					text-align: right;
					.cu-btn {
						&:after {
							border-radius: 18.18rpx;
						}
						.cuIcon-add {
							font-size: 27.27rpx;
						}
					}
				}
				&:after {
				    width: 0;
				    height: 0;
					border-bottom: 0;
				}
			}
		}
		.zaiui-text-content {
			line-height: 1.6;
			.cuIcon-right {
				position: relative;
				top: 1rpx;
			}
		}
		.zaiui-video-box {
			position: relative;
			width: 100%;
			.video-view {
				width: 100%;
				height: 363.63rpx;
				z-index: 0;
			}
		}
		.zaiui-img-grid-col {
			position: relative;
			width: 100%;
			.one-img {
				position: relative;
				.img-grid {
					width: 100%;
					height: 363.63rpx;
					border-radius: 9.09rpx;
					background-size: cover;
					background-position: center;
					background-repeat: no-repeat;
				}
			}
			.col-2 {
				.img-grid-view {
					padding: 5.45rpx;
					.img-grid {
					    position: relative;
					    width: 309.09rpx;
						height: 218.18rpx;
					    background-size: cover;
					    background-position: center;
					    border-radius: 9.09rpx;
					}
				}
			}
			.col-3 {
				.img-grid-view {
					padding: 5.45rpx;
					.img-grid {
					    position: relative;
					    width: 204.79rpx;
					    height: 204.79rpx;
					    background-size: cover;
					    background-position: center;
					    border-radius: 9.09rpx;
					}
				}
			}
		}
		.zaiui-footer-tool {
			margin: 40rpx 0 18.18rpx;
			.margin-right-lg {
			    margin-right: 94.54rpx;
			}
			.icon {
			    position: relative;
				font-size: 36.36rpx;
			    top: 4rpx;	
			}
		}
	}
</style>
