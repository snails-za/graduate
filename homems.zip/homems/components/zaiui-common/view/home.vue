<template>
	<view class="zaiui-home-box" :class="show?'show':''">
		
		
		
		<!--轮播图-->
		<view class="bg-white zaiui-swiper-box">
			<swiper class="screen-swiper square-dot c" autoplay circular indicator-dots :current="swiperIndex"  @change="swiperChange">
				<swiper-item v-for="(item,index) in swiperList" :key="index" @click="showdetail(item,index)">
					<view >
						<image :src="item.house.image" mode="widthFix"  />
					</view>
				</swiper-item>
			</swiper>
		</view>
		
		
		
		<!--商品列表-->
		<view class="bg-white margin-top padding-bottom-sm padding-top-sm zaiui-goods-list-view-box">
			<view class="cu-bar bg-white search " >
				<view class="search-form round">
					<text class="cuIcon-search"></text>
					<input type="text" placeholder="搜索房子" confirm-type="search" @input="searchIcon"></input>
				</view>
			</view>
			<!--商品列表1-->
			<goods-sort-list :list_data="goodsSortListData" @listTap="goodsSortListTap" :show="TabCur==0?true:false"></goods-sort-list>
			<!--商品列表2-->
			<goods-sort-list :list_data="goodsSortListData" @listTap="goodsSortListTap" :show="TabCur==1?true:false"></goods-sort-list>
		</view>
		
		<!--加号按钮-->
		<!-- <view class="zaiui-footer-fixed zaiui-add-btn-view-box">
			<button class="cu-btn cuIcon-add bg-red"/>
		</view> -->
		
			<!--占位底部距离-->
			<view class="cu-tabbar-height"/>
		</view>
		
	</view>
</template>

<script>
	import barSearchTitle from '@/components/zaiui-common/basics/bar-search-title';
	import goodsSortList from '@/components/zaiui-common/list/goods-sort-list';
	
	import _tool from '@/static/zaiui/util/tools.js';	//工具函数
	
	import { gethouselist,allslide,gethomehouselist,user_info } from '@/api/homes/index.js';
	
	export default {
		name: 'home',
		components: { 
			  barSearchTitle, goodsSortList
		},
		data() {
			return {
				CustomBar:40,
				 headInfo: {Class: "", opacity: 0,}, 
				headTab: {TabCur: 0, scrollLeft: 0, list: []}, 
				swiperIndex: 0, swiperList: [], gridRoundList: [], gridSmList: [], goodsTab: ['推荐','官方自营'], TabCur: 0, goodsSortListData: [],
			}
		},
		created() {
			this.getallslide();
			this.houselistdata();
			this.getuserinfo();
			
		},
		props: {
			show: {
				type: Boolean,
				default: true
			},
			scrollY: {
				type: Number,
				default: 0
			},
			scrollBottom: {
				type: Number,
				default: 0
			}
		},
		watch: {
			scrollY() {
				this.setPageScroll(this.scrollY);
			},
			scrollBottom() {
				if(this.scrollBottom != 0) {
					this.setReachBottom();
				}
			},
		},
	
		mounted() {
			uni.pageScrollTo({
			    scrollTop: 0,
			    duration: 0
			});
			
		},
		methods: {
			showdetail(data,index){
				// console.log(data);
				this.$store.state.selshopid = data.house_id;
				this.$store.state.houseimg = data.house.image;
				uni.navigateTo({
					url: "/pages/goods/goods"
				})
			},
			getallslide(){
				allslide().then(res=>{
					if(res==undefined){
						this.getallslide();
					}
					if(res.data.state==0){
						this.swiperList=res.data.data;
						console.log(this.swiperList);
					}
				});
			},
			getuserinfo(){
				const token = uni.getStorageSync('token');
				var params={token:token};
				user_info(params).then(res=>{
					if(res==undefined){
						this.getuserinfo();
					}
					if(res.data.state==0){
						uni.setStorageSync('useridnumber', res.data.data.identity_number);
						uni.setStorageSync('username', res.data.data.name);
						uni.setStorageSync('ismember', res.data.data.is_member);
						uni.setStorageSync('sex', res.data.data.sex);
						this.$store.state.userName = res.data.data.name;
					}
				});
			},
			houselistdata(){

				
				gethomehouselist().then(res=>{
					if(res==undefined){
						this.houselistdata();
					}
					if(res.data.state==0){
						
						this.goodsSortListData=res.data.data;
						console.log(this.goodsSortListData);
					}
				});
			},
			//页面被滚动
			setPageScroll(scrollTop) {
				//console.log(scrollTop);
				if(this.headTab.TabCur == 0) {
					if(scrollTop <= 100) {
						let num = scrollTop / 100;
						this.headInfo.opacity = num;
					} else if(scrollTop > 100) {
						this.headInfo.opacity = 1;
					}
				}
			},
			//触底了
			setReachBottom() {
				console.log('触底了');
			},
			swiperChange(e) {
				this.swiperIndex = e.detail.current;
			},
			tabSelect(e) {
				this.TabCur = e.currentTarget.dataset.id;
			},
			goodsSortListTap(e) {
				console.log(e);
			},
			searchTap() {
				uni.navigateTo({
					url: "/pages/home/search"
				});
			}
			
		}
	}
</script>

<style lang="scss" scoped>
	.zaiui-head-search-box {
		position: fixed;
		width: 100%;
		top: 0;
		z-index: 9999;
		background-color: rgba(229, 77, 66,0);
		padding-top: var(--status-bar-height);
		transition: top .25s;
		padding-bottom: 10rpx;
		.zaiui-search-box {
			position: relative;
		}
		.zaiui-flex-tab {
			position: relative;
			transition: opacity .25s;
			.flex {
				.basis-xxl {
					flex-basis: 90%;
					width: 90%;
					z-index: 1;
				}
				.basis-xxs {
					flex-basis: 10%;
					z-index: 1;
					width: 10%;
				}
				.sort-icon {
					font-size: 55rpx;
					height: 64rpx;
					line-height: 64rpx;
					text-align: center;
				}
			}
		}
	}
	.zaiui-head-search-box.welcome {
		top: calc(var(--status-bar-height) + 101rpx);
		transition: top .25s;
	}
	.zaiui-view-content {
		display: none;
		width: 100%;
		
		/* #ifdef APP-PLUS */
		margin-top: calc(var(--status-bar-height) + 30rpx);
		/* #endif */
		
		/* #ifdef H5 */
		margin-top: calc(var(--status-bar-height) + 70rpx);
		/* #endif */
		
		/* #ifdef MP */
		margin-top: calc(var(--status-bar-height) + 85rpx);
		/* #endif */
		
		.zaiui-tab-list {
			position: relative;
			width: 100%;
		}
	}
	.zaiui-view-content.welcome {
		/* #ifdef APP-PLUS */
		margin-top: calc(var(--status-bar-height) + 180rpx);
		/* #endif */
		
		/* #ifdef H5 */
		margin-top: calc(var(--status-bar-height) + 220rpx);
		/* #endif */
		
		/* #ifdef MP */
		margin-top: calc(var(--status-bar-height) + 220rpx);
		/* #endif */
		
		transition: all .25s;
	}
	.zaiui-view-content.show {
		display: block;
	}
	.zaiui-swiper-box {
		width: 100%;
		.screen-swiper {
			height: 230rpx;
			min-height: 230rpx;
			.swiper-padding {
				padding: 0 25rpx;
			}
		}
	}
	.red-envelopes {
		width: 100%;
	}
	.zaiui-goods-tab-box {
		position: sticky;
		padding: 2rpx 0;
		transition: all .25s;
		z-index: 9999;
		background: #fff;
		
		/* #ifndef MP */
		top: calc(var(--status-bar-height) + 101rpx);
		/* #endif */
		
		/* #ifdef MP */
		top: calc(var(--status-bar-height) + 161rpx);
		/* #endif */
		
		.cu-tag.z {
			top: 0px;
			right: -32.72rpx;
			font-size: 20rpx;
			padding: 19rpx 6rpx;
			transform: scale(0.8);
		}
	}
	.zaiui-ad-img {
		width: 100%;
	}
	.zaiui-tab-list-title {
		.img-aau {
			width: 101.81rpx;
			margin-top: 12.72rpx;
		}
		.text-right {
			.img-aau {
				margin-right: 14.54rpx;
			}
		}
		.text-left {
			.img-aau {
				margin-left: 14.54rpx;
			}
		}
	}
	.zaiui-add-btn-view-box {
		position: fixed;
		z-index: 999999;
		bottom: 181.81rpx;
		right: 27.27rpx;
		.cu-btn {
			margin: auto;
			width: 81.81rpx;
			height: 81.81rpx;
			font-weight: 800;
			border-radius: 50%;
			font-size: 36.36rpx;
			border: 9.09rpx solid #fff;
			box-shadow: 0 0 14.54rpx 7.27rpx #d0d0d0;
		}
	}
	.zaiui-home-box {
		display: none;
	}
	.zaiui-home-box.show {
		display: block;
	}
</style>