<template>
	<view class="zaiui-my-box show" >
		<view class="bg-gradual-red zaiui-head-box">
			<!--标题栏-->
			<!--小程序端不显示-->
			<!-- #ifndef MP -->
			<bar-title :isBack="false" :fixed="false">
				<block slot="right">
					<text class="cuIcon-settings" @tap="setupTap"/>
				</block>
			</bar-title>
			<!-- #endif -->
			
			<!--用户信息-->
			<view class="zaiui-user-info-box">
				<!--未登陆-->
				<view class="login-user-view" v-if="login">
					<view class="login-user-avatar-view">
						<view class="cu-avatar round lg" style="background-image:url(/static/images/avatar/1.jpg);"/>
					</view>
					<button class="cu-btn sm radius" @tap="loginUrlTap">立即登录</button>
				</view>
				
				<!--已登陆-->
				<view class="cu-list menu-avatar" v-else>
					<view class="cu-item">
						<view class="cu-avatar round lg" :style="'background-image:url('+userimg+')'"/>
						<view class="content text-xl">
							<view class="text-white">
								<text class="margin-right">{{username}}</text>
								<text class="text-sm" @tap="loginTap">切换未登陆页面</text>
							</view>
							<view class="text-white-bg text-sm">
								<text class="text-border-x">湖南 </text>
								<text>长沙</text>
							</view>
						</view>
					</view>
				</view>
			</view>
			
			<!--用户数据-->
			<view class="zaiui-user-info-num-box">
				<view class="cu-list grid col-4 no-border">
					<view class="cu-item" >
						<view class="text-xl" v-if="login">-</view>
						<view class="text-xl" v-else>{{total1}}</view>
						<text class="text-sm">房源</text>
					</view>
					<view class="cu-item" >
						<view class="text-xl" v-if="login">-</view>
						<view class="text-xl" v-else>{{total2}}</view>
						<text class="text-sm">收藏</text>
					</view>
					<view class="cu-item" >
						<view class="text-xl" v-if="login">-</view>
						<view class="text-xl" v-else>{{total3}}</view>
						<text class="text-sm">代金卷</text>
					</view>
					<view class="cu-item">
						<view class="text-xl" v-if="login">-</view>
						<view class="text-xl" v-else>{{total4}}</view>
						<text class="text-sm">订单</text>
					</view>
				</view>
			</view>
			
			<!--用户提示-->
			<view class="text-sm zaiui-user-info-tip-box"  @tap="realNameTap" v-if="ismember==0">
				<view class="text-cut">偷偷告诉你，升级为房东可以获得更多权限~</view>
				<text class="cuIcon-right icon"/>
			</view>	
		</view>
		
		
		<view class="zaiui-view-content">
			
			
			<!--推荐工具-->
			<view class="padding-xs bg-white margin-top zaiui-user-info-tools-box">
				<view class="padding-sm tools-view">
					<view class="text-black text-bold text-lg tools-title">我的交易</view>
					
				</view>
				
				<view class="zaiui-tools-list-box">
					<view class="cu-list grid col-4 no-border">
						<block >
							<view class="cu-item" @tap="footmarkTap">
								<view class="text-black cuIcon-squarecheck" />
								<text>我的房源</text>
							</view>
						</block>
						<block >
							<view class="cu-item" @click="showlist('order')">
								<view class="text-black cuIcon-order" />
								<text>我的订单</text>
							</view>
						</block>
						<block >
							<view class="cu-item" @tap="sponsoredTap">
								<view class="text-black cuIcon-moneybag"/>
								<text>我的代金卷</text>
							</view>
						</block>
						<block >
							<view class="cu-item" @tap="about">
								<view class="text-black cuIcon-friend" />
								<text>关于我们</text>
							</view>
						</block>
					</view>
				</view>
				
			</view>
			
		</view>
		
		<!--占位底部距离-->
		<view class="cu-tabbar-height"></view>
	</view>
</template>

<script>
	import barTitle from '@/components/zaiui-common/basics/bar-title';
	
	import _tool from '@/static/zaiui/util/tools.js';	//工具函数
	import { gethouselist,get_order,cash,collection,user_info } from '@/api/homes/index.js';
	
	export default {
		name: 'my',
		components: { 
			barTitle
		},
		data() {
			return {
				toolsList: [], login: false,
				userimg:"",
				username:"",
				token:"",
				total1:0,
				total2:0,
				total3:0,
				total4:0,
				ismember:0
			}
		},
		props: {
			show: {
				type: Boolean,
				default: true
			},
			scrollY: {
				type: Number,
				default: 0
			},
			scrollBottom: {
				type: Number,
				default: 0
			}
		},
		watch: {
			scrollY() {
				//通知他妈的滚动了。
				this.setPageScroll(this.scrollY);
			},
			scrollBottom() {
				if(this.scrollBottom != 0) {
					//通知他妈的触底了
					this.setReachBottom();
				}
			},
		},
		created() {
			
			this.ismember = uni.getStorageSync('ismember');
			this.token = uni.getStorageSync('token');
			this.userimg = uni.getStorageSync('headimg');
			
			
			this.getnumber();
			this.housdata();
			this.cashdata();
			this.collectiondata();
			this.getuserinfo();
		},
		mounted() {
			_tool.setBarColor(false);
			uni.pageScrollTo({
			    scrollTop: 0,
			    duration: 0
			});
		},
		methods: {
			housdata(){
				var that=this;
				var params={token:this.token};
				gethouselist(params).then(res=>{
					if(res==undefined){
						that.housdata();
					}
					if(res.data.state==0){
						this.total1=res.data.data.length;
					}
				});
			},
			getuserinfo(){
				const token = uni.getStorageSync('token');
				var params={token:token};
				user_info(params).then(res=>{
					if(res==undefined){
						this.getuserinfo();
					}
					if(res.data.state==0){
						this.userimg=res.data.data.img;
						this.username=res.data.data.name;
						
						
					}
				});
			},
			cashdata(){
				var that=this;
				var params={token:this.token};
				cash(params).then(res=>{
					if(res==undefined){
						that.cashdata();
					}
					if(res.data.state==0){
						this.total3=res.data.data.length;
						console.log(3333);
					}
				})
			},
			collectiondata(){
				var that=this;
				var params={token:this.token};
				collection(params).then(res=>{
					if(res==undefined){
						that.collectiondata();
					}
					if(res.data.state==0){
						this.total2=res.data.data.length;
					}
				});
			},
			getnumber(){
				var that=this;
				var params2={token:this.token,status:2};
				get_order(params2).then(res=>{
					if(res==undefined){
						that.getnumber();
					}
					if(res.data.state==0){
						console.log(2222);
						this.total4=res.data.order.length;
					}
				});
			},
			about(){
				uni.navigateTo({
					url: "/pages/my/about"
				});
			},
			//页面被滚动
			setPageScroll(scrollTop) {
				//console.log(scrollTop);
			},
			//触底了
			setReachBottom() {
				// console.log('触底了');
			},
			showlist(){
				uni.navigateTo({
					url: "/pages/order/list"
				});
			},
			//购物车
			cartTap() {
				uni.navigateTo({
					url: "/pages/goods/my_cart"
				});
			},
			//足迹
			footmarkTap() {
				uni.navigateTo({
					url: "/pages/my/footmark"
				});
			},
			//我买到的
			order_list_tap() {
				uni.navigateTo({
					url: "/pages/order/list"
				});
			},
			loginUrlTap() {
				uni.navigateTo({
					url: "/pages/my/login"
				});
			},
			loginTap() {
				this.login = false;
				uni.navigateTo({
					url: "/pages/login/login"
				});
				
			},
			realNameTap() {
				uni.navigateTo({
					url: "/pages/real_name/index"
				});
			},
			setupTap() {
				uni.navigateTo({
					url: "/pages/my/set-up"
				});
			},
			gridTap(item) {
				if(item.name == '设置') {
					this.setupTap();
				}
			},
			sponsoredTap() {
				uni.navigateTo({
					url: "/pages/my/sponsored"
				});
			},
		}
	}
</script>

<style lang="scss" scoped>
	.zaiui-my-box {
		width: 100%;
		display: none;
		.zaiui-head-box {
			padding-top: 0;
			padding-bottom: 72.72rpx;
			.zaiui-user-info-box {
				/* #ifdef MP */
				padding-top: calc(var(--status-bar-height) + 50rpx);
				/* #endif */
				.login-user-view {
					position: relative;
					text-align: center;
					.login-user-avatar-view {
						position: relative;
						margin-bottom: 18.18rpx;
					}
				}
				.cu-list.menu-avatar>.cu-item {
					background-color: inherit;
					.content {
						width: calc(100% - 94.54rpx - 59.99rpx - 20rpx);
						.text-white-bg {
							color: #e8e8e8;
							.text-border-x {
								margin-right: 25.45rpx;
							    position: relative;
								&:after {
									position: absolute;
									background: #dddddd;
								    top: 5.45rpx;
								    width: 1.81rpx;
									right: -12.72rpx;
								    height: 16.36rpx;
								    content: " ";
								}
							}
						}
					}
					&:after {
						width: 0;
						height: 0;
						border-bottom: 0;
					}
				}
				.cu-list.menu-avatar>.cu-item .content>view:first-child {
					font-size: 34.54rpx;
				}
			}
			.zaiui-user-info-num-box {
				.cu-list.grid.no-border {
					padding: 0;
				}
				.cu-list.grid.no-border>.cu-item {
				    padding-top: 27.27rpx;
				    padding-bottom: 9.09rpx;
				}
				.cu-list.grid {
					background-color: inherit;
				}
				.cu-list.grid>.cu-item text {
					color: #e8e8e8;
					font-size: 20rpx;
					line-height: 27.27rpx;
				}
			}
			.zaiui-user-info-tip-box {
				position: relative;
				margin: 18.18rpx 27.27rpx;
				border-radius: 9.09rpx;
				padding: 18.18rpx 27.27rpx;
				background: #ea8d8d;
				background-image: linear-gradient(45deg, #f7615f, #f553b3);
				.text-cut {
					padding-right: 45.45rpx;
				}
				.icon {
					position: absolute;
					right: 27.27rpx;
					top: 23.63rpx;
				}
			}
		}
		.zaiui-view-content {
			padding: 0 27.27rpx 54.54rpx;
			margin-top: -63.63rpx;
			.zaiui-user-info-order-box {
				border-radius: 18.18rpx;
				.cu-list.grid.no-border {
				    padding: 0;
				}
				.cu-list.grid.no-border>.cu-item {
				    padding-bottom: 9.09rpx;
				}
			}
			.cu-list.grid>.cu-item text {
			    color: inherit;
			}
			.zaiui-user-info-money-box {
				border-radius: 18.18rpx;
				.money-col {
					padding: 0 9.09rpx 9.09rpx;
					.money-item {
						position: relative;
						padding: 9.09rpx;
						.money-item-view {
							border: 1.81rpx solid #f3f2f3;
							border-radius: 18.18rpx;
							position: relative;
							padding: 9.09rpx;
							.cu-avatar {
								position: absolute;
								left: 9.09rpx;
							}
							.money-content {
								position: relative;
							    margin-left: 109.09rpx;
							    margin-bottom: 27.27rpx;
							    top: 12.72rpx;
							}
						}
					}
				}
			}
			.zaiui-user-info-tools-box {
				border-radius: 18.18rpx;
				.tools-view {
					position: relative;
					.tools-title {
						padding-right: 81.81rpx;	
					}
					.tools-right {
						position: absolute;
					    right: 9.09rpx;
					    bottom: 23.63rpx;	
					}
				}
				
			}
		}
	}
	.zaiui-my-box.show {
		display: block;
	}
</style>
