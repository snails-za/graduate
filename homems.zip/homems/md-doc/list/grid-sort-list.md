### 子分类的宫格图标导航

****

##### 参数说明

| 参数 | 类型 | 默认 | 说明 |
| --- | --- | --- |
| list_data | Array | 无 | 列表数据 |
| @listTap | 事件 | (data,index) | 被点击 |

****

##### list_data 参数说明

| 参数 | 类型 |  说明 |
| --- | --- | --- |
| name | String | 名称 |
| img | String | 图片地址 |
