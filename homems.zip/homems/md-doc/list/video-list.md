### 首页 - 视频列表

****

##### 参数说明

| 参数 | 类型 | 默认 | 说明 |
| --- | --- | --- |
| list_data | Array | 无 | 列表数据 |
| show | Boolean | true | 是否显示 |
| @listTap | 事件 | (data,index) | 被点击 |

****

##### list_data 参数说明

| 参数 | 类型 |  说明 |
| --- | --- | --- |
| cover_img | String | 封面图片地址 |
| title | String | 标题 |
| avatar | String | 头像图片地址 |
| name | String | 用户名称 |
| appreciate | String | 点赞数 |
