<template>
	<view>
		
		<!--聊天-->
		<news :scrollY="scrollY" :scrollBottom="scrollBottom" :show="tabID==2?true:false" />
		
		
		<!--底部导航-->
		<footer-tabbar :tabID='tabID' :msgDot='true' @tabTap='tabTap'/>
	</view>
</template>

<script>
	//加载组件
	import news from '@/components/zaiui-common/view/news';
	
	//固定组件
	import footerTabbar from '@/components/zaiui-common/footer/footer-tabbar';
	
	//工具函数
	import _tool from '@/static/zaiui/util/tools.js';
	export default {
		components: { 
			news,  footerTabbar, 
		},
		data() {
			return {
				 scrollY: 0, scrollBottom: 0, tabID: 2, tabIndex: 2,
			}
		},
		onLoad() {
			
		},
		onReady() {
			_tool.setBarColor(true);
		},
		methods: {
			tabTap(index) {
				
				this.$store.state.tabindex=index;
				this.tabIndex = this.tabID;
				
				this.tabID = index;
				
				uni.pageScrollTo({
				    scrollTop: 0,
				    duration: 0
				});
				console.log(index);
				if (index == 0 ) {
					uni.navigateTo({
						url: "/pages/app/index"
					});
				}
				if (index == 1 ) {
					uni.navigateTo({
						url: "/pages/app/index2"
					});
				}
				if (index == 2) {
					uni.navigateTo({
						url: "/pages/app/index3"
					});
				}
				if (index == 3) {
					uni.navigateTo({
						url: "/pages/app/index4"
					});
				}
			},
			
			sellCloseTap() {
				this.tabTap(this.tabIndex);
			},
		},
		onPageScroll(e) {
			this.scrollY = e.scrollTop;
			//console.log(e.scrollTop);
		},
		onReachBottom(e) {
			let timestamp = new Date().getTime();
			this.scrollBottom = timestamp;
		},
	}
</script>

<style lang="scss">
	//APP端引用。玄学问题，在这里引入css文件后，APP端才生效，在app.vue里引入无效。原因未知...
	//可自行测试在APP上是否有效，如果有效，可删除下面的引入代码。
	/* #ifdef APP-PLUS */
		@import "../../static/colorui/main.css";
		@import "../../static/colorui/icon.css";
		@import "../../static/zaiui/style/app.scss";
	/* #endif */
</style>
