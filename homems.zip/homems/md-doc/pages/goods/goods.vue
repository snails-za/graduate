<template>
	<view>
		<!--标题栏-->
		<bar-title bgColor='bg-white'>
			<block slot="content">房源详情</block>
			<block slot="right">
				<text class="cuIcon-forward"/>
				<text class="cuIcon-more"/>
			</block>
		</bar-title>
		
		<!--提示-->
		<view class="bg-grey text-sm text-center padding-tb-xs text-white">房屋真实情况请联系房主查看</view>
		
		<!--轮播图-->
		<view class="zaiui-banner-swiper-box">
			<swiper class="screen-swiper" circular autoplay >
				<swiper-item >
					<image :src="houseimg" mode="aspectFill"/>
				</swiper-item>
			</swiper>
			<!--页码-->
			<text class="cu-tag bg-grey round sm zaiui-page">{{bannerCur + 1}} / {{bannerList.length}}</text>
		</view>
		
		<!--原价-->
		<view class="zaiui-limited-seckill-box">
			<text class="text-price text-xxl">{{houseinfo.price}}</text>
			<view class="text-xs zaiui-cost-price-num price-4" style="margin-left:15px;">
				<view class="text-through">原价￥{{houseinfo.price}}</view>
				<view>{{houseinfo.type}}</view>
			</view>
			
		</view>
		
		<!--标题-->
		<view class="bg-white zaiui-view-box zaiui-title-view-box">
			<view class="title-view">
				<text class="cu-tag bg-red radius sm">精品房源</text>
				<text class="text-black text-lg text-bold">{{houseinfo.name}}</text>
			</view>
		</view>
		
		<!--介绍-->
		<view class="margin-top bg-white zaiui-view-box zaiui-service-view-box" >
			<view class="flex flex-wrap text-sm">
				<view class="basis-1">
					<text class="text-gray">介绍</text>
				</view>
				<view class="basis-7">
					<view>
						<text class="tag-view">
							<text class="cuIcon-title text-red"/>
							<text>{{houseinfo.description}}</text>
						</text>
					</view>
					
				</view>
			</view>
		</view>
		
		
		
		<!--地址-->
		<view class="margin-top bg-white zaiui-view-box zaiui-select-view-box">
			<view class="flex flex-wrap text-sm">
				<view class="basis-1">
					<text class="text-gray">地址</text>
				</view>
				<view class="basis-9">
					<text class="text-sm">{{houseinfo.address}}</text>
				</view>
			</view>
			
			<view class="zaiui-border-view"/>
			
			<view class="flex flex-wrap text-sm" >
				<view class="basis-1">
					<text class="text-gray">时间</text>
				</view>
				<view class="basis-8">
					<text class="text-sm">{{getdate(houseinfo.publish_time)}}</text>
				</view>
			</view>
		</view>
		
		
		<!--信息-->
		<view class="margin-top bg-white zaiui-view-box zaiui-goods-info-view-box">
			<view class="zaiui-shop-view">
				<view class="cu-avatar lg round" :style="'background-image:url('+userimg+')'"/>
				<view class="text-view">
					<view class="margin-bottom-xs">{{userinfo.name}}</view>
					<view class="text-sm text-cut">{{userinfo.phone}}</view>
				</view>
			</view>
			
			<view class="zaiui-border-view"/>
			
		</view>
		

		<!--占位底部距离-->
		<view class="cu-tabbar-height"/>
		
		<!--底部操作-->
		<view class="zaiui-footer-fixed">
			<view class="cu-bar bg-white tabbar border shop">
				<button class="action">
					<view class="cuIcon-service"/>
					<view>联系</view>
				</button>
				<view class="action" >
					
				</view>
				<view class="btn-group">
					<!-- <button class="cu-btn bg-orange radius shadow-blur" @tap="selectTap('add')">加入购物车</button> -->
					<button class="cu-btn bg-red radius shadow-blur" style="margin-left:105px;" @tap="selectTap('sell')">立即租房</button>
				</view>
			</view>
		</view>
		
		
		
	</view>
</template>

<script>
	import barTitle from '@/components/zaiui-common/basics/bar-title';
	
	import _tool from '@/static/zaiui/util/tools.js';	//工具函数
	import { housedetail } from '@/api/homes/index.js';
	import { formateDate } from '@/global/utils/utils.js';
	
	
	export default {
		components: {
			barTitle,
		},
		data() {
			return {
				bannerCur: 0, bannerList: [], bottomModal: false, modalTitle: '', modalType: 'promotion', selectType: '',
				detailID:"",
				houseinfo:"",
				userimg:"",
				houseimg:"",
				userinfo:{
					name:"",
					phone:""
				}
			}
		},
		onLoad() {
			this.userimg = uni.getStorageSync('headimg');
			this.detailID=this.$store.state.selshopid;
			
			console.log(this.detailID);
			this.getdata();
		},
		onReady() {
			_tool.setBarColor(true);
			uni.pageScrollTo({
			    scrollTop: 0,
			    duration: 0
			});
		},
		methods: {
			getdata(){
				const token = uni.getStorageSync('token');
				var params={token:token,house_id:this.detailID};
				housedetail(params).then(res=>{
					if(res==undefined){
						this.getdata();
					}
					if(res.data.state==0){
						var item=res.data.data.houses;
						var banner={img:item.image};
						this.bannerList.push(banner)
						this.houseinfo=item;
						this.userinfo=item.user;
						this.houseimg=item.image;
					}
				});
			},
			getdate(date){
				
				let formtime = formateDate(new Date(date), 'Y-M-D');
				return formtime;
			},
			selectTap(type) {
				
				uni.navigateTo({
					url: '/pages/goods/settlement'
				});
			},
			showModal() {
				this.bottomModal = true;
			},
			hideModal(e) {
				this.bottomModal = false;
				this.modalTitle = "";
				this.modalType = '';
			},
			myCartTap(){
				uni.navigateTo({
					url: '/pages/goods/my_cart'
				});
			}
		}
	}
</script>

<style lang="scss">
	/* #ifdef APP-PLUS */
		@import "../../static/colorui/main.css";
		@import "../../static/colorui/icon.css";
		@import "../../static/zaiui/style/app.scss";
	/* #endif */
	@import "../../static/zaiui/style/goods.scss";
</style>
