<template>
	<view>
		<!--标题栏-->
		<bar-title bgColor='bg-white'>
			<block slot="content">支付方式</block>
		</bar-title>
		<!--商品信息-->
		<view class="bg-white zaiui-goods-details-box">
			<view class="cu-avatar radius" :style="[{backgroundImage:'url('+ houseimg +')'}]"/>
			<view class="goods-info-view">
				<view class="text-cut text-black">{{houseinfo.name}}</view>
				<view class="text-sm text-gray">{{houseinfo.description}}</view>
				<view class="text-sm text-gray">{{houseinfo.type}}</view>
				<text class="text-price text-red text-lg">{{houseinfo.price}}</text>
			</view>
		</view>
		
		<view class="text-gray padding-sm">支付方式</view>
		
		<!--支付方式-->
		<view class="bg-white zaiui-pay-view">
			<radio-group class="block" @change="RadioChange">
				<view class="zaiui-pay-bar" @tap="payTap('wechat')">
					<view class="cu-avatar sm" style="background-image:url(/static/zaiui/img/wechat.png)"/>
					<view class="content">
						<view class="text-black">
							<text class="margin-right-sm">微信支付</text>
							<text class="cu-tag bg-red radius sm">推荐</text>
						</view>
						<view class="text-gray text-sm">亿万用户的选择，更快更安全</view>
					</view>
					<view class="action">
						<radio class="red zaiui-radio" :class="radio=='wechat'?'checked':''" :checked="radio=='wechat'?true:false" value="wechat"/>
					</view>
				</view>
				
				<view class="zaiui-pay-bar" @tap="payTap('alipay')">
					<view class="cu-avatar sm" style="background-image:url(/static/zaiui/img/alipay.png)"/>
					<view class="content">
						<view class="text-black">
							<text class="margin-right-sm">支付宝支付</text>
							<text class="cu-tag line-red radius sm">HOT</text>
						</view>
						<view class="text-gray text-sm">数亿用户都在用，安全可托付</view>
					</view>
					<view class="action">
						<radio class="red zaiui-radio" :class="radio=='alipay'?'checked':''" :checked="radio=='alipay'?true:false" value="alipay"/>
					</view>
				</view>
			</radio-group>
		</view>
		
		
		
		<!--底部操作-->
		<view class="bg-white zaiui-footer-fixed zaiui-foot-padding-bottom">
			<view class="padding-sm flex flex-direction">
				<button class="cu-btn radius bg-red" @tap="payBtnTap">立即支付</button>
			</view>
		</view>
		
	</view>
</template>

<script>
	import barTitle from '@/components/zaiui-common/basics/bar-title';
	import _tool from '@/static/zaiui/util/tools.js';	//工具函数
	import { housedetail,postaddorder } from '@/api/homes/index.js';
	
	export default {
		components: {
			barTitle,
		},
		data() {
			return {
				goodsList: [], checkAll: true, goods_img: '/static/images/home/goods/1.png', radio: 'wechat',
				bannerList: [],
				detailID:"",
				houseinfo:"",
				userimg:"",
				houseimg:"",
				userinfo:{
					name:"",
					phone:""
				}
			}
		},
		onLoad() {
			this.userimg = uni.getStorageSync('headimg');
			this.detailID=this.$store.state.selshopid;
			this.houseimg=this.$store.state.houseimg;
			console.log(this.detailID);
			this.getdata();
		},
		onReady() {
			_tool.setBarColor(true);
			uni.pageScrollTo({
			    scrollTop: 0,
			    duration: 0
			});
		},
		methods: {
			getdata(){
				const token = uni.getStorageSync('token');
				var params={token:token,house_id:this.detailID};
				housedetail(params).then(res=>{
					console.log(res);
					if(res.data.state==0){
						var item=res.data.data.houses;
						var banner={img:item.image};
						this.bannerList.push(banner)
						this.houseinfo=item;
						this.userinfo=item.user;
						console.log(this.userinfo);
					}
				});
			},
			RadioChange(e) {
				this.radio = e.detail.value;
			},
			payBtnTap() {
				var totalprice=this.$store.state.total_price;
				const token = uni.getStorageSync('token');
				var params={
					token:token,
					house_id:"",
					hire_price:"",
					cash_price:"",
					enter_time:"",
					exit_time:""
				};
				postaddorder(params).then(res=>{
					if(res.data.state==0){
						console.log(res);
					}
				});
				uni.navigateTo({
					url: "/pages/status/pay_status"
				});
			},
			payTap(type) {
				this.radio = type;
			}
		}
	}
</script>

<style lang="scss">
	/* #ifdef APP-PLUS */
		@import "../../static/colorui/main.css";
		@import "../../static/colorui/icon.css";
		@import "../../static/zaiui/style/app.scss";
	/* #endif */
	@import "../../static/zaiui/style/pay.scss";
</style>
