<template>
	<view>
		<!--标题栏-->
		<bar-title bgColor="bg-white" isBack>
			<block slot="content">关于我们</block>
		</bar-title>
		
		
		
		<view class="cu-list menu sm-border margin-top" style="margin-top:50%; ">
			<view class="cu-item " style="padding:20px 0px;">
				<view class="content text-center">{{info.detail_content}}</view>
			</view>
		</view>
		
	</view>
</template>

<script>
	import barTitle from '@/components/zaiui-common/basics/bar-title';
	import _tool from '@/static/zaiui/util/tools.js';	//工具函数
	import { about_pandas } from '@/api/homes/index.js';
	
	export default {
		components: {
			barTitle
		},
		data() {
			return {
				skin: true,
				info:{}
			}
		},
		onLoad() {
			this.getdata();
		},
		onReady() {
			_tool.setBarColor(true);
			uni.pageScrollTo({
			    scrollTop: 0,
			    duration: 0
			});
		},
		methods: {
			getdata(){
				about_pandas().then(res=>{
					if(res==undefined){
						this.getdata();
					}
					if(res.data.state==0){
						this.info=res.data.interal[0];
					}
				});
			}
			
		}
	}
</script>

<style lang="scss">
	/* #ifdef APP-PLUS */
		@import "../../static/colorui/main.css";
		@import "../../static/colorui/icon.css";
		@import "../../static/zaiui/style/app.scss";
	/* #endif */
</style>
