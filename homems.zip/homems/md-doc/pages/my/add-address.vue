<template>
	<view>
		<!--标题栏-->
		<bar-title bgColor="bg-white" isBack @rightTap="sub_info">
			<block slot="content">添加房源</block>
			<block slot="right">
				<text class="text-orange">保存</text>
			</block>
		</bar-title>
		
		<!--表单-->
		<view class="cu-form-group margin-top">
			<view class="title">房源名称</view>
			<input placeholder="您的房源名称" v-model="houseinfo.name" />
		</view>
		<view class="cu-form-group">
			<view class="title">类型</view>
			<input placeholder="您的房源类型" v-model="houseinfo.type" />
		</view>
		
		<view class="cu-bar bg-white ">
			<view class="action">
				图片上传
			</view>
			
		</view>
		<view class="cu-form-group">
			<view class="grid col-4 grid-square flex-sub">
				<view class="bg-img" v-for="(item,index) in imgList" :key="index" @tap="ViewImage" :data-url="imgList[index]">
				 <image :src="imgList[index]" mode="aspectFill"></image>
					<view class="cu-tag bg-red" @tap.stop="DelImg" :data-index="index">
						<text class='cuIcon-close'></text>
					</view>
				</view>
				<view class="solids" @tap="ChooseImage" v-if="imgList.length<1">
					<text class='cuIcon-cameraadd'></text>
				</view>
			</view>
		</view>
		
		<view class="cu-form-group">
			<view class="title">地址</view>
			<input placeholder="请输入地址信息"  v-model="houseinfo.address"/>
		</view>
		<view class="cu-form-group">
			<view class="title">价格</view>
			<input placeholder="请输入价格"  v-model="houseinfo.price"/>
		</view>
		<view class="cu-form-group">
			<view class="title">面积</view>
			<input placeholder="请输入面积" v-model="houseinfo.area" />
		</view>
		<view class="cu-form-group align-start">
			<view class="title">介绍</view>
			<textarea maxlength="-1"  v-model="houseinfo.discription" placeholder="介绍"></textarea>
		</view>
		
	
		
	</view>
</template>

<script>
	import barTitle from '@/components/zaiui-common/basics/bar-title';
	import _tool from '@/static/zaiui/util/tools.js';	//工具函数
	import { add_house } from '@/api/homes/index.js';
	
	export default {
		components: {
			barTitle
		},
		data() {
			return {
				multiIndex: [0, 0, 0], nameClose: false, phoneClose: false, addressClose: false,
				imgList: [],
				index: -1,
				houseinfo:{
					name:"",
					token:"",
					type:"",
					address:"",
					price:"",
					area:"",
					discription:"",
					image:""
				}
			}
		},
		onLoad() {
			const token = uni.getStorageSync('token');
			this.houseinfo.token=token;
		},
		onReady() {
			_tool.setBarColor(true);
			uni.pageScrollTo({
			    scrollTop: 0,
			    duration: 0
			});
		},
		methods: {
			sub_info(){
				
				var name=this.houseinfo.name
				var type=this.houseinfo.type
				var token=this.houseinfo.token
				var price=this.houseinfo.price
				var address=this.houseinfo.address
				var area=this.houseinfo.area
				var discription=this.houseinfo.discription
				var image=this.imgList[0];
				console.log(image);
				uni.uploadFile({
				            url: 'http://114.116.245.220:8010/api/add/', //仅为示例，非真实的接口地址
				            filePath: image,
				            name: 'image',
				            formData: {
				                'token': token,
				                'name': name,
				                'type': type,
				                'price': price,
				                'address': address,
				                'area': area,
				                'discription': discription
				            },
				            success: (res) => {
				                uni.navigateTo({
				                	url: "/pages/app/index4"
				                })
				            }
				        });
						
				
				
				// add_house(formData).then(res=>{
				// 	console.log(res);
				// 	if(res.data.state==0){
						
				// 		// uni.navigateTo({
				// 		// 	url: 'login'
				// 		// })
				// 	}else{
				// 		uni.showToast({
				// 			icon: 'none',
				// 			position: 'bottom',
				// 			title: res.data.msg
				// 		});
				// 	}
				// })
			},
			ViewImage(e) {
				uni.previewImage({
					urls: this.imgList,
					current: e.currentTarget.dataset.url
				});
			},
			DelImg(e) {
				this.imgList.splice(e.currentTarget.dataset.index, 1)
			},
			ChooseImage() {
				uni.chooseImage({
					count: 1, //默认9
					sizeType: ['original', 'compressed'], //可以指定是原图还是压缩图，默认二者都有
					sourceType: ['album'], //从相册选择
					success: (res) => {
						// const image_ = self.data.image.concat(res.tempFilePaths)
						// console.info(image_)
						// self.setData({
						//   image: image_
						// })
						console.log(res);
						if (this.imgList.length != 0) {
							this.imgList = this.imgList.concat(res.tempFilePaths)
						} else {
							this.imgList = res.tempFilePaths
						}
					}
				});
			},
			
		
		}
	}
</script>

<style lang="scss">
	/* #ifdef APP-PLUS */
		@import "../../static/colorui/main.css";
		@import "../../static/colorui/icon.css";
		@import "../../static/zaiui/style/app.scss";
	/* #endif */
	.wecanui-footer-fixed .flex-direction {
		padding: 18.18rpx;
	}
</style>
