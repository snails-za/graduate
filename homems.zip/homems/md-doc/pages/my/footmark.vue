<template>
	<view>
		<!--标题栏-->
		<bar-title bgColor="bg-white" isBack @rightTap="rightTap">
			<block slot="content">我的房源</block>
			<!-- <block slot="right" v-if="goods_checked">完成</block> -->
			<block slot="right" >添加</block>
		</bar-title>
		
		
		
		<checkbox-group class="block" @change="checkboxChange">
			<!--商品列表-->
			<view class="bg-white zaiui-goods-list-view" :class="goods_checked?'checked':''">
				
				<view class="zaiui-goods-list-box" v-for="(item,index) in goodsSortListData ">
					<checkbox class='round red zaiui-checked' :class="item.checked?'checked':''"
					:checked="item.checked?true:false" :value="item.house_id + ''"/>
					<view class="cu-avatar radius" :style="[{backgroundImage:'url('+ item.image +')'}]"/>
					<view class="goods-info-view">
						<view class="text-cut-2 text-black">{{item.name}}</view>
						<view class="goods-info-tools">
							<text class="text-price text-red text-lg">{{item.price}}</text>
							<text class="cu-tag radius line-red sm">{{item.type}}</text>
						</view>
					</view>
				</view>
			</view>
			
			
		</checkbox-group>
		
		<!--占位底部距离-->
		<view class="cu-tabbar-height" v-if="goods_checked"/>
		
		<!--底部操作-->
		<view class="bg-white zaiui-footer-fixed zaiui-foot-padding-bottom" v-if="goods_checked">
			<view class="cu-bar padding-lr">
				<view class="checked-view" @tap="tapChecked"> 
					<checkbox class='round red sm zaiui-checked' :class="checkbox_all?'checked':''" :checked="checkbox_all"/>
					<text class="text-black text-lg">全选</text>
				</view>
				<view class="btn-view">
					<button class="cu-btn radius bg-red">删除(3)</button>
				</view>
			</view>
		</view>
		
		<!--小程序端显示-->
		<!-- #ifdef MP -->
			<!--编辑-->
			<view class="zaiui-add-btn-view-box" @tap="rightTap">
				<button class="cu-btn cuIcon-check bg-red" v-if="goods_checked"/>
				<button class="cu-btn cuIcon-write bg-red" v-else/>
			</view>
		<!-- #endif -->
	</view>
</template>

<script>
	import barTitle from '@/components/zaiui-common/basics/bar-title';
	import _tool from '@/static/zaiui/util/tools.js';	//工具函数
	import { gethouselist } from '@/api/homes/index.js';
	
	export default {
		components: {
			barTitle
		},
		data() {
			return {
				headTab: {TabCur: 0, scrollLeft: 0, list: []},
				goods_img: '/static/images/home/goods/1.png',
				goods_img_a: '/static/images/home/goods/2.png',
				checkbox_list: [], checkbox_all: false, goods_checked: false,
				goodsSortListData: [],
			}
		},
		onLoad() {
			this.gethouselistdata();
			this.checkbox_list = [
				{id: 1,checked: true}, {id: 2,checked: false}, {id: 3,checked: false},
				{id: 4,checked: false}, {id: 5,checked: false}, {id: 6,checked: false}
			];
		},
		onReady() {
			_tool.setBarColor(true);
			uni.pageScrollTo({
			    scrollTop: 0,
			    duration: 0
			});
		},
		methods: {
			gethouselistdata()
			{
				const value = uni.getStorageSync('token');
				var params={token:value};
				gethouselist(params).then(res=>{
					if(res==undefined){
						this.gethouselistdata();
					}
					if(res.data.state==0){
						
						this.goodsSortListData=res.data.data;
						this.goodsSortListData.forEach(item=>{
							item.checked=false;
						})
						console.log(this.goodsSortListData);
					}else{
						uni.reLaunch({
							url: '/pages/login/login'
						});
					}
				});
			},
			//tab菜单被点击
			tabSelect(e) {
				let index = e.currentTarget.dataset.id;
				this.headTab.TabCur = index;
				this.headTab.scrollLeft = (index - 1) * 60;
				
				//滚动到顶部
				uni.pageScrollTo({
				    scrollTop: 0,
				    duration: 100
				});
			},
			//编辑
			rightTap() {
				uni.reLaunch({
					url: '/pages/my/add-address'
				});
			},
			//选择
			checkboxChange(e) {
				let items = this.checkbox_list, values = e.detail.value;
				for (let i = 0; i < items.length; i++) {
					//店铺处理
					let result = values.includes(items[i].id + '');
					if (result) {
						items[i].checked = true;
					} else {
						items[i].checked = false;
					}
				}
			},
			tapChecked() {
				if (this.checkbox_all) {
					this.checkbox_all = false;
				} else {
					this.checkbox_all = true;
				}
			}
		}
	}
</script>

<style lang="scss">
	/* #ifdef APP-PLUS */
		@import "../../static/colorui/main.css";
		@import "../../static/colorui/icon.css";
		@import "../../static/zaiui/style/app.scss";
	/* #endif */
	@import "../../static/zaiui/style/footmark.scss";
</style>
