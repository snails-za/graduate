<template>
	<view>
		<!--标题栏-->
		<bar-title bgColor="bg-white" isBack>
			<block slot="content">升级会员</block>
		</bar-title>
		
		<!--标题-->
		<view class="text-gray text-xl zaiui-title-view text-center">为提升交易可靠性，请如实填写信息</view>
		
		
		
		<!--表单-->
		<view class="cu-form-view margin-top-lg">
			<view class="cu-form-group " >
				<view class="title">姓名</view>
				<input placeholder="请输入真实姓名" v-model="userinfo.name"/>
			</view>
		</view>
		<view class="cu-form-view">
			<view class="cu-form-group " >
				<view class="title">身份证</view>
				<input placeholder="请输入18位身份证号" v-model="userinfo.identity_number"/>
			</view>
			
		</view>
		<view class="cu-form-view">
			<view class="cu-form-group " >
				<view class="title">邮箱</view>
				<input placeholder="请输入邮箱" v-model="userinfo.email"/>
			</view>
		</view>
		<view class="cu-form-view">
			<view class="cu-form-group " >
				<view class="title">昵称</view>
				<input placeholder="请输入昵称" v-model="userinfo.nickname"/>
			</view>
		</view>
		<view class="cu-form-view">
			<view class="cu-form-group " >
				<view class="title">性别</view>
				<input placeholder="请输入性别" v-model="userinfo.sex"/>
			</view>
		</view>
		<view class="cu-form-view">
			<view class="cu-form-group " >
				<view class="title">电话</view>
				<input placeholder="请输入电话" v-model="userinfo.phone"/>
			</view>
		</view>
		
		<!--按钮-->
		<view class="bg-white zaiui-btn-view zaiui-foot-padding-bottom">
			<view class="flex flex-direction">
				<button class="cu-btn bg-red" @click="updatebtn">确认</button>
			</view>
		</view>
		
	</view>
</template>

<script>
	import barTitle from '@/components/zaiui-common/basics/bar-title';
	import _tool from '@/static/zaiui/util/tools.js';	//工具函数
	import { become_superuser } from '@/api/homes/index.js';
	
	export default {
		components: {
			barTitle
		},
		data() {
			return {
				userinfo:{
					token:"",
					nickname:"",
					sex:"",
					phone:"",
					email:"",
					name:"",
					identity_number:"",
				}
			}
		},
		onLoad() {
			this.userinfo.token = uni.getStorageSync('token');
		},
		onReady() {
			_tool.setBarColor(true);
			uni.pageScrollTo({
			    scrollTop: 0,
			    duration: 0
			});
		},
		methods: {
			updatebtn(){
				become_superuser(this.userinfo).then(res=>{
					if(res.data.state==0){
						uni.showModal({
							title: '提示',
							content: res.data.msg,
							showCancel: false
						})
						uni.navigateTo({
							url: "/pages/app/index"
						});
					}
				});
			}
		}
	}
</script>


<style lang="scss">
	/* #ifdef APP-PLUS */
		@import "../../static/colorui/main.css";
		@import "../../static/colorui/icon.css";
		@import "../../static/zaiui/style/app.scss";
	/* #endif */
	page { background: #FFFFFF; }
	.zaiui-title-view {
	    position: relative;
	    padding: 18.18rpx;
	}
	.zaiui-content-view {
		position: relative;
		padding: 0 18.18rpx;
	}
	.cu-form-view {
		position: relative;
		// margin: 0 27.27rpx;
		// padding: 18.18rpx 0;
		border-bottom: 2rpx solid rgba(0,0,0,0.1);
		input {
			
		}
	}
	.cu-form-view.margin-top-lg {
		margin-top: 40rpx;
	}
	.zaiui-btn-view {
	    position: fixed;
	    width: 100%;
		bottom: 0;
		.flex {
			padding: 18.18rpx;
		}
	}
</style>
