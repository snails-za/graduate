let _sell_data = {
	typeListData() {
		return [{
			id: 1,
			title: '手机',
			text: 'iPhone/华为/小米/OPPO/vivo/三星',
			img: '/static/images/home/goods/1.png'
		},{
			id: 2,
			title: '图书影音',
			text: '文学小说/教材教辅/唱片影片',
			img: '/static/images/home/goods/2.png'
		},{
			id: 3,
			title: '数码',
			text: '摄影器材/耳机/智能穿戴/音箱/游戏机',
			img: '/static/images/home/goods/3.png'
		},{
			id: 4,
			title: '服装鞋帽',
			text: '男装/女装/鞋/箱包/配饰',
			img: '/static/images/home/goods/4.png'
		},{
			id: 5,
			title: '交通工具',
			text: '摩托车/电动车/自行车/汽车用品/汽车配件',
			img: '/static/images/home/goods/5.png'
		},{
			id: 6,
			title: '母婴用品',
			text: '服饰/童车童床/玩具图书/洗护用品/孕妈用品',
			img: '/static/images/home/goods/6.png'
		},{
			id: 7,
			title: '家用电器',
			text: '生活电器/厨房电器/电器配件',
			img: '/static/images/home/goods/7.png'
		},{
			id: 8,
			title: '家居家具',
			text: '沙发桌椅/家装软饰/灯具照明/厨房卫浴',
			img: '/static/images/home/goods/8.png'
		},{
			id: 9,
			title: '手机',
			text: 'iPhone/华为/小米/OPPO/vivo/三星',
			img: '/static/images/home/goods/1.png'
		},{
			id: 10,
			title: '图书影音',
			text: '文学小说/教材教辅/唱片影片',
			img: '/static/images/home/goods/2.png'
		},{
			id: 11,
			title: '数码',
			text: '摄影器材/耳机/智能穿戴/音箱/游戏机',
			img: '/static/images/home/goods/3.png'
		},{
			id: 12,
			title: '服装鞋帽',
			text: '男装/女装/鞋/箱包/配饰',
			img: '/static/images/home/goods/4.png'
		},{
			id: 13,
			title: '交通工具',
			text: '摩托车/电动车/自行车/汽车用品/汽车配件',
			img: '/static/images/home/goods/5.png'
		},{
			id: 14,
			title: '母婴用品',
			text: '服饰/童车童床/玩具图书/洗护用品/孕妈用品',
			img: '/static/images/home/goods/6.png'
		},{
			id: 15,
			title: '家用电器',
			text: '生活电器/厨房电器/电器配件',
			img: '/static/images/home/goods/7.png'
		},{
			id: 16,
			title: '家居家具',
			text: '沙发桌椅/家装软饰/灯具照明/厨房卫浴',
			img: '/static/images/home/goods/8.png'
		}];
	}
};

export default _sell_data;