import datetime
import os

from flask import Blueprint, request
from flask.json import jsonify
from sqlalchemy import and_

import settings
from apiapp.views import validate_json, validate_params, get_house_image
from common import cache_, oss_
from common.serializer import to_json
from db_ import session
from apiapp.models import THouse, THouseVerify

blue = Blueprint('house_api', __name__)


# 房源发布
@blue.route('/add/', methods=['POST'])
def add_house():
    """
    房源发布
    :return:
    """
    # resp = validate_json()
    # if resp: return resp
    # resp = validate_params(['token', 'image', 'name', 'type', 'address', 'price', 'area', 'discription'])
    # if resp: return resp
    upload_file = request.files.get('image')
    file_name = upload_file.filename
    # print(file_name)
    save_file_path = os.path.join(settings.TEMP_HOUSE_DIR, file_name)
    # 保存上传的文件到临时的目录中
    upload_file.save(save_file_path)

    user_id = cache_.get_user_id(request.form.get('token'))
    if user_id:
        try:
            house = THouse()
            house.user_id = user_id
            # house.image = 'http://localhost:5000/s/' + file_name
            key = f'h-{user_id}-{file_name}'  # 存储oss上的key对象
            house.image = key
            house.name = request.form.get('name')
            house.type = request.form.get('type')
            house.address = request.form.get('address')
            house.price = request.form.get('price')
            house.area = request.form.get('area')
            house.description = request.form.get('discription')
            house.publish_time = datetime.datetime.now()
            house.sale_status = 0
            house.is_public = 1
            session.add(house)
            session.commit()


            house_image_url = oss_.upload_house_image(user_id, file_name, save_file_path)

            # 将房屋图片的url存到redis中
            cache_.save_house_url(key, house_image_url)

            verify = THouseVerify()
            verify.house_id = house.house_id
            verify.verify_status = 0
            session.add(verify)
            session.commit()
            return jsonify({
                'state': 0,
                'msg': '发布房源成功'
            })
        except:
            return jsonify({
                'state': 2,
                'msg': '网络延迟，请等会再尝试！'
            })
    return jsonify({
        "state": 1,
        'msg': '未登录，请先登录！'
    })


@blue.route('/del_house/', methods=['POST'])
def del_house():
    """
    删除房源信息的房源信息
    :return:
    """
    # 验证参数完整性
    # resp = validate_json()
    # if resp: return resp
    # resp = validate_params('token', 'house_id')
    # if resp: return resp

    data = request.get_json()
    house_id = data['house_id']
    token = data['token']
    user_id = cache_.get_user_id(token)
    house = session.query(THouse).filter(house_id == house_id, user_id == user_id)
    print(house)
    if house:
        obj = house.first()
        obj.is_public = 0
        session.add(obj)
        session.commit()
        return jsonify({
            'state': 0,
            'msg': '撤销房源成功'
        })
    else:
        return jsonify({
            'state': 1,
            'msg': '登录已过期或房屋信息已删除'
        })


@blue.route('/change_house_info/', methods=['POST'])
def change_house_info():
    """
    改变房屋信息
    :return:
    """
    # resp = validate_json()
    # if resp: return resp
    # resp = validate_params('image', 'name', 'type', 'address', 'price', 'area', 'description', 'token', 'house_id')
    # if resp: return resp
    upload_file = request.files.get('image')
    file_name = upload_file.filename
    # print(file_name)
    save_file_path = os.path.join(settings.TEMP_HOUSE_DIR, file_name)
    # 保存上传的文件到临时的目录中
    upload_file.save(save_file_path)

    data = request.form
    house_id = data['house_id']
    token = data['token']
    user_id = cache_.get_user_id(token)
    if user_id:
        try:
            house = session.query(THouse).filter(THouse.house_id == house_id, THouse.user_id == user_id).first()
            key = f'h-{user_id}-{file_name}'  # 存储oss上的key对象
            house.image = key
            house.name = data['name']
            house.type = data['type']
            house.address = data['address']
            house.price = data['price']
            house.area = data['area']
            house.description = data['description']
            house.publish_time = datetime.datetime.now()
            session.add(house)
            session.commit()

            house_image_url = oss_.upload_house_image(user_id, file_name, save_file_path)

            # 将房屋图片的url存到redis中
            cache_.save_house_url(key, house_image_url)

            verify = THouseVerify()
            verify.house_id = house.house_id
            verify.verify_status = 0
            session.add(verify)
            session.commit()
            return jsonify({
                'state': 0,
                'msg': '房源信息修改成功！等待审核！'
            })
        except:
            return jsonify({
                'state': 2,
                'msg': '未发布房源，请先发布房源！'
            })
    else:
        return jsonify({
            'state': 1,
            'msg': '还未登陆，请先登录！'
        })


@blue.route('/list_houses/', methods=['GET'])
def list_user_houses():
    """
    查看现登录房东的已通过审核的的房源信息
    :return:
    """
    data = request.args.get('token')
    user_id = cache_.get_user_id(data)
    print(user_id)
    if user_id:
        ret = session.query(THouse).filter(THouse.user_id == user_id).all()
        try:
            data = to_json(ret)

            for house_info in data:
                h_key = house_info.get('image')
                h_image_url = get_house_image(h_key)
                # print("+++++++++++++++", image_url)
                house_info['image'] = h_image_url
                u_key = house_info['user']['img']
                u_image_url = get_house_image(u_key)
                house_info['user']['img'] = u_image_url
            return jsonify({
                'state': 0,
                'msg': '查询成功',
                'data': data
            })
        except:
            return jsonify({
                'state': 2,
                'msg': '暂未发布房源',
            })
    else:
        return jsonify({
            'state': 1,
            'msg': '未登录'
        })


@blue.route('/list_all_houses/', methods=['GET'])
def list_all_houses():
    """
    查看所有房源详细信息
    :return:
    """
    try:
        ret = session.query(THouse).all()
        data = to_json(ret)
        for (house_info, verify_obj) in zip(data, ret):
            h_key = house_info.get('image')
            h_image_url = get_house_image(h_key)
            # print("+++++++++++++++", image_url)
            house_info['image'] = h_image_url
            u_key = house_info['user']['img']
            u_image_url = get_house_image(u_key)
            house_info['user']['img'] = u_image_url
            house_info["verify_status"] = verify_obj.t_house_verifies[0].verify_status
            print("verify_status", house_info["verify_status"])

        return jsonify({
            'state': 0,
            'data': data
        })
    except Exception as e:
        session.rollback()
        print(e)
        return jsonify({
            'state': 1,
            'msg': '获取房屋信息失败！'
        })

@blue.route('/detail/', methods=['GET'])
def detail_info():
    """
    查看房屋的详情
    :return:
    """
    # token = request.args.get('token')
    # user_id = cache_.get_user_id(token)
    # if user_id:
    house_id = request.args.get('house_id')

    verify_info = session.query(THouseVerify).filter(THouseVerify.house_id == house_id)
    if verify_info:
        obj = verify_info.first()
        house_info = to_json(obj.house)
        # print("+++++++++++++++", type(house_info), house_info)
        h_key = house_info.get('image')
        h_image_url = get_house_image(h_key)
        # print("+++++++++++++++", image_url)
        house_info['image'] = h_image_url
        u_key = house_info['user']['img']
        u_image_url = get_house_image(u_key)
        house_info['user']['img'] = u_image_url
        return jsonify({
            'state': 0,
            'msg': '查询成功',
            'data': {
                'verify_state': obj.verify_status,
                'houses': house_info
            }
        })
    else:
        return jsonify({
            'state': 2,
            'msg': '查询失败，发生了未知错误，请重新尝试！'
        })
    #
    # return jsonify({
        # 'state': 1,
        # 'msg': '未登录，请先登录！'
    # })

