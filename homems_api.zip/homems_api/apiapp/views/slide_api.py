import uuid

from flask import Blueprint, request, g, redirect, url_for
from flask.json import jsonify

from apiapp.views import validate_json, validate_params, get_house_image
from common import cache_
from common.serializer import to_json
from db_ import session
from apiapp.models import TUser, THouse, THouseVerify, TSlidesshow, TFavorite, TOrder

blue = Blueprint('slide_api', __name__)


@blue.route('/slide/', methods=['GET'])
def slide_view():  # 获取首页轮播图
    try:
        slides_list = session.query(TSlidesshow).all()
        # house_info = session.query(THouse).filter(THouse.house_id == s.house_id)
        res = to_json(slides_list)
        for ad in res:
            key = ad['house']["image"]
            ad['house']["image"] = get_house_image(key)

        return jsonify({
            'state': 0,
            'msg': '请求成功',
            'data': res
        })

    except Exception as e:
        session.rollback()
        print("获取轮播图数据错误", e)
        return jsonify({
            'state': 1,
            'msg': '服务器错误'
        })


# 首页房屋展示
@blue.route('/house_display/', methods=["GET"])
def house_display():
    houses = session.query(THouse).all()
    if houses:
        return jsonify({
            "state": 0,
            'data': to_json(houses)
        })
    return jsonify({
        'state': 1,
        'msg': '房屋信息不存在'
    })


# 房屋详细信息页
@blue.route('/house_detail/', methods=['GET'])
def detail_info():
    """
    查看房屋的详情
    :return:
    """
    token = request.args.get('token')
    user_id = cache_.get_user_id(token)
    if user_id:
        house_id = request.args.get('house_id')

        verify_info = session.query(THouseVerify).filter(THouseVerify.house_id == house_id)
        if verify_info:
            obj = verify_info.first()
            return jsonify({
                'state': 0,
                'msg': '查询成功',
                'data': {
                    'verify_state': obj.verify_status,
                    'houses': to_json(obj.house)
                }
            })
        else:
            return jsonify({
                'state': 2,
                'msg': '查询失败，发生了未知错误，请重新尝试！'
            })

    return jsonify({
        'state': 1,
        'msg': '未登录，请先登录！'
    })


# 收藏房屋
@blue.route('/insert_collection/', methods=["POST"])
def collection():
    data = request.get_json()
    user_id = cache_.get_user_id(data["token"])
    if user_id:
        house_id = data["house_id"]
        fav = TFavorite()
        fav.house_id = house_id
        fav.user_id = user_id
        session.add(fav)
        session.commit()
        return jsonify({
            'state': 0,
            'msg': '房屋收藏成功',
        })
    return jsonify({
        'state': 1,
        'msg': '房屋添加不成功'
    })


# 查询收藏房屋的信息
@blue.route('/get_collection/', methods=["GET"])
def get_collection():
    data = request.args.get('token')
    user_id = cache_.get_user_id(data)
    if user_id:
        ret = session.query(TFavorite).filter(TFavorite.user_id == user_id).all()
    # if house_detail:
        return jsonify({
            'state': 0,
            'data': to_json(ret)
        })
    return ({
        'state': 1,
        'msg': '暂无收藏的房屋'
    })


# 下订单
ORDER_PAY = 0  # 已支付订单
ORDER_NOT_PAY = 1  # 待支付订单

# 添加订单
@blue.route('/order/', methods=["POST"])
def order():
    """
    添加订单
    :return:
    """
    resp = validate_json()
    if resp: return resp
    resp = validate_params('token', 'house_id', 'hire_price', 'cash_price', 'enter_time', 'exit_time')
    if resp: return resp

    order_num = uuid.uuid4().hex
    data = request.get_json()
    user_id = cache_.get_user_id(data["token"])
    # total_price = (data["exit_time"] - data["enter_time"]) * float(data["hire_price"]) + float(data["cash_price"])
    order = TOrder()
    order.order_number = order_num
    order.user_id = user_id
    order.house_id = data["house_id"]
    order.hire_price = data["hire_price"]
    order.cash_price = data["cash_price"]
    order.enter_time = data["enter_time"]
    order.exit_time = data["exit_time"]
    # order.total = total_price
    order.order_status = ORDER_NOT_PAY
    session.add(order)
    session.commit()
    order_info = session.query(TOrder).filter(TOrder.user_id==user_id, TOrder.order_number==order_num)
    # print(order_info)
    if order_info:
        return jsonify({
            'state': 0,
            'msg': '下单成功',
            'data': to_json(order_info.all())
        })


@blue.route('/del_order/', methods=['POST'])
def del_order():
    resp = validate_json()
    if resp: return resp
    resp = validate_params('token', 'order_number')
    if resp: return resp

    data = request.get_json()
    user_id = cache_.get_user_id(data['token'])
    if user_id:
        order_number = data['order_number']
        order = session.query(TOrder).filter(TOrder.order_number==order_number, TOrder.user_id==user_id).first()
        if order:
            session.delete(order)
            session.commit()
            return jsonify({
                'state': 0,
                'msg': '该订单已删除！'
            })
        else:
            return jsonify({
                'state': 1,
                'msg': '订单不存在'
            })
    else:
        return jsonify({
            'state': 1,
            'msg': '登录已超时，请重新登录！'
        })

