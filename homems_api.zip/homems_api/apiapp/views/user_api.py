import os
import uuid
from flask import Blueprint, Response
from flask import request, jsonify
from sqlalchemy import or_


import settings
from apiapp.models import TUser, TOrder
from apiapp.views import validate_json, validate_params, get_house_image, get_user_image
from common import code_, token_, cache_, oss_
from common.serializer import to_json
from common.simple_check import simple_check
from db_ import session
# from db.models import TUser
from db_.raw import query

blue = Blueprint('user_api', __name__)


# 发送短信验证码
@blue.route('/code/', methods=['get'])
def get_code():
    """
    发送短信验证码
    :return:
    """
    phone = request.args.get('phone')
    if phone:
        try:
            code_.send_code(phone)
            return jsonify({
                'state': 0,
                'msg': '验证码已发送'
            })
        except:
            return jsonify({
                'state': 2,
                'msg': '获取验证码失败'
            })
    return jsonify({
        'state': 1,
        'msg': '手机号不能为空'
    })

# 用户注册

@blue.route('/regist/', methods=['GET', 'POST'])
def regist():
    # 获取前端传来的JSON格式数据
    valid_fields = {"phone", "code", "password"}
    data = request.get_json()
    if data is None:
        return jsonify({
            'state': 4,
            'msg': '必须提供json格式的参数'
        })

    # 验证参数的完整性
    if set(data.keys()) == valid_fields:
        # 验证输入的验证码是否正确
        if not code_.valid_code(data['phone'], data['code']):
            return jsonify({
                'state': 2,
                'msg': '验证码输入错误，请确认输入的验证码'
            })
        user = TUser()
        # user.name = data.get('name')
        user.phone = data.get('phone')
        user.password = data.get('password')

        session.add(user)
        session.commit()
        # 向前端返回信息中，包含一个与用户匹配的token(有效时间为一周)
        # 1. 基于uuid+user_id生成token
        # 2. 将token和user_id保存到缓存（cache_.save_token(token, user_id)）
        # JWT 单点授权登录
        token = token_.gen_token(user.user_id)
        cache_.add_token(token, user.user_id)
    else:
        return jsonify({
            'state': 1,
            'msg': '参数不完整，详情查看接口文档'
        })

    return jsonify({
        'state': 0,
        'msg': '注册成功'
    })


# 用户登录
@blue.route('/login/', methods=['POST'])
def login():
    data = request.get_json()
    print("data=", data)
    try:
        user = session.query(TUser).filter(or_(TUser.phone == data.get('phone'),
                                               TUser.nickname == data.get('nickname')),
                                           TUser.password == data.get('password')).one()

        print(user)
        if user:
            token = token_.gen_token(user.user_id)
            cache_.add_token(token, user.user_id)
            head_url = get_house_image(user.image)
            resp: Response = jsonify({
                'state': 0,
                'msg': '登录成功',
                'token': token,
                'head': head_url
            })
            # 设置响应对象的cookie，向客户端响应cookie
            resp.set_cookie('token', token)
            resp.set_cookie('head', head_url)
            return resp
    except:
        return jsonify({
            'state': 1,
            'msg': '用户名或口令输入错误',
        })


# 普通用户升级为会员用户
@blue.route('/become_superuser/', methods=['POST'])
def become_superuser():
    """
    普通用户升级为会员用户,并进行实名认证
    :return:
    """
    # 验证用户是否输入json格式数据
    resp = validate_json()
    if resp: return resp
    # 验证用户输入参数是否齐全
    resp = validate_params('token', 'nickname', 'sex', 'phone', 'email', 'name', 'identity_number')
    if resp: return resp
    data = request.get_json()
    print("data=", data)
    token = data.get('token')
    user_id = cache_.get_user_id(token)
    print(user_id)
    if user_id:
        user = session.query(TUser).get(user_id)
        if simple_check(data['identity_number'], data['name']):
            user.name = data['name']
            user.nickname = data['nickname']
            user.sex = data['sex']
            user.phone = data['phone']
            user.identity_number = data['identity_number']
            user.is_member = 1
            user.has_real_name = 1
            session.add(user)
            session.commit()
            return jsonify({
                'state': 0,
                'msg': '已成功成为会员用户，您可以开始发布自己的房源了！',
            })
        return jsonify({
            'state': 2,
            'msg': '请填写正确的身份信息！'
        })
    else:
        return jsonify({
            'state': 1,
            'msg': '未登录， 请先登录！'
        })


# 用户修改密码
@blue.route('/modify_password/', methods=['POST'])
def modify_password():
    # 验证用户是否输入json格式数据
    resp = validate_json()
    if resp: return resp

    # 验证用户输入参数是否齐全
    resp = validate_params('new_password_str', 'password_str', 'token')
    if resp: return resp

    data = request.get_json()
    print(data['token'])
    try:
        user_id = cache_.get_user_id(data["token"])
        print(user_id)
        if not user_id:
            return jsonify({
                'state': 3,
                'msg': '登录已期，需要重新登录并获取新的token',
            })
        user = session.query(TUser).get(int(user_id))
        if user.password == data['password_str']:
            user.password = data['new_password_str']
            session.add(user)
            session.commit()

            return jsonify({
                'state': 0,
                'msg': '修改成功'
            })
        return jsonify({
            'state': 4,
            'msg': '原口令不正确'
        })
    except:
        pass

    return jsonify({
        'state': 3,
        'msg': 'token已无效，尝试重新登录',
    })


# 用户注销
@blue.route('/login_out/')
def login_out():
    token = request.args.get('token')
    cache_.del_token(token)

    return jsonify({
        'state': 0,
        'msg': '退出登陆成功'
    })


# 用户上传头像
@blue.route('/upload_head/', methods=["POST","GET"])
def upload_head():
    # 前端上传图片的两种方式(文件上传，base64字符串上传)
    upload_file = request.files.get('head')
    token = request.cookies.get('token')
    # print(upload_file.filename)
    # print(token)
    user_id = cache_.get_user_id(token)
    filename = upload_file.filename
    save_file_path = os.path.join(settings.TEMP_USER_DIR, filename)
    # 保存文件到临时的目录中
    upload_file.save(save_file_path)

    # 将头像保存到用户表中
    user = session.query(TUser).get(user_id)
    if user:
        try:
            user.img = f"{user_id}-{filename}"  # 存储oss上的key对象
            session.add(user)
            session.commit()

            # 将保存的文件上传到oss服务中，并获取到缩小后的图片的url
            head_url = oss_.upload_head(user_id, filename, save_file_path)

            # 将头像的url存到redis中
            cache_.save_head_url(user.img, head_url)

            return jsonify({
                'state': 0,
                'msg': '上传成功'
            })
        except:
            return jsonify({
                'state': 2,
                'msg': '上传失败'
            })
    return jsonify({
        'state': 1,
        'msg': '登录已超时，请先登录！'
    })


# 获取用户头像
@blue.route('/head/', methods=["GET"])
def get_head():
    token = request.args.get("token")
    user_id = cache_.get_user_id(token)
    if not user_id:
        return jsonify({
            'state': 3,
            'msg': '登录已期，需要重新登录并获取新的token',
        })

    user = session.query(TUser).get(user_id)
    head_url = get_user_image(user.img)
    data = {
        'nickname': user.nickname,
        'img': head_url,
        'is_member': user.is_member
    }
    return jsonify({
        'state': 0,
        'data': data
    })
@blue.route('/user_info/', methods=["GET"])
def get_user_info():
    token = request.args.get("token")
    user_id = cache_.get_user_id(token)
    if not user_id:
        return jsonify({
            'state': 3,
            'msg': '登录已期，需要重新登录并获取新的token',
        })

    user = session.query(TUser).get(user_id)
    head_url = get_user_image(user.img)
    data = {
        'nickname': user.nickname,
        'img': head_url,
        'is_member': user.is_member,
        'name': user.name,
        'sex': user.sex,
        'identity_number': user.identity_number,
        'phone': user.phone,
        'email': user.email,
    }
    return jsonify({
        'state': 0,
        'data': data
    })
# 用户更新信息
@blue.route('/detail_resource/', methods=["POST"])
def change_user_info():
    # 验证用户是否输入json格式数据
    resp = validate_json()
    if resp: return resp

    data = request.get_json()

    token = request.args.get('token')
    user_id = cache_.get_user_id(data["token"])
    if not user_id:
        return jsonify({
            'state': 3,
            'msg': '登录已过期，需要重新登录并获取新的token',
        })

    # 根据id查询用户
    user = session.query(TUser).get(user_id)
    user.nickname = data["nickname"]
    user.email = data["email"]
    session.add(user)
    session.commit()

    return jsonify({
        'state': 0,
        'msg': '更新信息成功',
        'data': data
    })


# 用户积分查询
@blue.route('/integral/', methods=["GET"])
def interal():
    token = request.args.get('token')
    user_id = cache_.get_user_id(token)
    if not user_id:
        return jsonify({
            'state': 3,
            'msg': '登录已期，需要重新登录并获取新的token',
        })
    sql = 'select score from t_score join t_user on t_score.user_id=t_user.user_id where t_score.user_id=%s'
    score = query(sql, user_id)
    return jsonify({
        'state': 0,
        'msg': 'ok',
        'data': score
    })


# 关于我们
@blue.route('/about_pandas/', methods=["GET"])
def about_pandas():
    sql = 'select * from t_panda where t_panda.panda_id=%s'
    detail = query(sql, 1)

    return jsonify({
        'state': 0,
        'msg': 'ok',
        'interal': detail
    })


# 查看合同
@blue.route('/get_contract/', methods=["GET"])
def get_contract():
    token = request.args.get('token')
    user_id = cache_.get_user_id(token)
    if not user_id:
        return jsonify({
            'state': 3,
            'msg': '登录已期，需要重新登录并获取新的token',
        })
    sql = 'select start_time,stop_time,content from t_user join contract c2 on t_user.user_id = c2.user_id where c2.user_id=%s'
    cont_details = query(sql, user_id)

    if cont_details:
        return jsonify({
            'state': 0,
            'msg': '已查询到合同信息',
            'data': cont_details
        })
    return jsonify({
        'state': 1,
        'msg': '您的合同信息不存在'
    })


# 查看房屋交易记录
@blue.route('/traderecord/', methods=["GET"])
def traderecord():
    token = request.args.get('token')
    user_id = cache_.get_user_id(token)
    if not user_id:
        return jsonify({
            'state': 3,
            'msg': '登录已期，需要重新登录并获取新的token',
        })
    sql = 'select th.*,td.* from t_house th,t_tradingrecord td,t_user tu where th.user_id=td.user_id and td.user_id=tu.user_id and tu.user_id=%s'
    house_details = query(sql, user_id)
    if house_details:
        return jsonify({
            'state': 0,
            'msg': '已查询到房屋交记录',
            "data": house_details
        })
    return jsonify({
        'state': 1,
        'msg': '您暂时没有交易记录'
    })


# 查看代金券
@blue.route('/cash/', methods=["GET"])
def cash():
    token = request.args.get('token')
    user_id = cache_.get_user_id(token)
    if not user_id:
        return jsonify({
            'state': 3,
            'msg': '登录已期，需要重新登录并获取新的token',
        })
    sql = 'select tl.* from t_u_lucky_ticket tul,t_lucky_ticket tl,t_user tu where tu.user_id=tul.user_id and tul.lucky_ticket_id=tl.lucky_ticket_id and tu.user_id=%s'
    cash_ = query(sql, user_id)
    print(cash_)

    return jsonify({
        'state': 0,
        'msg': '代金券查询成功',
        'data': cash_
    })

# ----------------------------------------------------------------------------------------

# 下订单
ORDER_PAY = 0  # 已支付订单
ORDER_NOT_PAY = 1  # 待支付订单

# 添加订单
@blue.route('/add_order/', methods=["POST"])
def add_order():
    """
    添加订单
    :return:
    """
    resp = validate_json()
    if resp: return resp
    resp = validate_params('token', 'house_id', 'hire_price', 'cash_price', 'enter_time', 'exit_time')
    if resp: return resp

    order_num = uuid.uuid4().hex
    data = request.get_json()
    user_id = cache_.get_user_id(data["token"])
    # total_price = (data["exit_time"] - data["enter_time"]) * float(data["hire_price"]) + float(data["cash_price"])
    order = TOrder()
    order.order_number = order_num
    order.user_id = user_id
    order.house_id = data["house_id"]
    order.hire_price = data["hire_price"]
    order.cash_price = data["cash_price"]
    order.enter_time = data["enter_time"]
    order.exit_time = data["exit_time"]
    total_price = data["hire_price"] + data["cash_price"]
    order.total = total_price
    order.order_status = ORDER_NOT_PAY
    session.add(order)
    session.commit()
    order_info = session.query(TOrder).filter(TOrder.user_id==user_id, TOrder.order_number==order_num)
    # print(order_info)
    if order_info:
        return jsonify({
            'state': 0,
            'msg': '下单成功',
            'data': to_json(order_info.all())
        })


# 删除订单
@blue.route('/del_order/', methods=['POST'])
def del_order():
    resp = validate_json()
    if resp: return resp
    resp = validate_params('token', 'order_number')
    if resp: return resp

    data = request.get_json()
    user_id = cache_.get_user_id(data['token'])
    if user_id:
        order_number = data['order_number']
        order = session.query(TOrder).filter(TOrder.order_number==order_number, TOrder.user_id==user_id).first()
        if order:
            session.delete(order)
            session.commit()
            return jsonify({
                'state': 0,
                'msg': '该订单已删除！'
            })
        else:
            return jsonify({
                'state': 1,
                'msg': '订单不存在'
            })
    else:
        return jsonify({
            'state': 1,
            'msg': '登录已超时，请重新登录！'
        })

# 查看订单
@blue.route('/get_order/', methods=["GET"])
def get_order():
    token = request.args.get('token')
    user_id = cache_.get_user_id(token)
    if not user_id:
        return jsonify({
            'state': 3,
            'msg': '登录已期，需要重新登录并获取新的token',
        })
    status = int(request.args.get("status"))
    print(status, type(status))
    if status == 2:
        # 1查看全部订单
        sql = 'select th.*,td.* from t_user tu,t_order td,t_house th where tu.user_id=td.user_id and tu.user_id=th.user_id and tu.user_id=%s'
        all_orders = query(sql, user_id)[0]
        h_key = all_orders.get('image')
        all_orders["image"] = get_house_image(h_key)
        print(all_orders)
        if all_orders:
            return jsonify({
                'state': 0,
                'msg': '全部订单信息',
                'order': all_orders
            })
    elif status == 0:
        # 2.查看已支付订单
        sql = 'select th.*,td.* from t_user tu,t_order td,t_house th where tu.user_id=td.user_id and tu.user_id=th.user_id and td.order_status=%s'
        pay_order = query(sql, 0)
        return jsonify({
            'state': 0,
            'msg': '有效订单信息',
            'order': pay_order
        })

    elif status == 1:
        # 3.查看待支付订单
        sql = 'select th.*,td.* from t_user tu,t_order td,t_house th where tu.user_id=td.user_id and tu.user_id=th.user_id and td.order_status=%s'
        nopay_order = query(sql, 1)
        return jsonify({
            'state': 0,
            'msg': '待支付订单信息',
            'order': nopay_order
        })

    return jsonify({
        'state': 1,
        'msg': '暂无订单'
    })
