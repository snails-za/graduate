from common import rd, log


def save_code(phone, code):
    rd.set(phone, code, ex=120)  # 两分钟有效时间


def get_code(phone):
    return rd.get(phone)



def add_token(token, user_id):
    return rd.set(token, user_id, ex=3600 * 24 * 7)


def get_user_id(token):
    
    return rd.get(token)

# ------用户头像的缓存-----
def save_head_url(key, url):
    rd.set(key, url, ex=3600 * 7 * 24)


def get_head_url(key):
    return rd.get(key)


# ------用户房屋的缓存-----
def save_house_url(key, url):
    rd.set(key, url, ex=3600 * 7 * 24)


def get_house_url(key):
    return rd.get(key)





# 注销：删除token
def del_token(token):
    #退出登陆删除缓存中的token
    rd.delete(token)

#---------------------------------------------------
# def valid_token(token):
#     # 验证token是否存在
#     try:
#         if rd.get(token):
#             return True
#         else:
#             return False
#     except Exception as e:
#         log.error('验证token失败，错误原因：' + str(e))
#         return False
