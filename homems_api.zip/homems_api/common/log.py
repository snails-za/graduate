import time


def error(content, e):
    log_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))
    with open('error.log', 'a', encoding='utf-8') as f:
        log_str = log_time + ' ----- ' + content + '，错误原因：' + str(e) + '\n'
        f.write(log_str)


def action(url, args='None'):
    log_time = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(time.time()))
    with open('action.log', 'a', encoding='utf-8') as f:
        log_str = log_time + ' ----- ' + 'url: ' + url + ' ----- args: ' + args + '\n'
        f.write(log_str)
