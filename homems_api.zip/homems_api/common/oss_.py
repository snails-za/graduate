#!/usr/bin/python3
# coding: utf-8

import oss2

small_style = 'image/interlace,1/resize,m_lfit,w_100/quality,q_90/bright,3/contrast,-21'


def get_bucket():
    # 阿里云主账号AccessKey拥有所有API的访问权限，风险很高。强烈建议您创建并使用RAM账号进行API访问或日常运维，请登录 https://ram.console.aliyun.com 创建RAM账号。
    auth = oss2.Auth('LTAI4FqbMxbMPrnKSBsu5KSh', ' copeGy6ElAJ0fdleAkYxcOME5TR4CJ')
    # Endpoint以杭州为例，其它Region请按实际情况填写。
    bucket = oss2.Bucket(auth, 'http://oss-cn-hangzhou.aliyuncs.com', 'homems')

    return bucket


def upload_head(user_id, file_name, file_path):
    bucket = get_bucket()

    # <yourObjectName>上传文件到OSS时需要指定包含文件后缀在内的完整路径，例如abc/efg/123.jpg。
    # <yourLocalFile>由本地文件路径加文件名包括后缀组成，例如/users/local/myfile.txt。
    key = f'head/{user_id}-{file_name}'
    ret = bucket.put_object_from_file(key, file_path)

    if ret.status == 200:
        return bucket.sign_url('GET', key, 3600 * 24 * 7, params={'x-oss-process': small_style})


def get_oss_img_url(key):
    bucket = get_bucket()

    return bucket.sign_url('GET', f'head/{key}', 3600 * 24 * 7, params={'x-oss-process': small_style})


def upload_house_image(user_id, file_name, file_path):
    bucket = get_bucket()

    # <yourObjectName>上传文件到OSS时需要指定包含文件后缀在内的完整路径，例如abc/efg/123.jpg。
    # <yourLocalFile>由本地文件路径加文件名包括后缀组成，例如/users/local/myfile.txt。
    key = f'house/h-{user_id}-{file_name}'
    ret = bucket.put_object_from_file(key, file_path)

    if ret.status == 200:
        return bucket.sign_url('GET', key, 3600 * 24 * 7)


def get_oss_house_image(key):
    bucket = get_bucket()

    return bucket.sign_url('GET', f'house/{key}', 3600 * 24 * 7)


if __name__ == '__main__':
    res = get_oss_house_image("h-1-4.jpg")
    print(res)
