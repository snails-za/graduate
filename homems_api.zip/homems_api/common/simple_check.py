# 身份认证
import requests


def simple_check(cardNo, realName):
    url = 'https://zidv2.market.alicloudapi.com/idcard/VerifyIdcardv2/'
    appcode = '4655689266a744bbbb55081572ffb2fa'
    data = {
        "cardNo": cardNo,
        "realName": realName
    }

    resp = requests.get(url, params=data, headers={'Authorization': 'APPCODE ' + appcode}).json()
    if resp["result"]["isok"]:
        return True
    return False


if __name__ == '__main__':
    res = simple_check("610115199710115270", "王举")
    print(res)

# {"error_code":0,"reason":"成功","result":{"realname":"王*","idcard":"610115************","isok":true,
# "IdCardInfor":{"area":"陕西省西安市临潼区","sex":"男","birthday":"1997-10-11"}}}
