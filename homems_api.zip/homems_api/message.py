import json
import os

from tornado.web import Application, url, RequestHandler
from tornado.ioloop import IOLoop
from tornado.websocket import WebSocketHandler

chatdict = {}


def catch_(token):
    return 1


class IndexHandler(RequestHandler):
    def get(self, *args, **kwargs):
        return self.render("chatroom.html")


class ChatHandler(WebSocketHandler):

    def open(self, *args, **kwargs):
        token = self.get_query_argument('token')
        user_id = catch_(token)
        # user_id = self.get_query_argument('token')
        chatdict[user_id] = self
        print("连接成功")

    def on_message(self, message):
        data = {}
        msg = json.loads(message)
        print(type(msg))
        # print(message.other_id)
        other_id = msg['other_id']
        data['other_id'] = other_id
        data['body'] = msg['body']
        data_json = json.dumps(data)
        chatdict[other_id].write_message(data_json)
        # self.write_message(message)
        print('发送成功')

    def close(self, code=None, reason=None):
        pass

    def check_origin(self, origin):
        return True


settings = {
    "template_path": os.path.join(os.getcwd(), "templates"),
    "static_path": os.path.join(os.getcwd(), 'static'),
    "debug": True
}

app = Application([
    url(r'/index/', IndexHandler),
    url(r'/chat/', ChatHandler)
], **settings)

app.listen(8020, address='0.0.0.0')
IOLoop.instance().start()
