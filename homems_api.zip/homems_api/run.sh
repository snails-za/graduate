#!/bin/bash

cd /usr/src
gunicorn -w 3 -b 0.0.0.0:8090 apiapp:app
echo "服务器已启动"
