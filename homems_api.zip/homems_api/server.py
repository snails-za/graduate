#!/bin/bash
# coding: utf-8

from apiapp import app

# diango 重量级
# oddoo 公司集成web后端
# tornado 异步web后端框架
if __name__ == '__main__':
    # app.run(host='0.0.0.0', port=5000)
    app.run(host='0.0.0.0', port=5000)
