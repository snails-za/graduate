#!/user/bin/bash
# coding: utf-8

import os

BASE_DIR = os.path.dirname(os.path.dirname(__file__))

STATIC_DIR = os.path.join(BASE_DIR, 'homems_api/static')

TEMP_USER_DIR = os.path.join(BASE_DIR, 'homems_api/temp/users')
TEMP_HOUSE_DIR = os.path.join(BASE_DIR, 'homems_api/temp/houses')


