import requests

from unittest import TestCase

from common import cache_, rd

HOST = 'localhost'
PORT = 5000

base_url = f'http://{HOST}:{PORT}'

data = {
    'phone': '15829377201',
    'token': 'd9d804fb689f54360919c317e915c6c5',
}


class TestUserApi(TestCase):

    # 发布房源
    def test_e_add_house(self):
        url = base_url + '/api/add/'
        print(url)

        resp = requests.post(url,
                             files={'image': ('3.jpg', open('3.jpg', 'rb'), 'image/jpeg')},
                             data={
                                 'token': data['token'],
                                 'name': '洋房',
                                 'type': '公用',
                                 'address': '北京',
                                 'price': 190000,
                                 'area': 1000,
                                 'discription': '太大了！'})

        print(resp.json())

    # 删除房源
    def test_f_del_house(self):
        url = base_url + '/api/del_house/'
        print(url)

        resp = requests.post(url, json={
            'house_id': 2,
            'token': data['token']
        })
        print(resp.json())

    # 改变出售状态
    # def test_g_change_sale_state(self):
    #     url = base_url + '/api/change_sale_state/'
    #     print(url)
    #
    #     resp = requests.post(url, json={
    #         'house_id': 2,
    #         'token': 'abacab33b10b0539d898f265c6c119fa'
    #     })
    #     print(resp.json())

    # 修改房源信息
    def test_h_change_house_info(self):
        url = base_url + '/api/change_house_info/'
        # print(url)

        resp = requests.post(url,
                             files={'image': ('4.jpg', open('4.jpg', 'rb'), 'image/jpeg')},
                             data={
                                 'house_id': 6,
                                 'token': data['token'],
                                 'name': '海景房',
                                 'type': '海景房',
                                 'address': '我家',
                                 'price': '999',
                                 'area': '8888',
                                 'description': '擦擦'
                             })
        print(resp.json())

    # 查询所登录房东的房源
    def test_k_list_user_houses(self):
        token = data['token']
        url = base_url + '/api/list_houses/?token=' + token
        print(url)
        resp = requests.get(url)
        print(resp.json())

    # 列出所有房源
    def test_l_list_all_houses(self):
        url = base_url + '/api/list_all_houses/'
        resp = requests.get(url)
        print(resp.json())

    # 房源详情（包含审核）
    def test_m_house_detail_info(self):
        url = base_url + f"/api/detail/?house_id=3&token={data['token']}"
        print(url)
        resp = requests.get(url)
        print(resp.json())

