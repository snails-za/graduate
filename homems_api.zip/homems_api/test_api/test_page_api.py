import requests

from unittest import TestCase

HOST = 'localhost'
PORT = 5000

base_url = f'http://{HOST}:{PORT}'

data = {
    'phone': '15829377201',
    'token': '4d2605befd7aaa59b7b1c7e5bdcb34d3'
}


class TestpagerApi(TestCase):
    def test_a_house_display(self):
        url = base_url + f'/api/house_display/?phone={data["phone"]}'
        resp = requests.get(url)
        print(resp.json())

    def test_b_house_detail(self):
        url = base_url + '/api/detail/?house_id=3&token=4d2605befd7aaa59b7b1c7e5bdcb34d3'
        print(url)
        resp = requests.get(url)
        print(resp.json())

    def test_c_insert_collection(self):
        url = base_url + '/api/insert_collection/'
        resp = requests.post(url,json={
            'token':'4d2605befd7aaa59b7b1c7e5bdcb34d3',
            'house_id':3
        })
        print(resp.json())



    def test_d_get_collection(self):
        url = base_url + '/api/get_collection/?token=' + data['token']
        resp = requests.get(url)
        print(resp.json())

    def test_e_order(self):
        url = base_url + '/api/order/'
        resp = requests.post(url,json={
            'token':'4d2605befd7aaa59b7b1c7e5bdcb34d3',
            'house_id': 4,
            'enter_time': '2020-12-04',
            'exit_time': '2021-12-30',
            'hire_price': 60320,
            'cash_price':200,
        })
        print(resp.json())

    def test_f_del_order(self):
        url = base_url + '/api/del_order/'
        resp = requests.post(url, json={
            'token': data['token'],
            'order_number': '806fb83ec50f410f86be1ecd9537fd88'
        })
        print(resp.json())

