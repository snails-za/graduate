import requests

from unittest import TestCase

HOST = 'localhost'
PORT = 5000

base_url = f'http://{HOST}:{PORT}'

data = {
    'phone': '13488144055',
    'token': 'b92d4aa9e5d8156d8b1d359f313fbb11'
}


class TestpagerApi(TestCase):
    def test_a_house_display(self):
        url = base_url + f'/api/house_display/?phone={data["phone"]}'
        resp = requests.get(url)
        print(resp.json())

    def test_b_house_detail(self):
        url = base_url + '/api/detail/?house_id=3&token=4d2605befd7aaa59b7b1c7e5bdcb34d3'
        print(url)
        resp = requests.get(url)
        print(resp.json())

    def test_c_insert_collection(self):
        url = base_url + '/api/insert_collection/'
        resp = requests.post(url,json={
            'token':'3e4cf89b26b69497654f45773d2a7f62',
            'house_id':3
        })
        print(resp.json())

    def test_d_get_collection(self):
        url = base_url + '/api/get_collection/?token=' + data['token']
        resp = requests.get(url)
        print(resp.json())

    def test_e_order(self):
        url = base_url + '/api/add_order/'
        resp = requests.post(url,json={
            'token': data["token"],
            'house_id': 4,
            'enter_time': '2020-05-22',
            'exit_time': '2021-12-30',
            'hire_price': 400,
            'cash_price': 400,
        })
        print(resp.json())

    def test_f_del_order(self):
        url = base_url + '/api/del_order/'
        resp = requests.post(url, json={
            'token': data['token'],
            'order_number': '806fb83ec50f410f86be1ecd9537fd88'
        })
        print(resp.json())


