import requests
from unittest import TestCase


HOST = 'localhost'
PORT = 5000

base_url = f'http://{HOST}:{PORT}'


data = {
    'phone': '13488144055',
    'token': '46fa75d01bfa5b4e17722f06d95580cb',
}

class TestSliderApi(TestCase):
    def test_a_adshow(self):
        url = base_url + '/api/slide/'
        print(url)
        res = requests.get(url)
        print(res.json())

    def test_b_houseshow(self):
        url = base_url + '/api/house_display/'
        res = requests.get(url)
        print(res.json())
