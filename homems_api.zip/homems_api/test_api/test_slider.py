import requests
from unittest import TestCase


HOST = 'localhost'
PORT = 5000

base_url = f'http://{HOST}:{PORT}'


data = {
    'phone': '15829377201',
    'token': '7612d1fb5af220a055246cc1b8d344ac',
}

class TestSliderApi(TestCase):
    def test_a_adshow(self):
        url = base_url + '/api/slide/'
        print(url)
        res = requests.get(url)
        print(res.json())

    def test_b_houseshow(self):
        url = base_url + '/api/house_display/'
        res = requests.get(url)
        print(res.json())
