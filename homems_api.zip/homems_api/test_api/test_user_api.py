import requests

from unittest import TestCase

HOST = 'localhost'
PORT = 5000

base_url = f'http://{HOST}:{PORT}'

data = {
    'phone': '15829377201',
    'token': '19c16453d7f3ca9fd9d017bafc1fe1ba'
}


class TestUserApi(TestCase):
    # 发送短信验证测试
    def test_a_send_code(self):
        url = base_url + f'/api/code/?phone={data["phone"]}'
        resp = requests.get(url)
        print(resp.json())

    # 用户注册测试
    def test_b_regist(self):
        url = base_url + '/api/regist/'
        resp = requests.post(url, json={
            'nickname': 'jack',
            'phone': data['phone'],
            'code': '9357',
            'password': '123456'  # 密文要求（前端）：需要使用hash算法
        })
        print(resp.json())

    # 登录测试
    def test_c_login(self):
        url = base_url + '/api/login/'
        print('phone=', data['phone'])
        resp = requests.post(url, json={
            'phone': data['phone'],
            'password': "123456"
        })
        resp_data = resp.json()
        print(resp_data)
        if resp_data['state'] == 0:
            data['token'] = resp_data['token']

    # 实名认证和成为房东测试
    def test_d_become_superuser(self):
        url = base_url + '/api/become_superuser/'
        print(data["phone"])
        resp = requests.post(url, json={
            'token': data['token'],
            'nickname': "snail",
            'sex': 1,
            'phone': "13488144055",
            'email': "2131@qq.com",
            'name': "王举",
            'identity_number': "610115199710115270",
        })
        print(resp.json())

    # 修改密码测试
    def test_e_login(self):
        url = base_url + '/api/modify_password/'
        resp = requests.post(url, json={
            'token': data['token'],
            'password_str': '123456789',
            'new_password_str': '1234567890',
        })
        resp_data = resp.json()
        print(resp_data)

    # 上传头像测试
    def test_f_upload_head(self):
        url = base_url + "/api/upload_head/"
        resp = requests.post(url, files={
            'head': ('4.jpg', open('4.jpg', 'rb'), 'image/jpeg')
        }, cookies={'token': data["token"]})

        print(resp.json())

    # 退出登陆测试
    def test_g_login_out(self):
        url = base_url + "/api/login_out/?token=" + data["token"]
        resp = requests.get(url)

        print(resp.json())

    # TODO 更新用户信息测试
    def test_h_detail_resource(self):
        url = base_url + "/api/detail_resource/"
        resp = requests.post(url, json={
            'token': data["token"],
            'nickname': 'xiaoming',
            'email': '156865488@qq.com',
        })

        print(resp.json())

    # TODO 积分测试
    def test_i_integral(self):
        url = base_url + "/api/integral/?token=" + data["token"]
        resp = requests.get(url)

        print(resp.json())

    # TODO  关于我们测试
    def test_j_about_pandas(self):
        url = base_url + "/api/about_pandas/?token=" + data["token"]
        resp = requests.get(url)

        print(resp.json())

    # TODO  查看合同测试
    def test_k_get_contract(self):
        url = base_url + "/api/get_contract/?token=" + data["token"]
        resp = requests.get(url)

        print(resp.json())

    # 交易记录测试
    def test_l_traderecord(self):
        url = base_url + "/api/traderecord/?token=" + data["token"]
        resp = requests.get(url)

        print(resp.json())

    # 订单测试
    def test_m_get_order(self):
        url = base_url + "/api/get_order/?status=1&token=" + data["token"]
        resp = requests.get(url)

        print(resp.json())

    # 查看代金券测试
    def test_n_cash(self):
        url = base_url + "/api/cash/?token=" + data["token"]
        resp = requests.get(url, )

        print(resp.json())

    # 获取头像和昵称
    def test_o_get_head_nickname(self):
        url = base_url + "/api/head/?token=" + data["token"]
        resp = requests.get(url, )

        print(resp.json())



