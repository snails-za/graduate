<template>
	<view :class="[prefixClass, prefixClass+'-'+type]" :style="setStyle" @tap="$_click"></view>
</template>

<script>
	/**  
	 * 图标组件  
	 * @description 用于展示 icon。该组件的 icon 图形基于 Webfont，因此可任意放大、改变颜色。  
	 * @tutorial https://ext.dcloud.net.cn/plugin?id=175  
	 * @property {String} prefix-class 自定义字体图标库前缀 - 默认cmd-icon  
	 * @property {String} type 图标图案类型 - 列如：home、add  
	 * @property {String} color 图标颜色 - 默认白色  
	 * @property {Number} size 图标大小 - 默认24，单位px  
	 * @event {Function} click 图标组件点击事件  
	 * @example <cmd-icon type="bell" size="30" color="#654321"></cmd-icon>  
	 */
	export default {
		name: 'cmd-icon',

		props: {
			/**
			 * 自定义字体图标库前缀
			 */
			prefixClass: {
				type: String,
				default: 'cmd-icon'
			},
			/**
			 * 图标类型
			 */
			type: String,
			/**
			 * 图标颜色
			 */
			color: {
				type: String,
				default: '#fff'
			},
			/**
			 * 图标大小
			 */
			size: {
				type: [Number, String],
				default: '24'
			}
		},

		computed: {
			setStyle() {
				return `color:${this.color};
				font-size:${this.size}px;
				line-height:${this.size}px`
			}
		},

		methods: {
			$_click(e) {
				this.$emit('click', e)
			}
		}
	}
</script>

<style>
	@font-face {
		font-family: cmdicons;
		src: url("data:application/x-font-woff;charset=utf-8;base64,d09GRgABAAAAACzsAAsAAAAASZgAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAABHU1VCAAABCAAAADMAAABCsP6z7U9TLzIAAAE8AAAARAAAAFY/d0tZY21hcAAAAYAAAAIiAAAG8vi5tr1nbHlmAAADpAAAI/IAADeY7eoYuGhlYWQAACeYAAAALwAAADYSVnjKaGhlYQAAJ8gAAAAcAAAAJAfeA+VobXR4AAAn5AAAABEAAAGQkAAAAGxvY2EAACf4AAAAygAAAMqKgH2CbWF4cAAAKMQAAAAfAAAAIAF8AK1uYW1lAAAo5AAAAUUAAAJtPlT+fXBvc3QAACosAAACwAAABGw/XD2leJxjYGRgYOBikGPQYWB0cfMJYeBgYGGAAJAMY05meiJQDMoDyrGAaQ4gZoOIAgCKIwNPAHicY2BkYWCcwMDKwMHUyXSGgYGhH0IzvmYwYuRgYGBiYGVmwAoC0lxTGBxeMr5MZ27438AQw9zA0AAUZgTJAQDlXQxReJzt1GVSJEEAROE3hru7LO7u7u7uGnDN/blXqVOwlZN7jJ2ID5rOx0QTFAAZIBUNRmlIjpOIVyQG491E9n6Kguz9dHYoII8kyZAJ7eEzfP/8QEiE3NARvnT975WIXQXb/MleJ+N7pOK7Z8ghN35/flwLKaKYEkopozy2lVRRTQ211FFPA4000UwLrbTRzi866KSLbnropY9+BuKTDTHMCKOMMc4Ek0wxzQyzzDHPAossscwKq6yxzgabbMUn2mGXPfY54JAjjjnhlDPOueCSK6654ZY77nngkSeeeeGVN975iD9IDv9fRfqQ/v3vq0/99k2nJSQNfU6ZTldIW/Y6YzptIdd0CkOexTNCyDe0FxjaCw3tRabTGYoN7SWmJw2lhvYyQ3u5ob3C0F5paK8ytFcb2msM7bWG9jpDe72hvcHQ3mhobzK0NxvaWwztrYb2NkN7u6G9w9DeaWjvsvi3Q+g21PYYansNtX2G2n5D7YChdtBQO2SoHTbUjpj+o4RRQ+2YoXbcUDthqJ001E4ZaqcNtTOG2llD7Zyhdt5Qu2CoXTTULhlqlw21K4baVUPtmqF23VC7YajdNNRuGWq3DbU7htpdQ+2eoXbfUHtgqD001B4Zao8NtSeG2lND7Zmh9txQe2GovTTUXhlqrw21N4baW0PtnaH23lD7YKh9NNQ+GWqfDbUvhtpXQ+2bofbdUPthqP001H4Zar+Nj7/0TBXaAAB4nI17C3wU1b3//M7s7uxms4/Z2d3Jvh+TfSSbbB6zu7N5kJCQkAgEBHkqCIoE8IkoSEHFEqwibcVivYrXVit6tVarSH3VamsRtYK193pL1U+rra2v+m+v3uK195+Z3t+Z2U0CWNvNzJwz5z2/8zu/3/f3OycMyzB/e5Q9yo4wdkZkJIYBPyNaGC7NZEqM0ANKHjJO4KIg+GSf5JOKUlEuEuYQmMxmbfzQIW3cbAbTofveMpneuk9/vrR/f//+/ezI1GwsPv5gtQA+yRxapn8/w5gZ/LH7yHsMy3A4Bhcj4BiKCR+9U5VQv2XYp43CPvU2tjB+xLjh4wULtCcWLNhvBOTGBQtoc5/bpvA5bY4aTWqjX9wkUBqRnyONrAyT4niJz3CiQm7ffNqmwiuvHLyCdY9/skl+5RXaLeh9HyV6WeASvoTIZRQoTBQiAaPayWVTSqKYyCgiR45cMf5frJOW/cNE0RPHABkcAzYrVsdA5kzUwbImfU63YlmWqWMSTCOSBCcvpfgSRZnOaRHvKIg+vCFp4UrtYh4gwRpTDV//6U9h//D4R6fVW8+eTabl89Ng9tlW7XdukfU1+lhR+zMBybZt2bJtNnv/fujrgxvmb4+5sRhMy/Ox7fMh43ObTG6fOg+uXbaRkI3L8DOn8JmXiZ7IZ5AnFg56AC8FnCBG4RQOI/Ngwwu/WgEf9A5omzsvatV8i/PNLc+dwmZaecOT65y96r7yLdpLkIiTc5a8e+mGMcaC/f+ELbBBxs+EmHqmmSkxvUiXZLoFOEs6k4ciXygpiSj4eK8FRD7BQzJdKLX7vRbp70fIpzbBduxlr+wyc4kwfBROJLT3xzUvPOR0u8M8v8sIrnfyfNjt3mUE3Zz53nudxINVyW/DCSR9WE1hSJ4nb6opEqE1wu5Tn5QPLBXePljhbS8TYdJITWQevnKb81BS6OBwQo1RTkb2qYvIA9V7/LiIPw9evChKEwEsGdAeGIDfDMyGbBYwRfsTfVYiybq6pDh1PkWkZwZHgKIB+QtFBPIQj5yVwMnk88DimFJF2SfjepMxZK/ZN0c7MmdfIgeQS7CMEarYoMrsmwOFOftYZgR/NHHEyCSPJnIqwNGR22jGbZS/9XXzHhNg2pkeZhaungQyL489ykoPdEG7PwYyjoF3AjI4zqifDgdnOJ2DDN5JiwsErGGsAyewuogTdXHHbladSVwP+eSdgrkh/Fm4sUa4ExMsreP/r8blqiGf0OfhGMd/ZnNB9NE5awiMzsEnWTOnOJvAcAc+yWwH5BPwMxxWORyK1ZXxTSsl8qTNZdNKNTgsZw38zOZaIdTYVmjryJoRo4GRNSjnhsvFOYDtFOacuG5EnGsGcNHg0ikxSpphp34CyiTI4LqZXAv6+pkimf/S37wJTPIXi2aQe1ovhoGGCfk0E+UTSlSBs0EGmQIWw+JBFAEjg9oDsGhQ+1OlHKHzYaayyYaLmBytZpPvDGjf1b47CPxJ5RTaHsiDsEh7YBA8J5er9mujBUX4L+AHaf4APK/9yahTkXMGbeqYMBM/UaqwUdJeVWAi5TyZl06RKy/AuqdefWod6N/+3Lv9/f2fI1Iu+MEFeBnarb8fztd+xfzTehNEDjUACmsqrr9Ib0Ikf/nl+U2b9Oc/UJ+N1XL4NHTDu+w+lG12g/44VSKdBXZfr3aPdk8vLNf298JZcFavtp+8iQ9YfkKGoTMqa4pqS7qmUaagbjhpJRfxD1CXsLvHPwynAFJh1m+E4x+yfnprf33+efJuKqx+30gn88Mp9WLYvXq1trAfp3+CblamjOtW5GUelV4GilHgnJCDooyTls5QiUwJqF+oEBTsFFPSJYUuciTrdWt6R5sPHID/7ut18hcM3/nt9tP4tlYPcXx9dPQbLuKydwyBaV75uedGLqrhFs0OPLzFtOXBm9bAi1ppbfMjj8AxNrp1aObC3p5zF/CcsGaHCa4+z+7CKh3lYdIL58wZ2ezZdCOYbzlxzJTHJsbc7qcShqvIHhmVPU9pBGdfOefq0utvkGWxRpOpMaYyRggO7b9ZRvtvuP1Kkld/cZXy+uswLxNTvxrFhZCJkstjmRF1HxkdYarr/nn2DIy5kLsZEVvHmVVQR6KOQhWlQKmQTnIwyq4cv4uNark/tsB/RubObvKqY1vgp95s0at11Mwgj2u5lj9ijivW3xBq1boD8IKvkBW0sq4Tqzzs0udcMiQ5L/lk/Ea5KIkI93C+ETfwsoDCnaImiQIglOUk0b96NV6JnTshu1r7bHV/YqfaBFYasiPaLYe1W+D8wzv7tV8dPkxeG7+vv5984/BhtYm8trO/XxcFev9HdLqGdA2S4KUi0lKnozyFtAo7/BC0j2gXKtoRcnAEmuLqnHiTrkBgjnb0EW19AW4bUeeArB2lOqMpTg5i/hS+PsjY9HXagv2k4y4Q/fFeylpU/yNLUYWRmqIEOBT4hR6qQ1Bpilu1w1sfe2wrdG597PctW3ZuabnuOiPQ9pRnETKrbDw9MUGIeUL19WT6ZZc99hje17W0tbVctzPf3p7fuXOiXHnWIT5WH+NJqpRiJvDaV5AOJtTpDl2aUABi9skCT4kioE71+ttLSlHxVaM8R556efy3ZO3puSc136cORB7lBFxea4TH2JGX1TZ23/rT1RVk9Inx38FSwPRE+M7YdUYEnNMqWPmEvgXUqSf1TiWYkpHoQ5naJ1yxbl1u7947b745t379Kf39j565d29u3Tpmgp8n+zmpj6ntntwUztyJdUVchW1MJzODOYdKKWwnI0oChj7ZLPn8GeTediXjp8vDgpqfzqGUxlSJRxjSQ2fYyFHaq0WS6QxOtdxemgZIXylJERSyAsUrTiA/VB9gY0/Mm7dNXQ5/fFKrLUKAcw5CqNbtFnn3U6nGhlSOh2IBrHFWEMWMKL7vpYFfSLeYCqzP5fUDF/NLjdCY8sWsUIACOzI+Sl49Bz+RjT5x34uoubveBreIDboEKKwoQHIVMAnecztEC1G8IEKDyMZ4yF7r4xMuT/tZBQDBnXhGyp7CP6fOIH67j0IwXNEnzOCGadu24XUyxUnDtp5t23rovFlPajuKEuLzKT9J5qJB5gnqysVCSfZHAMO0lOQQKJr/HuUpUEXsqlMe0fVJlLcn0qlExgUtuEDDrMfrlXy+a1o97nhLLJJ1Qh5cHp9P8np5qdHUwnqcHi9YIkI8nU4IYQ7yLSdQfRvkF7ZAdPF7URf/1VBLCK/61bwPpDWXxJLJ+PXBfCjYElwbqbPZPa6Yk4fmBXnwOKMPxOuRLtxJdGliCsw05qxTqOKNgZ+zJDNSFNpL+P0tkEbrS8YvzCMKTUmclJFEeZITUd6dwIloZ8gVepzCieq3isk6NLpMbSQ3u7kuLAXA5YggKGwYaoRzCxlIl6Z33Cv4/Wmfz5NqZttYr0vwgSXmTTY0SN4oB+3QfgJNftBQazU7PGIoHg976yycxWGzA77Fwl/72pPZcFsk3B6+GGKBmlqvO+70tC1pR+I/nsicKsPcp/CgkjmB9bwHDpwiM5yXXFyVST9BvRRknLjW04zCTMfWJjAVKkLEA9ScodShShhTdN5BMDzxioyFWGUKG7LnN3QAdDRILTVoZL1Z0yK5PJ6ox6N2YQo1vDBFLwF7MQEu1W60y92yXbsRLp0oSxZiAw1ltH+j/VFpjCZFPer3pVhftB5zsh0wi+bU11eyeT7q0WVfBVs5GQ/an8gjmcQUYJVKiAnKNuxe7aLLtHshHmDTgThAfPwnYO3UnmHT42+waXLZZep1enIAjtYlOjvV/4WjOt3/oNMqx3Qzi5j1iKl0CUYKPSbKOUohT5JINQuXodhJbo+SCEVwmXalhH9FKekk3igBv0glJTIZh3QslPRMqhexohN8Vb2YocjMAueGB3L1XU0BIdrY3OJL5gVwRVL5rOR21kYyTWJLXeOMtkDp61s8nkSktmY0mE3wrmA9GXZ6Y+Fsjr165crtJJcJx3xOayAaGIqGpSysmDm4gkCmPhR1uR2JYMKfLUxrlQJOi8nUEEyF7OYaHMq0OgdnFZr688fnd5usPmvtJXYxno0INeTnfqlQnH1ZatU1hFyzKr1xdrEg+R0Ox3lyYWBteOhsgLOHwmsHCnIg6DOwB87JK2wIkQ/q2xToyDIGSomSgaNuEYsXQXQP9U24ANEoAe3S6dA3eGBw/rzBAwP9MF3dGe8U83lYBSujfn/3wvmxq7b7u1zwtZkHBvrI9NNPn076Bg7MhF5RbNvept0JK2PzF3aL/tj27aI4oferNoTC9H2BdZd2ElFOl0ScUS+dEc5HpSoFw3mWjQJVaThNX2j+3RdsS3uhG3LRUBqC/lAMusVgJEHAl8nPhmAmGMnU/QO74yKWr28NRRtJOCaGXW45JnoCEcFdiAea4g7tIm8QQpkQCXkNbPe2/m1O6n2zEVFBK1xOoBDkRbQkUmb2qCZrsjSQDJKFweTgl9XvASpIOA5Ltbtb27RcIJkMwG8K2mLCvvPrik+P8rkLLb0YaiGZrqMTfQ1m3X2DxhbwKBgSYPZa0N5XRJiK5s5Vu/PdAN15ckgPVSc55PY+duBC7UUvaVc/wsn/D6+75z+/clDd7k148Ypms2yQdDerLzXTCs1Eae4eBK9Le/AHj1+kPUsaXAi5wfGhy/va2A+A8yTTSQ9ku7OTGHcV0sFl2FSneEdk460osxH1k4rN5DRC9ZM+fII1nEKrVLexJm2u8furllcFWxl9xJjs5/SCmjmRTFMPF86A3wcGhiykybhWaCwDlBvhiB7aBKdWcAqCE444Be2v4VSqnEph3+VGtckoSF5rLI//jBYhr9Gn+gugZcop41vfZYs4RxJT1H1ruGwUAZVYJl1QBGoh4Zj8XheVQmDhcBisHCX4DkaZXpCgxVRjquFMtzxtsyMHv2Z2maHJVovRsT023oY8XWe2iT+w2WvM50HvFUbOe0FiNvtrYIHVZHPa4ApbDXBmm8P22xrBTStw8BxwNbztfeiw6umTMnmE8aKGaWQYIcp2AdqYKDd1Y9MJKX3lIVyRDdEnFc2oWdZDXb4r8cwzXau78HrmmcHlZNfyrSy7dbkeJ8sHn9E+hgPaXLg80ZUPlKBjdONoB5TI8puxzPJtBGODWLD0TGnSn7d2wp9nWN8THnDjln1s5YZL4bhmN261cCP9wcjQkPbb4WHSQ8PJeFW+XIV84Ue+aKH+Tl1L0o+aZJAi1UA0WughOCMGo+AX07kyo8lHeUVEaUNFDBtMsN/csOFmNtGoEMoM87OdoGgPLtxAtE3R8jAOT3Co33d4ESiR+U4PaMf6nTzv7He53WRwwzdZrA1KoyZTXupogKONygtkw8LscDmq2nW2O4qVsPL3L7rIFpEiNRdeWIMBM1WHulCHJk71TnDmFFTZPK3YEHWx56tNVKFTntUV+5naC9rL5MfIs01OAQB24x+Qdzuz6sfGeIgr29n31lvqqzp7uyxm7Q8QMJsmbbTV7DzsvZ5pZTpwBNhpmspi0e9BxcEopTRUXRSioUZO9CxyVa8xy7ZunTHjytaWPAu33yLWQQumaL/fcS2w9enMaqW0OpNOEXLtjvJsgNllhT6VQCzWFo+TP+fbAFpb2rcPbNXev6OuDjqPD16tLvrq8fXKaDadJpBOZ0eVdcfhA6xTrf9UvDWO1wQdJ/ltYl+E3vvIEbVg3FO5qvr9BibzoH0RMWagwkSyLzUhzriixCfMvkSR3pNeon6UqkeNqJZ45CusX72YONVPgGODVM59jFnPP08lnyucUh9GW9l1T3//WH+/jgX/qs+7VffxZRFnM0B9AxLdLzH41fC+UORH3fZT1GYGkY8X4bTOu3s7ETqpI+TRDkjUqSMGlCKP1iVAFcij2r19SwCW9PUvAbK4P9gcCjUHGwoFslj9dV2i47K6RKKOcPSp/pVw2mpY0l8pv/izQF7OB0hpfmnC30DpW49ypYHKQaDaOo+iDe+KM1pH+AooFVxFVRcXABAppKVSGmU0a24og9lk0i6s8dqiktVcE3LVCDVwswPKDVkqitWfCHDzYzzFoDx5kJSzPzJbwWMiUlR9B0vW2DgL2B0/aqBlG+DFbDkWVD8kfu347xHMuuBFF8+7JvYTqntldUjfxSftJ2R0iShTw67IZnR7xMAg1CqR6GZSD0GIzWYovPSj3cbpxKcyHaehQCVou4KmH91+OIM8WL3Hf2nlXLaEe9hj9npDnjpwOTm3KR49h7Nba3xgc9jNHrPP4RdtJrMdICo4RItgizqdDifYLHbYOKjdPwhvDTi8rM0+Wlc3Q3vf5/d5XLzV7DQ700G7w2J1usw27WOfxe7jbXaWddZ6hVqrYIcw+BwcB5PzNblXyCgyjyYZLyGXSQov8fuOHRsaHoaHjh3bMxwkR4bU58i1amGI9KjPVXUe9b02MHOpbymTRriILIhCwHBiShbDg1m5ZATW06CU5lBY5SmupFdaKYlyOyJwv4sWojCUvojsoq6y2OIpjFzVXHTXWEWbJR/bWh+020nN9ELrlbPnH1zJxeuCkI7ZLEvumTWwsamlqwbAYttaS2pEk+msYNvuRfllnLV3BiZbOb+1hi80XTW3wOfFjmkxXI9BR4JfdfD02Ve1FKbbwReo3xpvecFitXW0NG0cmHXPErPFQuwzpnPcsubFN7QHlpnNdVbWXpUjfqSbD3kmiAg6Wd1Eo/wBUUCtjuKPt+HKF9wRu8Wajtt9NXAwaHf7tDk1Pjsc1M7xBXk7Rsn0eNpq0d52KyGf9raZJdepT0IcZoR1O/vfJ/YN47iqsmhrt6DcmipYq/tbBuNxhiWIyprVXbIYitzerAKgZDP0mUHWj6BaMl70DEiTbvXQdrSwB+n9rKbBzzHPKJFRrgZaIcI/S0qVJrIl0jNdPdQLV00H9dvfZk6QrVRDUHyKKgq4oqFyeWO0RVz7SJ0u6GHpfhRMWfI2wqZw4WoXTizxrCED4GZMdriEGqukvm5YlcSmXQg3k0etZu2440fZMsH1r5WNtY5yQDtu4Uy1greG+KOS+urkgtd4sIPdkOe3ss+wXbqM0vfQFKrJTErJk0nXu5ADKSNb/DHw9wB1kqJG81uMrVLBj0ycBydBFYe5GEPzsYSs74Qo6YFv1daaOiGx/zvfaOvU3rpHiNm9jTVzbU7+NmfA4nK2mnb/pa1x2y58msRGp58Qq8fn5sxOxeU3ucN+sztNeIfdYwf8AOf/mkTH/m+2dYB07/5vtnIlTz14rnfFzRLritSZ7NBw9e6vfdrauH13bS10ErezWu9LRG8q4r/YKRJi83h5zuyq2n1Un3jxyxnBkF8U68hcRsaZQqUGurNF9z1LiigZGONX/WT5ENwwtJys3rlzNYIFbXNDB5lHU7XN/cs5mmouNsANmNrf3z+0HGD50JEjDXRmtDk0gZAz+48cycqINAy58Rjy9QK0j3D1mBEgZtImzkLoFNgMa5TSG5fQUe2z5eIll2nvXLTOfN46iFwBVlWZb1505gcrFpgXL/vQC9wWiKw917b+Eu2djRcJZ2ufwcKzPzhzkXm+/pxiZ2aYlcwFzOW4Wi10V8rCoZJO082pdEbiUTKhrVRSEAj4RUXk/CgEMavUC3JRylAWwJIYICbkqEmMLWAg+WS0aIHDGhggTqQVRHbKQpzwt7KbOFvPU70er/aZIPQ+1WPjli7VUwQBrNWUq2UPZ3GeNozC29M+KqfcfHZPlnen5DXtesZptSdnfDDVB19HcU583OuZ2r7HO9l+tUftszVtaTefuSnr5lPy6N9rvNKrMRz4jyk+/B9CFVQZNt5D+j5GmJ76oMc4MroCqW5hyFWkCu9d2nb4cPvGmfDlQZjXpb7aNY/MhGyEtEayQF6gmW0bNRbqtOWYQ+Z1wX5tubE/VJnHJ9hFKAMN/zdKXQuXKmVS1ANAl6HPK5rTuusiCorZMum34aNQ8ZdVZeVEhPVHiih1eR7ijevPDDWffeEMq/Z22+bmXK55cxvErYhy+hYTsrgvnsv15XKaLd7UhCH8T0J/f98r7Glt21Nv6Rtd0youKNfV7cmam1quyDebG24SA0ZVBEskBLR4X04rVSNHK5Hq/sAIOxfxZQitFbSADLHpkyZ271OVYyu6s4y8yV111llXcWOZKGkIN2g+8+LensUW7Qjcqx4jDWStcNZmQjafJag3RZB82TC5ROiZDzC/B1NIwySmfwrnrZZxo9VFLediJsGxlblixYRiNrgYjFk0yCnzfgt7YLraNZ0jp3cTZdo8siWsjobhqGNRZ+fiWnhcfSmehi85rl66ZLtjiy1N/tV5993qv3SfTmj554eGvl6eCTCzrO6AdJwoSy4GuHiJ+lK40fB9vqTjbONsh8wodJYnYeyErlP0Gc1DCRIshcFigiZwCVaiuxcyCAkB7gg2B0PNoQal3OgQhJAgfNZQVs5A4KldQD7oNNUH1DftYJjxn44OCx6PcDW5Jq9elv9aCDFtEMpnKDvAE/bgtQOUM7BumTRpD9VFp9FUIBmIx0FbAmbt/0+eZ9KxEJMy/LEIHJWMfiaESlOfXLGp6QaBvsOCuSzpW7WDZXes6nv55b5lu+qlXcvGxoyUsbFlu6T6Xcsw50EytnLVGDl3bOxcWDp79lLoJ2OrVo6RfuMN0/V9oif1/qkPukb3QlNrOqifm0iwNkgpMVR/isyZMzKHsl0WIIGUUkSWUz85jBr/ZfXQJdeadl37vUdy2qNtD37/9gvD0hXa60Q5oP1iT/48Nqi9pz5J+hpuvLFDmw8PfXqj61tP/8ur2lUwpn0JfnzTTTofP86+wi5kmpkyXaHUSqRMxEtp3dHa3kN08zqF+pSvOF9pmrkqLhV5SpQ9WntWt3ZHqQ8ukPrkYFDuG+prD0HCD6vjLZbz6/El1I5pclDdQaY15egZqtwFRMFn0zSCKeeT17t7a8q1c0raLYBFh6fTVqbXk1AobSlbonHtFnwd7msPBtv76oea6CGuJnxKEzFDvh1gX8V1IjHd+he1ELp74SJOQkW/JUpQ5Pt7iL6Viiorhog2qUMIPaXXwLTsz8wR75/XWxMNCW79R96I3ea8v4F1xjP8a//uScddbOMDrprPHHY2/bw76X4+SuyO77zliVjXnsdFhN/Ax0KQld4SRFF4q54NZtKuB/7iSwWI7fLLbWxdynv8e670vzmSng8vtlovft+TdNyXZP38a6/xfjbJTMXpFOczAhqK9DzDKFtYoG4ge9ggPfynRskeY8+rsmdsYM5mlLUzmTNQd+q23CnmvKAvvAwaQRlO35s34kolGYqFdMasu1H0xYs8iHSj8WKhlJmSTph0EcFH2njSs2I8/7t8oZDPpRoh05ALJyLxHNpJPv+xvsHBvly5e5qixVONjalcvtDavtjIo8XOUaZNU3K0EPxMb5AQ+txqHCUDZ/7K3dtaco2rLzmvIRc/vSE/J54TlT5FPNZ335P39eU6vnH6GXuUxam1G9amc/IVu6/MLzbyc4l5jc1z7ure86295ZxedlKOGmfBKJrso/T16kYAtXKp1MpQ4xehFaVcAnP8Xg4syQzoVBInTukUeqBd34RIpmWfF1Z628vtXkh5fT6vdpcgh7Q3uubOQFUI6TDN9Wpv+hWfdpcX8mRuV+dcQuZ2YgFPIpXwkExHhjynvRGSBSyADWAzemsrvT4sTFUqtulT/NqbXpoYPthF61daEeJeb1yIpNPV/ahf6t/nY3Ioj2dQSy+VSLbgR03DiesF/eCgcdrMhSwSwTlF3Fx1TWVOcEmkdVmuUKqAzFEzOZOSRfY0LdokPRwIhwMPS03wOx1lqO/6PQ/XOp21D3v88LuK+0QuzwJAAKK7djwxD17h+nq49bRua1xwObXHb3/5h8GdQik+FleEsSAgWNE2YXPzHDttYfeYO1Qz5qANwW5sUNuEjVQbPAR8XIp5MFNJacWreK/lX1dNnGklzyFmpueLUHCyVHjKggSvvy/MuLrP84EwsH0GeXe++sv580njlLNEJlw9WbSFGEFCVGmW26jvg7Tr+xZtsu5DQC7IE0E/V+yTzJXwzfvYfarzXJZztg8uHAq6GslK8Inzisqmkjwvd+65g38Zgd+sXHB8AO5ArB1p9mZl0RuoGVw4UOyY6/V6hXkXQu2WkZEteFfx2QGcv5SO+ekRFsvkQOj2JEUZ+mDo/hbaYxIgMj4PfEvAZHWX562cH+FbyHLwzpHP7Or9yqbmZjEwj507/mV2ZKl2a7zgz3eE6kK1c1fCuqVLtbvP2LHULzbn8t0IOEZV2+zZ1XMWVyK+8TEBJmGMBBJFKkcRhftkoQI6BJlFszVFt95En8TJvCTgzW7T/mTpW9Fv1t4fKpNUEL4ZqmeVoR9rF5QI0V5mI9mw6YKR/v7DfX3kxVC+qysf6lfPD9GzpSFyi3oJuWmBt67OKzyHE75b22TQ5BH2sokzTROYtaSfacokLLpXDRW0xOunco6szz/xRP78PlgTSLFsKqBuDtSbEEH8/vfkhnfIq0aulgETiQa0ZCBKMITfYNindcALfZNnTQxbPoA2fBczdNKJPWrA46SgjUksZoQIlUNgOFl0pujmAUwVF8a2jn7A45SjdQ6bpX3jlkvbsclLvrIBDrFLWptbDm3ddqiluXWJydLw9ft3Zy3aaWTFzJkriP68O5QPh/MIlpRTdsFUP+9J1ksJt6t7JukvLHlv46VjhIxduvG9JQ77rDPYxbNtsKnaDsCK+wMtxZYgUPw0xXd9EHFIMyJ3qkFdVCtIU33YRdFPnYJ8QXfCV1wp1KkpZIoK+6KtRfxOKa15qXIoZOCjTAHustcGJUAQzTs0r4P31MJHDh6OP/EEaRe9NdP60iWssAALYoWBHpMUBLlW2+HwYHl4yOHxOLQbZ901y8De77IrdMzJ67sPTtDdlLLIcwpPTUP9dAcHsXRTU3r/8eN37376aWihL2QzNKW0J1JNsJ8t7LdqpjNheAE0zWqq4IZ3yUeVdhmobjpgsyxtVIFP92NFbGD/pwu++vTTXz2hMXUdNnXmief5aTt1TJr6gIXJxqpjRLoVkV6YUTRYpBilumJKwgPU5ZWKXX/06K7L77gD+jAeS+0iG5d1jhAy0rls48t7nzWZnt17+T6W3Xc5ORvqY9qf4/VwPfnu9Zy2YAHwu2Kp61OxZRvJIIx0Yq0BsnGcfXbv3mfZAayB9Spn9Y/pfF5Lz2OiaYwqQBRENIuPKq96Fmtvv6H9bfovfgmL68iXj5Rnipr3b+rfEnDnX8lpyyr1q3jrH6GtfwpU/TPYqdLvH3U6I8VT+nliWPrg4N9Ice7YXbP+TH7cVcX4xr75Kbvmp26Rn7IZXv1fhsnzqtRFJ+m+ZpnIsFa7bVS7DdaOwqOVcO1JZ21Df/+sLXX3feEZ2wjcoG3+B+ef7+uf0HnsPqD7JPoeCSJFGBkdpclOHM8RHE8B9ZtNt1er/08wzMxnzmRGmY3MNqSOt72Q5Pz0Yey2Ji2ZKZFSphrRlUCGSj6aokxEqoUnUsSJCCII42zzRFxvZKIAO8NuvxK83vtrnDV4HXQIDrzuDEfAXee6JJEEIezJgT/hxysBgXQAr9FILhzORW6BeEscr/tAKkh47fPEpTgPkO5IXyRImaRAGrobGqFpRhNed1rs19p9c6w2m8tmAxvtxDHs5nl3rdt9DSpir9PjuYP3+5N+/20C7SSw2Reh/XTU0T7inlAyWZSkVRUck05/25v0+ZJ0y/2FJO2g6ZRzEtQH/HfPSWSqRyEEXua/8DTEG5UTD7bhL+aHXwuVQw2wQzsCBTr/tRPjqUU9lkYbfTozwpzFrGeuYHYy32DuxPG1+yO6w4XiQ2HqC9AzCdRyoP+lYJ76kvJThysa74gn/XDCC/WmO6k27KX/JXPCG1uiUJM6ZltwNYL+5gTjhS5NfReSItUT3wjjcLuDbrfDCOANt+NLGKUPNTAZJ/9msdjX2cVarmadQ1SvtWCIb5hm88NvbZyp1+x32iymXptfu42GnN9upM61+W29WNzpN/eaOPiSXeR6zRa/n+s1WdRPTKJjnZUzYZl1Do5cb/Y71tk4s5HKjnz+WCB4wpBft2NbiJ1ouyZtbGr7xFlpn7br4NQtNLRbLDS11kS22sw2/AoLBhfbfFM/yuGHX+vD99kcnLWz+lFY3fioSdkV1n1UaUQm9ERV5dhUG116XFsVohCLy4fDHv7yaNH04q23vmhyiS4wv/fQQ++Zze+wATYQIaU1O4ZufZFlX7y11uWqpRnvPfS9dxnm/wCrinufAAB4nGNgZGBgAGIPL+0F8fw2Xxm4WRhA4PrsWQUI+v8MFgbmUCCXg4EJJAoAF8cKAwB4nGNgZGBgbvjfwBDDwgACQJKRARWkAABHagLNeJxjYWBgYBnFgwYDAD0/AZEAAAAAAAAAAEAAagCSAKgAvgDUAOoBNAF0AdgCHAJaAtADDgMiAzYDSgNeA5wD4gQEBDgEkgTMBP4FPgVwBcIGAAY0BlIG4gcQB5wIJAhKCLII4Al8Cb4KLApUCrAK4gsmC3wLwAvuDFQMlAz4DRQNUA2oDgAOgA6gDxwPUA+mD/wQeBC8EPIRohHWEkQSfhLIEyYTZhOoFBIUdBSKFSIVkhYSFioWcha0FvwXNheyGAIYLhhSGKoYyhkGGRgZOhlSGYwZmhpSGpobmBvMAAB4nGNgZGBgSGFYyMDHAAJMQMwFhAwM/8F8BgAj0QIqAHicZY9NTsMwEIVf+gekEqqoYIfkBWIBKP0Rq25YVGr3XXTfpk6bKokjx63UA3AejsAJOALcgDvwSCebNpbH37x5Y08A3OAHHo7fLfeRPVwyO3INF7gXrlN/EG6QX4SbaONVuEX9TdjHM6bCbXRheYPXuGL2hHdhDx18CNdwjU/hOvUv4Qb5W7iJO/wKt9Dx6sI+5l5XuI1HL/bHVi+cXqnlQcWhySKTOb+CmV7vkoWt0uqca1vEJlODoF9JU51pW91T7NdD5yIVWZOqCas6SYzKrdnq0AUb5/JRrxeJHoQm5Vhj/rbGAo5xBYUlDowxQhhkiMro6DtVZvSvsUPCXntWPc3ndFsU1P9zhQEC9M9cU7qy0nk6T4E9XxtSdXQrbsuelDSRXs1JErJCXta2VELqATZlV44RelzRiT8oZ0j/AAlabsgAAAB4nG1TZ5fbNhDU+EiKqk6c3uP0xhQ5vTnF6b33AoErEhEIMCg6X359lpB0Lx/C9wjOoMzu7IKjC6P9Mx39/1PjAk6QIUeBMUpMMMUMcyywxEXcgBtxCTfhZtyCW3EbbscduBN34W7cg3txH+7HZTyAB/EQHsYjeBSP4XE8gSfxFCo8jWfwLJ7DClfwPF7Ai3gJL+MVvIrX8DrewJu4irfwNt7Bu7iG9/A+PsCH+Agf4xN8is/wOb7Al/gKX+MbfIvv8D1+wI/4CT/jF/yK3/A7/sCfEFhDogaNpqKuK6mc1DQXWjWmkmQCuemeaNqEqXDOnla1PTUHOMzO9tCppg3lHsc+W5PW47W2ckt1ubZ22wm3na2j1hQqrXwopdBkauEKKTpyYi5bkttjBkx2zpoU65wM0RZHkuJNjyz2uRyCzXn0dFDJE5lJR7UKlRSuXg562gp2qm2syyPNhh0T+juy2X/ILeg6OzdCc6Zme0JnNN0oTZWItbKTBKWtaZ5QQ4ackmUif/XNHhg63YPeHGb8rtmr7FRNtmDIMYqN1TUXeWMNZ2i1dXlLwoWsJd1nre0oV51oqFR9aw1V14s9WOrBvlGmqdZWh2zIMxvKmg1VyDqh9LgTfdUrk3Vk4rgj71kn7/jwWWbY4MLEbk1cm9SOvBfRU57Es16Ls3IYkmLvaFc4Guo0c9STCNWwVnhOVLalpxA4Dz/2rXBUrfL0XfrW9n3KTzTVav5fujgn3JPAS3GzGSqVRLcUZJt7G02d+SAcD7af+OBIdHzkJIgm49fPAnuoVOCOyUsJ8x7Fp1tnY9Mu0xSLkOPaUB6c8G0R+9Rtdury1Ib5zurYUcXS0U8PxG42swPsdfQTwTfhLCjpiyEhdpiu6jg1qlqd8I9z0cc1R5DhcPPKI58M8QanV/inIndcP59ejQ9oNPoXdg9YhA==") format("woff");
	}

	.cmd-icon {
		display: inline-block;
		font-family: cmdicons;
		font-style: normal;
		font-weight: 400;
		font-variant: normal;
		text-transform: none;
		text-rendering: auto;
		text-align: center;
		line-height: 1;
		-webkit-font-smoothing: antialiased;
		vertical-align: middle;
	}

	.cmd-icon-add::before {
		content: "\e960";
	}

	.cmd-icon-add-circle::before {
		content: "\e901";
	}

	.cmd-icon-subtract::before {
		content: "\e962";
	}

	.cmd-icon-subtract-circle::before {
		content: "\e961";
	}

	.cmd-icon-align-center::before {
		content: "\e902";
	}

	.cmd-icon-align-left::before {
		content: "\e903";
	}

	.cmd-icon-align-right::before {
		content: "\e904";
	}

	.cmd-icon-arrow-down::before {
		content: "\e905";
	}

	.cmd-icon-arrow-left::before {
		content: "\e907";
	}

	.cmd-icon-arrow-right::before {
		content: "\e908";
	}

	.cmd-icon-arrow-up::before {
		content: "\e909";
	}

	.cmd-icon-bell::before {
		content: "\e90a";
	}

	.cmd-icon-blocked::before {
		content: "\e90b";
	}

	.cmd-icon-bookmark::before {
		content: "\e90c";
	}

	.cmd-icon-bullet-list::before {
		content: "\e90d";
	}

	.cmd-icon-calendar::before {
		content: "\e90e";
	}

	.cmd-icon-camera::before {
		content: "\e90f";
	}

	.cmd-icon-check-circle::before {
		content: "\e910";
	}

	.cmd-icon-chevron-down::before {
		content: "\e911";
	}

	.cmd-icon-chevron-left::before {
		content: "\e912";
	}

	.cmd-icon-chevron-right::before {
		content: "\e913";
	}

	.cmd-icon-chevron-up::before {
		content: "\e914";
	}

	.cmd-icon-clock::before {
		content: "\e915";
	}

	.cmd-icon-close-circle::before {
		content: "\e916";
	}

	.cmd-icon-close::before {
		content: "\e917";
	}

	.cmd-icon-credit-card::before {
		content: "\e918";
	}

	.cmd-icon-download-cloud::before {
		content: "\e919";
	}

	.cmd-icon-download::before {
		content: "\e91a";
	}

	.cmd-icon-edit::before {
		content: "\e91b";
	}

	.cmd-icon-equalizer::before {
		content: "\e91c";
	}

	.cmd-icon-external-link::before {
		content: "\e91d";
	}

	.cmd-icon-eye::before {
		content: "\e91e";
	}

	.cmd-icon-file-audio::before {
		content: "\e91f";
	}

	.cmd-icon-file-code::before {
		content: "\e920";
	}

	.cmd-icon-file-generic::before {
		content: "\e921";
	}

	.cmd-icon-file-jpg::before {
		content: "\e923";
	}

	.cmd-icon-file-new::before {
		content: "\e924";
	}

	.cmd-icon-file-png::before {
		content: "\e925";
	}

	.cmd-icon-file-svg::before {
		content: "\e926";
	}

	.cmd-icon-file-video::before {
		content: "\e927";
	}

	.cmd-icon-filter::before {
		content: "\e928";
	}

	.cmd-icon-folder::before {
		content: "\e929";
	}

	.cmd-icon-font-color::before {
		content: "\e92a";
	}

	.cmd-icon-heart::before {
		content: "\e92b";
	}

	.cmd-icon-help::before {
		content: "\e92c";
	}

	.cmd-icon-home::before {
		content: "\e92d";
	}

	.cmd-icon-image::before {
		content: "\e92e";
	}

	.cmd-icon-iphone-x::before {
		content: "\e92f";
	}

	.cmd-icon-iphone::before {
		content: "\e930";
	}

	.cmd-icon-lightning-bolt::before {
		content: "\e931";
	}

	.cmd-icon-link::before {
		content: "\e932";
	}

	.cmd-icon-list::before {
		content: "\e933";
	}

	.cmd-icon-lock::before {
		content: "\e934";
	}

	.cmd-icon-mail::before {
		content: "\e935";
	}

	.cmd-icon-map-pin::before {
		content: "\e936";
	}

	.cmd-icon-menu::before {
		content: "\e937";
	}

	.cmd-icon-message::before {
		content: "\e938";
	}

	.cmd-icon-money::before {
		content: "\e939";
	}

	.cmd-icon-next::before {
		content: "\e93a";
	}

	.cmd-icon-numbered-list::before {
		content: "\e93b";
	}

	.cmd-icon-pause::before {
		content: "\e93c";
	}

	.cmd-icon-phone::before {
		content: "\e93d";
	}

	.cmd-icon-play::before {
		content: "\e93e";
	}

	.cmd-icon-playlist::before {
		content: "\e93f";
	}

	.cmd-icon-prev::before {
		content: "\e940";
	}

	.cmd-icon-reload::before {
		content: "\e941";
	}

	.cmd-icon-repecmd-play::before {
		content: "\e942";
	}

	.cmd-icon-search::before {
		content: "\e943";
	}

	.cmd-icon-settings::before {
		content: "\e944";
	}

	.cmd-icon-share-2::before {
		content: "\e945";
	}

	.cmd-icon-share::before {
		content: "\e946";
	}

	.cmd-icon-shopping-bag-2::before {
		content: "\e947";
	}

	.cmd-icon-shopping-bag::before {
		content: "\e948";
	}

	.cmd-icon-shopping-cart::before {
		content: "\e949";
	}

	.cmd-icon-shuffle-play::before {
		content: "\e94a";
	}

	.cmd-icon-sketch::before {
		content: "\e94b";
	}

	.cmd-icon-sound::before {
		content: "\e94c";
	}

	.cmd-icon-star::before {
		content: "\e94d";
	}

	.cmd-icon-stop::before {
		content: "\e94e";
	}

	.cmd-icon-streaming::before {
		content: "\e94f";
	}

	.cmd-icon-tag::before {
		content: "\e950";
	}

	.cmd-icon-tags::before {
		content: "\e951";
	}

	.cmd-icon-text-italic::before {
		content: "\e952";
	}

	.cmd-icon-text-strikethrough::before {
		content: "\e953";
	}

	.cmd-icon-text-underline::before {
		content: "\e954";
	}

	.cmd-icon-trash::before {
		content: "\e955";
	}

	.cmd-icon-upload::before {
		content: "\e956";
	}

	.cmd-icon-user::before {
		content: "\e957";
	}

	.cmd-icon-video::before {
		content: "\e958";
	}

	.cmd-icon-volume-minus::before {
		content: "\e959";
	}

	.cmd-icon-volume-off::before {
		content: "\e95a";
	}

	.cmd-icon-volume-plus::before {
		content: "\e95b";
	}

	.cmd-icon-analytics::before {
		content: "\e95c";
	}

	.cmd-icon-star-2::before {
		content: "\e95d";
	}

	.cmd-icon-check::before {
		content: "\e95e";
	}

	.cmd-icon-heart-2::before {
		content: "\e95f";
	}

	.cmd-icon-loading::before {
		content: "\e967";
	}

	.cmd-icon-loading-2::before {
		content: "\e966";
	}

	.cmd-icon-loading-3::before {
		content: "\e963";
	}

	.cmd-icon-alert-circle::before {
		content: "\e964";
	}
</style>
