<template>
	<view class="margin-top zaiui-goods-list-box" :class="show?'show':''">
		<view class="cu-list menu-avatar">
			<block v-for="(item,index) in list_data" :key="index" >
				<view class="cu-item" >
					<view class="cu-avatar radius lg" style="width:165px;" :style="[{backgroundImage:'url('+ item.image +')'}]" @tap="showdetail(item,index)"></view>
					<view class="content" style="left:190px;">
						<view class="text-black text-cut" @tap="showdetail(item,index)">
							
							<text>{{item.name}}</text>
						</view>
						<view class="text-gray text-cut text-sm" @tap="showdetail(item,index)">
							<block >
								<text class="cu-tag radius sm">{{item.type}}</text>
							</block>
						</view>
						<view class="text-gray text-cut text-sm zaiui-tag-view" @tap="showdetail(item,index)">
							<text class="text-red text-price text-lg">{{item.price}}</text>
							<text class="text-gray through" v-if="item.price">￥{{item.price}}</text>
							<block v-for="(items,indexs) in item.discount" :key="indexs">
								<text class="cu-tag line-orange radius sm">{{items}}</text>
							</block>
						</view>
						<view class="text-gray text-cut text-sm " style="position:relative;left:">
							<block >
								<text class="cu-tag line-blue radius sm">{{item.area}}</text>
								<text class="cu-tag bg-blue radius " style="float:right;position:relative;left:-62px;" @tap="showdetail(item,index)">查看</text>
								<text class="cu-tag bg-red radius " style="float:right;position:relative;left:-62px;" @tap="likeTap(item,index)">收藏</text>
							</block>
						</view>
					</view>
				</view>
			</block>
		</view>
	</view>
</template>

<script>
	import _tool from '@/static/zaiui/util/tools.js';
	import { likehouseinfo } from '@/api/homes/index.js';
	
	export default {
		name: 'goods-sort-list',
		props: {
			list_data: {
				type: Array,
				default: () => {
					return []
				}
			},
			show: {
				type: Boolean,
				default: true
			}
		},
		methods: {
			//查看
			listTap(data,index) {
				this.$emit('listTap', {
					data,
					index
				});
			},
			showdetail(data,index){
				// console.log(data);
				this.$store.state.selshopid = data.house_id;
				this.$store.state.houseimg = data.image;
				uni.navigateTo({
					url: "/pages/goods/goods"
				})
			},
			//收藏
			likeTap(data,index) {
				const token = uni.getStorageSync('token');
				var params={token:token,house_id:data.house_id};
				likehouseinfo(params).then(res=>{
					if(res.data.state==0){
						uni.showToast({
							icon: 'none',
							position: 'bottom',
							title: res.data.msg
						});
					}else{
						uni.showToast({
							icon: 'none',
							position: 'bottom',
							title: res.data.msg
						});
					}
				});
			},
		}
	}
</script>

<style lang="scss" scoped>
	.zaiui-goods-list-box {
		display: none;
		.cu-list.menu-avatar > .cu-item {
			height: 218.18rpx;
			&:after {
				width: 0;
				height: 0;
				border-bottom: 0;
			}
			.cu-avatar.lg {
				width: 181.81rpx;
				height: 181.81rpx;
				font-size: 2em;
			}
			.content {
				left: 236.36rpx;
				width: calc(100% - 94.54rpx - 59.99rpx - 119.99rpx);
				line-height: 1.7em;
				.cu-tag.sm {
					display: inline-block;
					margin-left: 0;
					height: 29.09rpx;
					font-size: 14.54rpx;
					line-height: 29.09rpx;
					margin-right: 9.09rpx;
					margin-bottom: 9.09rpx;
				}
				view:first-child {
					font-size: 29.09rpx;
					display: inherit;
					align-items: inherit;
				}
				.through {
					text-decoration:line-through;
				}
				.zaiui-tag-view {
					text {
						margin-right: 9.09rpx;
					}
				}
			}
		}
	}
	.zaiui-goods-list-box.show {
		display: block;
	}
</style>
