<template>
	<view>
		<!--标题栏-->
		<bar-title bgColor='bg-white'>
			<block slot="content">确认订单</block>
		</bar-title>
		
		<!--收货地址-->
		<view class="margin-tb-sm zaiui-view-box">
			<view class="bg-white zaiui-card address-view">
				<view class="cu-list menu-avatar">
					<view class="cu-item">
						<view class="bg-grey icon-view">
							<text class="cuIcon-locationfill"/>
						</view>
						<view class="content">
							<view class="text-black">
								<text>{{userinfo.name}}</text>
								<text class="margin-left">{{userinfo.phone}}</text>
							</view>
							<!-- <view class="text-gray text-sm flex">
								<view class="text-cut">重庆市渝北区XXXXXXXX</view>
							</view> -->
						</view>
						
					</view>
				</view>
				<view class="address-line"/>
			</view>
		</view>
		
		<!--商品信息-->
		<view class="margin-tb-sm zaiui-view-box">
			<view class="bg-white zaiui-card goods-view">
				<view class="margin-bottom-sm title-view">
					<view class="cu-avatar sm round" :style="'background-image:url('+userimg+')'"/>
					<view class="title-box">
						<text class="text-black margin-right-xs">{{userinfo.name}}</text>
					</view>
				</view>
				
				<view class="goods-info-view-box solid-bottom">
					<view class="cu-avatar radius lg" :style="[{backgroundImage:'url('+ houseimg +')'}]"/>
					<view class="goods-info-view">
						<view class="text-cut text-black">{{houseinfo.name}}</view>
						<view class="text-sm text-gray">{{houseinfo.description}}</view>
						<view class="zaiui-tag-view">
							<text class="cu-tag line-blue sm radius">{{houseinfo.type}}</text>
						</view>
						<view class="goods-price-view">
							<text class="text-price text-red text-lg">{{houseinfo.price}}</text>
						</view>
					</view>
				</view>
				
			</view>
		</view>
		
		<!--商品价格计算-->
		<view class="margin-tb-sm zaiui-view-box">
			<view class="bg-white zaiui-card zaiui-price-view">
				<view class="cu-form-group text-black">
					<view class="title" style="padding-right:175px;left:-15px;">入住时间</view>
					<picker mode="date" :value="query.startdate" @change="StartDateChange">
						<view class="picker">{{ query.startdate }}</view>
					</picker>
				</view>
				<view class="cu-form-group text-black">
					<view class="title" style="padding-right:175px;left:-15px;">退房时间</view>
					<picker mode="date" :value="query.enddate" @change="EndDateChange">
						<view class="picker">{{ query.enddate }}</view>
					</picker>
				</view>

				<view class="cu-form-group text-black item-view" v-if="cashlist.length>0">
					<view class="title" style="padding-right:205px;left:-15px;">代金卷</view>
					<picker @change="PickerChange" :value="index" :range-key="'money'"  :range="cashlist">
						<view class="picker">
							{{cashlist[index].money}}
						</view>
					</picker>
				</view>
				
				<view class="text-black item-view">
					<view class="text-cut title">租房总额</view>
					<text class="text-red text-price text-right">{{houseprice}}</text>
				</view>
				
				<view class="text-black item-view">
					<view class="text-cut title">押金</view>
					<text class="text-black text-price text-right">{{houseinfo.price}}</text>
				</view>
			</view>
		</view>
		
		<view class="text-gray padding-sm">支付方式</view>
		
		<!--支付方式-->
		<view class="bg-white zaiui-pay-view">
			<radio-group class="block" @change="RadioChange">
				<view class="zaiui-pay-bar" @tap="payTap('wechat')">
					<view class="cu-avatar sm" style="background-image:url(/static/zaiui/img/wechat.png)"/>
					<view class="content">
						<view class="text-black">
							<text class="margin-right-sm">微信支付</text>
							<text class="cu-tag bg-red radius sm">推荐</text>
						</view>
						<view class="text-gray text-sm">亿万用户的选择，更快更安全</view>
					</view>
					<view class="action">
						<radio class="red zaiui-radio" :class="radio=='wechat'?'checked':''" :checked="radio=='wechat'?true:false" value="wechat"/>
					</view>
				</view>
				
				<view class="zaiui-pay-bar" @tap="payTap('alipay')">
					<view class="cu-avatar sm" style="background-image:url(/static/zaiui/img/alipay.png)"/>
					<view class="content">
						<view class="text-black">
							<text class="margin-right-sm">支付宝支付</text>
							<text class="cu-tag line-red radius sm">HOT</text>
						</view>
						<view class="text-gray text-sm">数亿用户都在用，安全可托付</view>
					</view>
					<view class="action">
						<radio class="red zaiui-radio" :class="radio=='alipay'?'checked':''" :checked="radio=='alipay'?true:false" value="alipay"/>
					</view>
				</view>
			</radio-group>
		</view>
		
		
		<!--占位底部距离-->
		<view class="cu-tabbar-height"/>
		
		<!--底部操作-->
		<view class="bg-white zaiui-footer-fixed zaiui-foot-padding-bottom">
			<view class="cu-bar padding-lr">
				<view class="text-black text-bold price-view">
					<text>合计：￥{{totalprice}}</text>
				</view>
				<view class="btn-view">
					<button class="cu-btn radius bg-red" @tap="payBtnTap">确认下单</button>
				</view>
			</view>
		</view>
		
	</view>
</template>

<script>
	import barTitle from '@/components/zaiui-common/basics/bar-title';
	import _tool from '@/static/zaiui/util/tools.js';	//工具函数
	import { housedetail,cash,postaddorder } from '@/api/homes/index.js';
	import { formateDate } from '@/global/utils/utils.js';
	
	export default {
		components: {
			barTitle,
		},
		data() {
			let today = formateDate(new Date(), 'Y-M');
			return {
				goodsList: [], checkAll: true, goods_img: '/static/images/home/goods/1.png',radio: 'wechat',
				pickerdata:['1个月','2个月','3个月','4个月','5个月','6个月','7个月','8个月','9个月','10个月','12个月','12个月'],
				bannerList: [],
				cashlist:[],
				detailID:"",
				houseinfo:"",
				userimg:"",
				houseimg:"",
				userinfo:{
					name:"",
					phone:""
				},
				query: {
					startdate: today,
					enddate: today,
				},
				index:0,
				houseprice:0,
				totalprice:0,
				yaprice:0,
				selmonth:0,
				token:"",
				money:0,
			}
		},
		onLoad() {
			this.token = uni.getStorageSync('token');
			this.userimg = uni.getStorageSync('headimg');
			this.detailID=this.$store.state.selshopid;
			console.log(this.detailID);
			this.getdata();
			this.getcash();
		},
		onReady() {
			_tool.setBarColor(true);
			uni.pageScrollTo({
			    scrollTop: 0,
			    duration: 0
			});
		},
		methods: {
			PickerChange(e) {
				this.index = e.detail.value
				console.log(e.detail.value);
				this.money=this.cashlist[this.index].money;
				this.totalprice-=this.money;
				// this.selmonth=e.detail.value;
				// this.houseprice*=(e.detail.value+1);
				// this.totalprice=this.houseprice+this.yaprice;
			},
			getdata(){
				var params={token:this.token,house_id:this.detailID};
				housedetail(params).then(res=>{
					if(res==undefined){
						this.getdata();
					}
					if(res.data.state==0){
						var item=res.data.data.houses;
						var banner={img:item.image};
						this.bannerList.push(banner)
						this.houseinfo=item;
						this.userinfo=item.user;
						this.houseimg=item.image;
						this.houseprice=item.price;
						this.yaprice=item.price;
						this.totalprice=item.price*2;
					}
				});
			},
			getcash(){
				var params={token:this.token};
				cash(params).then(res=>{
					if(res==undefined){
						this.getcash();
					}
					if(res.data.state==0){
						if(res.data.data!=null && res.data.data.length>0)
						{
							this.cashlist=res.data.data;
							this.money=this.cashlist[this.index].money;
							this.totalprice-=this.money;
						}else
							this.cashlist=[];
					}
				})
			},
			// payTap() {
			// 	this.$store.state.total_price=this.totalprice;
			// 	uni.navigateTo({
			// 		url: "/pages/goods/pay"
			// 	});
			// },
			RadioChange(e) {
				this.radio = e.detail.value;
			},
			payBtnTap() {
				this.houseprice-=this.money;
				var params={
					'token':this.token,
					'house_id':this.detailID,
					'enter_time':this.query.startdate,
					'exit_time':this.query.enddate,
					'hire_price':this.houseprice,
					'cash_price':this.yaprice,
					};
				postaddorder(params).then(res=>{
					console.log(res);
					if(res.data.state==0){
						uni.navigateTo({
							url: "/pages/status/pay_status"
						});
					}
				});
				
			},
			StartDateChange(e) {
				if (new Date(e.detail.value) < new Date(this.query.enddate)) {
					this.query.startdate = e.detail.value.substr(0,7);
					
					// this.getdatalist();
				} else {
					uni.showModal({
						title: '提示',
						content: '开始时间应小于结束时间',
						showCancel: false
					})
				}
				
			},
			EndDateChange(e) {
				var end_mon=e.detail.value.substr(5,2);
				var str_mon=this.query.startdate.substr(5,2);
				var res_mon=end_mon-str_mon;
				if (new Date(e.detail.value) > new Date(this.query.startdate)) {
					this.query.enddate = e.detail.value.substr(0,7);
					if(res_mon>0){
						this.selmonth=res_mon;
						this.houseprice*=res_mon;
						this.totalprice=this.houseprice+this.yaprice;
						console.log(this.selmonth);
					}else{
						uni.showModal({
							title: '提示',
							content: '至少选择一个月',
							showCancel: false
						})
					}
					// this.getdatalist();
				} else {
					uni.showModal({
						title: '提示',
						content: '结束时间应大于开始时间',
						showCancel: false
					})
				}
				
			},
			payTap(type) {
				this.radio = type;
			}
		}
	}
</script>

<style lang="scss">
	/* #ifdef APP-PLUS */
		@import "../../static/colorui/main.css";
		@import "../../static/colorui/icon.css";
		@import "../../static/zaiui/style/app.scss";
	/* #endif */
	@import "../../static/zaiui/style/settlement.scss";
	@import "../../static/zaiui/style/pay.scss";
	
	
</style>
