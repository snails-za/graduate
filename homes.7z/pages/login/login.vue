<template>
	<view class="content">
		<view class="logo"><image src="../../static/kitty-BasicLogin/logo.png" mode=""></image></view>
		<view class="uni-form-item uni-column">
			<input type="tel" v-model="phoneData" class="uni-input" name="" placeholder="请输入手机号" />
		</view>
		<view class="uni-form-item uni-column">
			<input type="password" v-model="passData" class="uni-input" name="" placeholder="请输入密码" />
		</view>
		<button type="primary" @click="go_login">登陆</button>
		<view class="links"><view @tap="gotoForgetPassword">忘记密码？</view><view>|</view><view class="link-highlight" @tap="gotoRegistration">注册账号</view></view>
	</view>
</template>

<script>
	import { userlogin } from '@/api/homes/index.js';
	
	export default {
		data() {
			return {
				phoneData: '', //用户/电话
				passData: '', //密码
			}
		},
		//页面初始加载
		mounted() {
			//缓存的账号
			const loginname = uni.getStorageSync('loginname');
			//缓存的密码
			const password = uni.getStorageSync('password');
			//有缓存就赋值给文本没有就清空
			if (loginname && password) {
				this.phoneData = loginname;
				this.passData = password;
			} else {
				this.phoneData = '';
				this.passData = '';
			}
		},
		methods: {
			go_login(){
				
				var that=this;
				if (this.phoneData.length == '') {
					uni.showToast({
						icon: 'none',
						position: 'bottom',
						title: '用户名不能为空'
					});
					return;
				}
				if (this.passData.length < 5) {
					uni.showToast({
						icon: 'none',
						position: 'bottom',
						title: '密码长度必须大于5位'
					});
					return;
				}   
				let params = { phone: that.phoneData, password: that.passData };
				userlogin(params).then(res => {
					console.log(res);
					if(res==undefined){
						this.go_login();
					}
					if (res.data.state==0) {
						uni.setStorageSync('token', res.data.token);
						uni.setStorageSync('headimg', res.data.head);
						uni.setStorageSync('loginname', that.phoneData);
						// uni.setStorageSync('password', that.passData);
						that.$store.state.userName = that.phoneData;
						that.$store.state.token = res.data.token;
						that.$store.state.hasLogin = res.data.state;
						
						uni.reLaunch({
							url: '../app/index'
						});
						
					} else {
						uni.showToast({
							icon: 'none',
							position: 'center',
							title: res.data.msg
						});
					}
				});
			},
			gotoRegistration: function () {
				uni.navigateTo({url: 'registration'});
			},
			gotoForgetPassword: function () {
				uni.navigateTo({url: 'forget-password'});
			}
		}
	}
</script>

<style lang="scss" scoped>
	$color-primary: #b49950;
	.content{
		padding: 100upx;
	}
	.logo{
	    text-align: center;
		image{
		    height: 200upx;
		    width: 200upx;
		    margin: 0 0 60upx;
		}
	}
	.uni-form-item{
		margin-bottom: 40upx;
		padding: 0;
		border-bottom: 1px solid #e3e3e3;
		.uni-input{
			font-size: 30upx;
			padding: 7px 0;
			height:27px;
		}
	}
	button[type="primary"]{
		background-color: $color-primary;
		border-radius: 0;
		font-size: 34upx;
		margin-top: 60upx;
	}
	.links{
		text-align: center;
		margin-top: 40upx;
		font-size: 26upx;
		color: #999;
		view{
			display: inline-block;
			vertical-align: top;
			margin: 0 10upx;
		}
		.link-highlight{
			color: $color-primary
		}
	}
</style>
