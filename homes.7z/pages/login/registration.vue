<template>
	<view class="content">
		<view class="logo"><image src="../../static/kitty-BasicLogin/logo.png" mode=""></image></view>
		<view class="uni-form-item uni-column">
			<input type="tel" v-model="nic" class="uni-input" name="" placeholder="请输入昵称" />
		</view>
		<view class="uni-form-item uni-column">
			<input type="tel" v-model="phoneData" class="uni-input" name="" placeholder="请输入手机号" />
		</view>
		
		<view class="uni-form-item uni-column column-with-btn">
			<input type="number" v-model="code" class="uni-input" name="" placeholder="请输入验证码" />
			<button :class="{active : !disableCodeBtn}" :disabled="disableCodeBtn" @click="sendCode">{{codeBtn.text}}</button>
		</view>
		<view class="uni-form-item uni-column">
			<input type="password" v-model="passData" class="uni-input" name="" placeholder="请输入密码" />
		</view>
		<button type="primary" @click="reg">注册</button>
		<view class="links">已有账号？<view class="link-highlight" @tap="gotoLogin">点此登陆</view></view>
	</view>
</template>

<script>
	import { userreg,sencode } from '@/api/homes/index.js';
	export default {
		data() {
			return {
				disableCodeBtn:false,
				havecode:false,
				nic: '', 
				phoneData: '', //用户/电话
				passData: '', //密码
				code:"",
				captchaImg: '',
				seconds: 60,
				codeBtn: {
					text: '获取验证码',
					waitingCode: false,
					count: this.seconds
				}
			}
		},
		onLoad() {
		},
		methods: {
			sendCode: function () {
				if(this.codeBtn.text=="重新发送" || this.codeBtn.text=="获取验证码"){
					if(this.phoneData=="" || this.phoneData==null){
						uni.showToast({
							icon: 'none',
							position: 'bottom',
							title: '请输入手机号'
						});
						return;
					}
					this.codeBtn.waitingCode = true;
					this.codeBtn.count = this.seconds;
					this.codeBtn.text = this.codeBtn.count + 's';
					
					let countdown = setInterval( () => {
						this.codeBtn.count--;
						this.codeBtn.text = this.codeBtn.count + 's';
						if( this.codeBtn.count < 0 ){
							clearInterval(countdown);
							this.codeBtn.text = '重新发送';
							this.codeBtn.waitingCode = false;
						}
					},1000);
					var params={phone:this.phoneData};
					sencode(params).then(res=>{
						if(res.data.state==0){
							uni.showToast({
								icon: 'none',
								position: 'bottom',
								title: res.data.msg
								
							});
							this.havecode=true;
						}else{
							uni.showToast({
								icon: 'none',
								position: 'bottom',
								title: res.data.msg,
								
							});
							this.havecode=false;
						}
					});
				}else{
					uni.showToast({
						icon: 'none',
						position: 'bottom',
						title: "请勿重复获取验证码",
						
					});
				}
				
			},
			gotoLogin: function () {
				uni.navigateTo({
					url: 'login'
				})
			},
			reg(){
				if(this.nic=="" ){
					uni.showToast({
						icon: 'none',
						position: 'bottom',
						title: '请输入昵称'
					});
					return;
				}
				
				if(this.phoneData=="" ){
					uni.showToast({
						icon: 'none',
						position: 'bottom',
						title: '请输入手机号'
					});
					return;
				}

				if(this.passData=="" ){
					uni.showToast({
						icon: 'none',
						position: 'bottom',
						title: '请输入密码'
					});
					return;
				}
				if(!this.havecode){
					uni.showToast({
						icon: 'none',
						position: 'bottom',
						title: '请先获取验证码'
					});
					return;
				}
				var params={phone:this.phoneData,code:this.code,password:this.passData,nickname:this.nic};
				userreg(params).then(res=>{
					console.log(res);
					if(res.data.state==0){
						uni.showToast({
							icon: 'none',
							position: 'bottom',
							title: res.data.msg
						});
						uni.navigateTo({
							url: 'login'
						})
					}else{
						uni.showToast({
							icon: 'none',
							position: 'bottom',
							title: res.data.msg
						});
					}
				})
			}
		},
		watch: {
			'codeBtn.text':{
				handler(newName, oldName) {
					  if(newName=="重新获取"){
						  
					  }
				    },
					deep: true,
					immediate: true
				
			}
		}
	}
</script>

<style lang="scss" scoped>
	$color-primary: #b49950;
	.content{
		padding: 60upx 100upx 100upx;
	}
	.logo{
	    text-align: center;
		image{
		    height: 200upx;
		    width: 200upx;
		    margin: 0 0 40upx;
		}
	}
	.uni-form-item{
		margin-bottom: 40upx;
		padding: 0;
		border-bottom: 1px solid #e3e3e3;
		.uni-input{
			font-size: 30upx;
			padding: 7px 0;
			height:27px;
		}
	}
	.column-with-btn{
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		align-items: center;
		button{
			font-size: 24upx;
			margin: 0;
			width: 180upx;
			text-align: center;
			&:after{
				border: none
			}
			&.active{
				background-color: $color-primary;
				color: $uni-text-color-inverse;
			}
		}
	}
	.img-captcha{
		width: 150upx;
		height: 60upx;
	}
	button[type="primary"]{
		background-color: $color-primary;
		border-radius: 0;
		font-size: 34upx;
		margin-top: 60upx;
	}
	.links{
		text-align: center;
		margin-top: 40upx;
		font-size: 26upx;
		color: #999;
		view{
			display: inline-block;
			vertical-align: top;
			margin: 0 10upx;
		}
		.link-highlight{
			color: $color-primary
		}
	}
</style>
