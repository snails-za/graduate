<template>
	<view>
		<!--标题栏-->
		<bar-title bgColor="bg-white" isBack>
			<block slot="content">个人资料</block>
		</bar-title>
		
		
		
		
		<!--设置列表  arrow-->
		<view class="cu-list menu sm-border margin-top">
			<view class="cu-item ">
				<view class="content">头像</view>
				<view class="action">
					<view class="cu-avatar round sm" :style="[{backgroundImage:'url('+ userinfo.img +')'}]"/>
				</view>
			</view>
			<view class="cu-item " @tap="editNameTap">
				<view class="content">名字</view>
				<view class="action">
					<text class="text-gray">{{userinfo.name}}</text>
				</view>
			</view>
			<view class="cu-item " >
				<view class="content">昵称</view>
				<view class="action">
					<text class="text-gray">{{userinfo.nickname}}</text>
				</view>
			</view>
			<view class="cu-item ">
				<view class="content">性别</view>
				<view class="action">
					<picker @change="sexPickerChange" :value="sexIndex" :range="sexPicker">
						<view class="picker text-gray">
							{{sexIndex>-1?sexPicker[sexIndex]:'男'}}
						</view>
					</picker>
				</view>
			</view>
			<!-- <view class="cu-item arrow">
				<view class="content">出生日期</view>
				<view class="action">
					<picker mode="date" :value="dateValue" start="1920-01-01" end="2020-05-01" @change="datePickerChange">
						<view class="picker text-gray">
							{{dateValue}}
						</view>
					</picker>
				</view>
			</view> -->
			<view class="cu-item " >
				<view class="content">身份证号</view>
				<view class="action">
					<text class="text-gray">{{userinfo.identity_number}}</text>
				</view>
			</view>
		</view>
		
		<view class="cu-list menu sm-border margin-top">
			<view class="cu-item " >
				<view class="content">手机号</view>
				<view class="action">
					<text class="text-gray">{{userinfo.phone}}</text>
				</view>
			</view>
		
		</view>
		
		
		
	</view>
</template>

<script>
	import barTitle from '@/components/zaiui-common/basics/bar-title';
	import _tool from '@/static/zaiui/util/tools.js';	//工具函数
	import { user_info } from '@/api/homes/index.js';
	
	export default {
		components: {
			barTitle
		},
		data() {
			return {
				avatar_img: '/static/images/avatar/1.jpg', sexIndex: 0, sexPicker: ['男', '女'], dateValue: '1945-10-01',
				userinfo:{},
			}
		},
		onLoad() {
			this.getuserinfo();
		},
		onReady() {
			_tool.setBarColor(true);
			uni.pageScrollTo({
			    scrollTop: 0,
			    duration: 0
			});
		},
		methods: {
			getuserinfo(){
				const token = uni.getStorageSync('token');
				var params={token:token};
				user_info(params).then(res=>{
					if(res.data.state==0){
						console.log(res.data.data);
						
						this.userinfo=res.data.data;
						if(res.data.data.sex=="男")
						this.sexIndex==0
						else
						this.sexIndex==1
					}
				});
			},
			editNameTap() {
				uni.navigateTo({
					url: "/pages/my/edit-name"
				});
			},
			sexPickerChange(e) {
				this.sexIndex = e.detail.value;
			},
			datePickerChange(e) {
				this.dateValue = e.detail.value;
			},
			
			
			editPhoneTap() {
				uni.navigateTo({
					url: "/pages/my/edit-phone"
				});
			},
			editContactCardsTap() {
				uni.navigateTo({
					url: "/pages/my/contact-cards"
				});
			},
			regionTap() {
				uni.navigateTo({
					url: "/pages/my/region"
				});
			},
		}
	}
</script>

<style lang="scss">
	/* #ifdef APP-PLUS */
		@import "../../static/colorui/main.css";
		@import "../../static/colorui/icon.css";
		@import "../../static/zaiui/style/app.scss";
	/* #endif */
	.zaiui-head-box {
		position: relative;
	    padding: 45.45rpx 90.9rpx;	
	}
	.zaiui-btn-view {
	    position: fixed;
	    width: 100%;
		bottom: 0;
		.flex {
			padding: 18.18rpx;	
		}
	}
</style>
