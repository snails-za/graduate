<template>
	<view>
		<!--标题栏-->
		<bar-title bgColor="bg-white" isBack>
			<block slot="content">我的代金卷</block>
		</bar-title>
		
		<!--红包Tab-->
		<scroll-view scroll-x class="bg-white nav z text-center">
			<block v-for="(item,index) in TabData" :key="index">
				<view class="cu-item" :class="index == TabCur?'select':''" @tap="tabSelect" :data-id="index">
					<view :class="index == TabCur?'text-black':''">{{item}}</view>
					<view class="tab-dot bg-red"/>
				</view>
			</block>
		</scroll-view>
		
		<!--红包列表-->
		<view class="zaiui-sponsored-card-view" v-for="(item,index) in cashlist">
			<view class="card-price-view">
				<view class="text-red price-left-view">
					<text class="text-sm">￥</text>
					<text class="price">{{item.money}}</text>
				</view>
				<view class="name-content-view">
					<view class="text-cut text-red">租房代金卷</view>
					<view class="text-xs">{{getdate(item.begin_time)}} - {{getdate(item.end_time)}}</view>
				</view>
				
			</view>
			<view class="card-num-view">
				<view class="text-xs"></view>
			</view>
		</view>

	</view>
</template>

<script>
	import barTitle from '@/components/zaiui-common/basics/bar-title';
	import _tool from '@/static/zaiui/util/tools.js';	//工具函数
	import { cash } from '@/api/homes/index.js';
	import { formateDate } from '@/global/utils/utils.js';
	
	export default {
		components: {
			barTitle
		},
		data() {
			return {
				TabCur: 0, TabData: ['未使用','已使用','已过期'],
				cashlist:[],
			}
		},
		onLoad() {
			this.getcash();
		},
		onReady() {
			_tool.setBarColor(true);
			uni.pageScrollTo({
			    scrollTop: 0,
			    duration: 0
			});
		},
		methods: {
			tabSelect(e) {
				this.TabCur = e.currentTarget.dataset.id;
				uni.pageScrollTo({
				    scrollTop: 0,
				    duration: 0
				});
			},
			getcash(){
				const token = uni.getStorageSync('token');
				var params={token:token};
				cash(params).then(res=>{
					if(res==undefined){
						this.getcash();
					}
					if(res.data.state==0){
						if(res.data.data!=null && res.data.data.length>0)
						{
							this.cashlist=res.data.data;
						}else
							this.cashlist=[];
					}
				})
			},
			getdate(time){
				return formateDate(new Date(time), 'Y-M-D h:min:s');
			}
		}
	}
</script>

<style lang="scss">
	/* #ifdef APP-PLUS */
		@import "../../static/colorui/main.css";
		@import "../../static/colorui/icon.css";
		@import "../../static/zaiui/style/app.scss";
	/* #endif */
	page {
		background: #FFFFFF;
	}
	.zaiui-sponsored-card-view {
		position: relative;
		margin: 27.27rpx 27.27rpx 0;
		.card-price-view {
		    position: relative;
		    background: #FFF5F5;
			border-radius: 14.54rpx 14.54rpx 0 0;	
		    padding: 18.18rpx;
			.price-left-view {
				position: absolute;
				height: 125.45rpx;
				width: 145.45rpx;
				text-align: center;
				line-height: 125.45rpx;
				.price {
				    font-size: 45.45rpx;
				    font-weight: 400;	
				}
			}
			.name-content-view {
				position: relative;
			    padding-left: 163.63rpx;
			    padding-right: 35px;
				height: 125.45rpx;
				line-height: 1.8;
				color: #999898;
				&::before {
					content: '';
					position: absolute;
					top: -18.18rpx;
					bottom: -18.18rpx;
					margin-left: -18.18rpx;
					border-left: 2rpx dashed #fdbabc;
				}
			}
			.btn-right-view {
				position: absolute;
			    right: 27.27rpx;
			    top: 18.18rpx;
				height: 125.45rpx;
				line-height: 125.45rpx;
			}
		}
		.card-num-view {
		    position: relative;
		    background: #FFECED;
		    border-radius: 0 0 14.54rpx 14.54rpx;
			border-top: 2rpx dashed #dedbdb;
		    padding: 10.9rpx 27.27rpx;
			color: #999898;
			&::before {
				content: '';
			    position: absolute;
			    width: 36.36rpx;
			    height: 36.36rpx;
			    background: #ffffff;
			    border-radius: 50%;
			    top: -18.18rpx;
			    left: -18.18rpx;
			}
			&::after {
			    content: '';
			    position: absolute;
			    width: 36.36rpx;
			    height: 36.36rpx;
			    background: #ffffff;
			    border-radius: 50%;
			    top: -18.18rpx;
			    right: -18.18rpx;
			}
			view {
				position: relative;
				padding-right: 72.72rpx;
			}
			text {
			    position: absolute;
			    right: 27.27rpx;
			    top: 14.54rpx;
			}
		}
	}
</style>
