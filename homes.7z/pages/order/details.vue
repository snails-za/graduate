<template>
	<view>
		<!--标题栏-->
		<bar-title bgColor="bg-white" >
			<block slot="content">订单详情</block>
		</bar-title>
		
		
		
		
		<!--状态图标-->
		<view class="bg-white padding solid-top text-center zaiui-status-img-view" v-if="basics == 4 && cancel">
			<view class="are-img-view" @tap="cancel = false">
				<image class="are-img" src="/static/zaiui/img/arg.png" mode="widthFix"/>
			</view>
			<view class="text-sm text-black">订单已取消</view>
		</view>
		
		
		<!--商品信息-->
		<view class="bg-white zaiui-card-box">
			<view class="zaiui-card-view zaiui-shop-view">
				<view class="shop-info-view">
					<view class="cu-avatar round sm" :style="[{backgroundImage:'url('+ userinfo.img +')'}]"/>
					<view class="text-black text-bold text-lg title-view">{{userinfo.name}}</view>
				</view>
				<view class="goods-list-view">
					<view class="cu-avatar radius" :style="[{backgroundImage:'url('+ houseinfo.image +')'}]"/>
					<view class="goods-info-view">
						<view class="text-black text-cut name">{{houseinfo.name}} </view>
						<view class="text-gray text-sm text-cut introduce">{{houseinfo.description}}</view>
						<view class="text-cut tag-view">
							<text class="cu-tag sm line-blue radius">{{houseinfo.type}}</text>
						</view>
						<view class="text-price text-red text-lg">{{houseinfo.price}}</view>
					</view>
				</view>
				
			</view>
		</view>
		
		<!--商品金额-->
		<view class="bg-white zaiui-card-box">
			<view class="zaiui-card-view zaiui-price-view">
				<view class="text-black title-view">
					<view class="title">总额</view>
					<view class="text-right">
						<text class="text-price">{{orderdetail.total}}</text>
					</view>
				</view>
				<view class="text-black title-view">
					<view class="title">押金</view>
					<view class="text-right">
						<text class="margin-right-xs">+</text>
						<text class="text-price">{{orderdetail.cash_price}}</text>
					</view>
				</view>
				<view class="text-black title-view">
					<view class="title">房租费</view>
					<view class="text-right">
						<text class="margin-right-xs">+</text>
						<text class="text-price">{{orderdetail.hire_price}}</text>
					</view>
				</view>
				<view class="text-black text-bold title-right-view">
					<text class="margin-right-xs">应付款：</text>
					<text class="text-price">{{orderdetail.total}}</text>
				</view>
				
				<view class="solid-line"></view>
				
			</view>
		</view>
		
		<!--订单信息-->
		<view class="bg-white zaiui-card-box">
			<view class="zaiui-card-view zaiui-order-view">
				<view class="text-lg text-bold text-black">订单信息</view>
				<view class="solid-line"></view>
				<view class="text-black title-view">
					<view class="title">订单编号</view>
					<view class="text-right">
						<text class="margin-right-xs">{{orderdetail.order_number}}</text>
						<!-- <button class="cu-btn sm line-black">复制</button> -->
					</view>
				</view>
				<view class="text-black title-view">
					<view class="title">支付方式</view>
					<view class="text-right">
						<text>支付宝（已支付）</text>
					</view>
				</view>
				<view class="text-black title-view">
					<view class="title">下单时间</view>
					<view class="text-right">
						<text>{{ordertime}}</text>
					</view>
				</view>
				
			</view>
		</view>
		
		<view class="bg-white zaiui-card-hight-box"/>
		
		
		
		<!--底部-->
		<view class="foot-hight-view"/>
		
		<view class="bg-white zaiui-footer-fixed zaiui-foot-padding-bottom" v-if="basics == 0">
			<!-- <button class="cu-btn line-black radius">取消订单</button>
			<button class="cu-btn bg-red">确认支付</button> -->
			<button class="cu-btn bg-red" @click="delorder">删除订单</button>
		</view>
		
	</view>
</template>

<script>
	import barTitle from '@/components/zaiui-common/basics/bar-title';
	import _tool from '@/static/zaiui/util/tools.js';	//工具函数
	
	import { housedetail,cash,get_order,postdelorder } from '@/api/homes/index.js';
	import { formateDate } from '@/global/utils/utils.js';
	export default {
		components: {
			barTitle
		},
		data() {
			return {
				basics: 0, bg_img: '/static/images/home/goods/1.png', avatar: '/static/images/avatar/1.jpg', cancel: false,
				bottomModal: false, codeKey: [], btnKey: true,
				token:"",
				userimg:"",
				houseimg:"",
				detailID:"",
				orderid:"",
				houseprice:"",
				totalprice:"",
				houseinfo:{},
				userinfo:{},
				orderdetail:{},
				ordertime:""
			}
		},
		onLoad() {
			this.token = uni.getStorageSync('token');
			this.userimg = uni.getStorageSync('headimg');
			this.detailID=this.$store.state.selshopid;
			this.orderid=this.$store.state.orderid;
			this.getdata();
			this.getorderlist();
		},
		onReady() {
			_tool.setBarColor(true);
			uni.pageScrollTo({
			    scrollTop: 0,
			    duration: 0
			});
		},
		methods: {
			getdata(){
				var params={token:this.token,house_id:this.detailID};
				housedetail(params).then(res=>{
					// console.log(res);
					if(res.data.state==0){
						var item=res.data.data.houses;
						this.houseinfo=item;
						this.userinfo=item.user;
						this.houseimg=item.image;
						this.houseprice=item.price;
						this.totalprice=item.price*2;
					}
				});
			},
			getorderlist(){
				var params={token:this.token,status:2};
				get_order(params).then(res=>{
					if(res.data.state==0){
						res.data.order.forEach(item=>{
							if(item.order_id==this.orderid){
								this.orderdetail=item;
								this.getdate(item.publish_time)
							}
						})
					}
				});
			},
			delorder(){
				var params={token:this.token,order_number:this.orderdetail.order_number};
				postdelorder(params).then(res=>{
					if(res.data.state==0){
						uni.showModal({
							title: '提示',
							content: res.data.msg,
							showCancel: false
						})
						uni.navigateTo({
							url: "/pages/order/list"
						});
					}
				});
			},
			getdate(time){
				if(time!=null)
				{
					var ordertime=formateDate(time, 'Y-M')
					this.ordertime=ordertime;
				}
			},
			closeModalTap () {
				this.bottomModal = false;
			},
			codeKeyTap (index) {
				if(this.codeKey.length < 4) {
					this.codeKey.push(index);
				}
			},
			codeKeyDelTap() {
				this.codeKey.pop();
			},
			getCodeKey() {
				this.btnKey = false;
			},
			appraiseTap() {
				uni.navigateTo({
					url: "/pages/order/appraise"
				});
			}
		}
	}
</script>

<style lang="scss">
	/* #ifdef APP-PLUS */
		@import "../../static/colorui/main.css";
		@import "../../static/colorui/icon.css";
		@import "../../static/zaiui/style/app.scss";
	/* #endif */
	@import "../../static/zaiui/style/order-details.scss";
</style>
