<template>
	<view>
		<!--标题栏-->
		<!-- <bar-title bgColor='bg-white' @rightTap="barEditTap">
			<block slot="content">我的订单</block>
		</bar-title> -->
		<cu-custom bgColor="bg-gradual-blue"  :isBack="true" tourl="/pages/app/index4">
			<block slot="backText">返回</block>
			<block slot="content">我的订单</block>
		</cu-custom>
		<!--tab列表-->
		<!-- <view class="bg-white zaiui-nav-tab-view">
			<scroll-view scroll-x class="nav z" scroll-with-animation :scroll-left="tab_scroll">
				<block v-for="(item,index) in nav_list" :key="index">
					<view class="cu-item" :class="index == tab_cur?'select':''" @tap="tabSelect" :data-id="index">
						<view :class="index == tab_cur?'text-black':''">{{item}}</view>
						<view class="tab-dot bg-red"/>
					</view>
				</block>
			</scroll-view>
		</view> -->
		
		<!--订单列表-->
		<block v-for="(item,index) in order_list" :key="index" v-if="tab_cur == 0">
			<view class="bg-white zaiui-order-tab-view" >
				<!--店铺名称-->
				<view class="shop-title-view">
					<view class="cu-avatar sm round" :style="[{backgroundImage:'url('+ userimg +')'}]"/>
					<view class="text-black text-cut shop-name">{{username}}</view>
					<text class="text-right text-gray text-sm">{{getorderstate(item.order_status)}}</text>
				</view>
				<!--商品列表-->
				<block>
					<view class="goods-list-view">
						<view class="cu-avatar lg radius" :style="[{backgroundImage:'url('+ item.image +')'}]"/>
						<view class="goods-info-view">
							<view class="text-black text-cut name">{{item.name}}</view>
							<view class="text-gray text-sm text-cut introduce">{{item.description}}</view>
							<view class="text-cut tag-view">
								<block >
									<text class="cu-tag sm line-blue radius">{{item.type}}</text>
								</block>
							</view>
						</view>
					</view>
				</block>
				<!--统计-->
				<view class="statistics-view">
					<view class="text-black text-sm text-right">
						<text>共1件</text>
						<text v-if="item.order_status == 1">商品 实付款：</text>
						<text v-if="item.order_status == 0">商品 应付款：</text>
						<text class="text-price text-lg">{{item.total}}</text>
					</view>
				</view>
				<!--按钮-->
				<view class="zaiui-btn-view" >
					<button class="cu-btn line-black sm radius" @tap="whereaboutsTap(item,index)">查看订单详情</button>
				</view>
				
			</view>
		</block>
		
		<!--无数据-->
		<view class="bg-white zaiui-null-view" v-if="tab_cur != 0">
			<view class="img-view">
				<view class="cu-avatar lg round" style="background-image:url('/static/zaiui/img/aa6.png')"/>
			</view>
			<view class="text-sm margin-top-sm">您还没有相关订单哦</view>
		</view>
		
		
		<!--到底了-->
		<view class="zaiui-foot-tip-view" v-if="tab_cur == 0">
			
			<view class="text-gray">hi,到底啦~</view>
		</view>
		
		<!--小程序端显示-->
		<!-- #ifdef MP -->
			<!--编辑-->
			<view class="zaiui-add-btn-view-box" @tap="barEditTap">
				<button class="cu-btn cuIcon-check bg-red" v-if="goods_checked"></button>
				<button class="cu-btn cuIcon-write bg-red" v-else></button>
			</view>
		<!-- #endif -->
	</view>
</template>

<script>
	import barTitle from '@/components/zaiui-common/basics/bar-title';
	
	import _tool from '@/static/zaiui/util/tools.js';
	import { get_order } from '@/api/homes/index.js';
	
	export default {
		components: {
			barTitle,
		},
		data() {
			return {
				sort_grid_data: [], nav_list: [], tab_cur: 0, tab_scroll: 0, order_list: [], goods_checked: false,
				userimg:"",username:""
			}
		},
		created() {
			this.userimg = uni.getStorageSync('headimg');
			this.username=uni.getStorageSync('username');
			this.getorderlist();
			
		},
		onReady() {
			_tool.setBarColor(true);
			uni.pageScrollTo({
			    scrollTop: 0,
			    duration: 0
			});
		},
		methods: {
			
			getorderlist(){
				const token = uni.getStorageSync('token');
				var params={token:token,status:2};
				get_order(params).then(res=>{
					if(res==undefined){
						this.getorderlist();
					}
					if(res.data.state==0){
						this.order_list=res.data.order;
						console.log(res);
					}
				});
			},
			getorderstate(id){
				var str="";
				if(id==0){
					str="交易成功";
				}else{
					str="等待付款";
				}
				return str;
			},
			tabSelect(e) {
				let index = e.currentTarget.dataset.id;
				this.tab_cur = index;
				this.tab_scroll = (index - 1) * 60;
				uni.pageScrollTo({
				    scrollTop: 0,
				    duration: 0
				});
			},
			barEditTap() {
				if (this.goods_checked) {
					this.goods_checked = false;
				} else {
					this.goods_checked = true;
				}
			},
			whereaboutsTap(data,index) {
				console.log(data);
				this.$store.state.selshopid = data.house_id;
				this.$store.state.orderid = data.order_id;
				this.$store.state.houseimg = data.image;
				
				uni.navigateTo({
					url: "/pages/order/details"
				});
			},
			
			
		}
	}
</script>

<style lang="scss">
	/* #ifdef APP-PLUS */
		@import "../../static/colorui/main.css";
		@import "../../static/colorui/icon.css";
		@import "../../static/zaiui/style/app.scss";
	/* #endif */
	@import "../../static/zaiui/style/order-list.scss";
</style>
