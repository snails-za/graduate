<template>
	<view>
		<!--标题栏-->
		<bar-title bgColor='bg-white' :isBack="false">
			
			<block slot="content">{{title}}</block>
		</bar-title>
		
		<!--状态图标-->
		<view class="zaiui-status-view">
			<image class="status-img" src="/static/zaiui/img/pay.png" mode="widthFix"/>
			<view class="bg-red status-bg-view">
				<text class="cuIcon-check icon"></text>
			</view>
		</view>
		
		<!--状态标题-->
		<view class="text-bold text-black text-xl text-center">{{title}}</view>
		
		<!--状态说明-->
		<view class="text-gray text-sm text-center zaiui-padding"> {{introduce}} </view>
		
		<!--按钮-->
		<view class="zaiui-btn-view">
			<button class="cu-btn radius line-red" @click="gohome">返回首页</button>
		</view>
		
		
		
	</view>
</template>

<script>
	//各种状态显示内容，可自行修改或判断法显示，这里我就不一一写出来了。
	
	import barTitle from '@/components/zaiui-common/basics/bar-title';
	import _tool from '@/static/zaiui/util/tools.js';
	export default {
		components: {
			barTitle,
		},
		data() {
			return {
				title: '支付成功', introduce: '请注意资金安全，请注意资金安全请注意资金安全请注意资金安全请注意资金安全！。',
			}
		},
		onLoad() {
			
		},
		onReady() {
			_tool.setBarColor(true);
			uni.pageScrollTo({
			    scrollTop: 0,
			    duration: 0
			});
		},
		methods: {
			setupTap(){
				uni.navigateTo({
					url: "/pages/app/index"
				});
			},
			gohome(){
				uni.navigateTo({
					url: "/pages/app/index"
				});
			}
		}
	}
</script>

<style lang="scss">
	/* #ifdef APP-PLUS */
		@import "../../static/colorui/main.css";
		@import "../../static/colorui/icon.css";
		@import "../../static/zaiui/style/app.scss";
	/* #endif */
	@import "../../static/zaiui/style/pay-status.scss";
</style>
