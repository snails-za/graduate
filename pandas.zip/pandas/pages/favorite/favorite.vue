<template>
	<view>
		<view class="house-list">
			<scroll-view scroll-y="true">
				<view class="house-item" v-for="(item, index) in favList" :key="index" @tap="openinfo" :data-houseid="item.house.house_id">
					<view class="house-info">
						<!-- 图片 -->
						<image class="house_picture" :src="item.house.image" mode="widthFix"></image>
						<!-- 房屋详细信息 -->
						<view class="house-detail">
							<!-- 标题 -->
							<view class="title">
								<text>{{item.house.name}}</text>
							</view>
							<!-- 地点 -->
							<view class="address">
								<text>{{item.house.address}}</text>									
							</view>
							<!-- 面积 -->
							<view class="area">
								<text>{{item.house.area}}平方米</text>									
							</view>
							<!-- <!-- 价格 -->
							<view>
								<text class="price">￥{{item.house.price}}</text>
								/月
							</view>
							<!-- <button class="fav" :data-houseid="item.house.house_id">取消收藏</button> -->
						</view>
						<!-- 分割线 -->
						<view style="width: 100%;height: 10rpx;background-color: #D9D9D9;border-radius: 5rpx;"></view>
					</view>

				</view>
			</scroll-view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				favList: []
			}
		},
		onLoad() {
			this.getData()
		},
		methods: {
			getData(){
				// console.log(getApp().globalData.globalToken)
				let that = this
				uni.request({
					url: 'http://localhost:5000/api/get_collection/?token=' + getApp().globalData.globalToken,
					method: 'GET',
					data: {},
					success: res => {
						that.favList = res.data.data
						console.log(that.favList)
					},
					fail: () => {},
					complete: () => {}
				});
			},
			openinfo(e){
				var houseid = e.currentTarget.dataset.houseid;
				console.log(houseid)
				uni.navigateTo({
					url: '../info/info?houseid=' + houseid
				});
			}
		}
	}
</script>

<style>
	/* 房源信息列表 */
	.house-list{
	  margin-top: 30rpx;
	}
	.house-item{
		width: 700rpx;
		margin-top: 15rpx;
		margin-left: 20rpx;
		border-radius: 20rpx;
	}
	.active{
		background-color: #D8D8D8;
	}
	.house-info{
		display: flex;
		flex-wrap: wrap;
		justify-content: space-around;
	}
	.house_picture{
		width: 400rpx;
		height: 260rpx;
		border-radius: 20rpx;
	}
	.house-detail{
	font-size: 30rpx;
	display: -webkit-box;
	overflow: hidden;
	text-overflow: ellipsis;
	word-wrap: break-word;
	-webkit-line-clamp: 2;
	-webkit-box-orient: vertical;
	width: 200rpx;
	}
	.title{
		font-weight: bold;
		font-size: 30rpx;
	}
	.price{
		color: #FF3333;
	}
</style>
