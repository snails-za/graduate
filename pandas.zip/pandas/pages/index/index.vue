<template>
        <view class="main">
			<!-- 轮播图 -->
			<view class="slides">
				<swiper class="swiper" indicator-dots autoplay circular :interval="2000" duration="500">
					<swiper-item v-for="(item, index) in adList" :key="index" @tap="openinfo" :data-houseid="item.house.house_id">
						<view class="swiper-img">
						  <image :src="item.house.image" mode="widthFix"></image>
						</view>
					</swiper-item>
				</swiper>
			</view>
			<!-- 搜索框 -->
			<view class="search">
				<view class="city">
					<picker @change="bindPickerChange" :value="index" :range="array">
						<view class="uni-input">{{array[index]}}</view>
					</picker>
				</view>
				<view class="input">
					<input class="search_input" placeholder="户型/地址"></input>
				</view>
			</view>
			<button type="default">搜索房源</button>
			<!-- 房源信息 -->
			<view class="house-list">
				<scroll-view scroll-y="true">
					<view class="house-item" v-for="(item, index) in houseList" :key="index" hover-class="active" @tap="openinfo" :data-houseid="item.house_id">
						<view class="house-info" v-if="item.verify_status===1">
							<!-- 图片 -->
							<image class="house_picture" :src="item.image" mode="widthFix"></image>
							<!-- 房屋详细信息 -->
							<view class="house-detail">
								<!-- 标题 -->
								<view class="title">
									<text>{{item.name}}</text>
								</view>
								<!-- 地点 -->
								<view class="address">
									<text>{{item.address}}</text>									
								</view>
								<!-- 面积 -->
								<view class="area">
									<text>{{item.area}}平方米</text>									
								</view>
								<!-- <!-- 价格 -->
								<view>
									<text class="price">￥{{item.price}}</text>
									/月
								</view>
							</view>
							<!-- 分割线 -->
							<view style="width: 100%;height: 10rpx;background-color: #D9D9D9;border-radius: 5rpx;" v-if="item.verify_status===1"></view>
						</view>
	
					</view>
				</scroll-view>
			</view>
		</view>
</template>

<script>
	export default {
		components: {
		},
		data() {
			return {
				adList: [],
				houseList: [],
				array: ['北京', '上海', '广州', '深圳'],
				index: 0,
				token: getApp().globalData.globalToken
			}
		},
		onLoad() {
			this.getData()
		},
		methods: {
			bindPickerChange: function(e) {
			            console.log('picker发送选择改变，携带值为', e.target.value)
			            this.index = e.target.value
			        },
			getData(){
				this.getSwiperData()
			},
			getSwiperData(){
				let self = this
				uni.request({
					url: 'http://localhost:5000/api/slide/',
					method: 'GET',
					data: {},
					success: res => {
						if(res.data.state===0){
							self.adList=res.data.data
							console.log(res.data.data)
							self.getHouseData()
						}
					},
					fail: () => {this.getSwiperData()},
					complete: () => {console.log("轮播图获取成功")}
				});
				
			},
			getHouseData(){
				let that = this
				uni.request({
					url: 'http://localhost:5000/api/list_all_houses/',
					method: 'GET',
					data: {},
					success: res => {
						if(res.data.state==0){
							that.houseList=res.data.data
							console.log(res)
						}
					},
					fail: () => {this.getHouseData()},
					complete: () => {console.log('房屋信息获取成功！')}
				});
			},
			openinfo(e){
				var houseid = e.currentTarget.dataset.houseid;
				console.log(houseid)
				uni.navigateTo({
					url: '../info/info?houseid=' + houseid
				});
			}

		}
	}
</script>

<style>
	/* 轮播图 */
	.slides{
	  margin-top: 10rpx
	}
	.slides swiper{
	  height: 320rpx;
	}
	.slides .swiper-img{
	  width: 96%;
	  height: 98%;
	  margin: 1% 1% 2% 2%;
	}
	.slides image{
	  width: 100%;  
	  height: 100%;
	  border-radius: 20rpx;
	}
	/* 搜索 */
	.search{
		display: flex;
		width: 700rpx;
		margin: 20rpx auto;
		border-radius: 20rpx;
		border-bottom: solid;
		border-bottom-color: #C0C0C0;
		justify-content: space-between;
		align-items: center;
		overflow: hidden;
		text-overflow: ellipsis;
		word-wrap: break-word;
		-webkit-line-clamp: 2;
		-webkit-box-orient: vertical;
	}
	.city{
		font-size: 500rpx;
		font-weight: bold;
		color: #D8D8D8;
		width: 150rpx;
		border-right: solid;
		border-right-color: #BEBEBE;
	}
	.input{
		border: #D8D8D8;
		border-radius: 10rpx;
	}
	.search_input{
		  padding-left: 10rpx;
	}
	button{
			width: 70%;
			height: 10%;
			background-color: #000000;
			color: #fff;
	}
	/* 房源信息列表 */
	.house-list{
	  margin-top: 30rpx;
	}
	.house-item{
		width: 700rpx;
		margin-top: 15rpx;
		margin-left: 20rpx;
		border-radius: 20rpx;
	}
	.active{
		background-color: #D8D8D8;
	}
	.house-info{
		display: flex;
		flex-wrap: wrap;
		justify-content: space-around;
	}
	.house_picture{
		width: 400rpx;
		height: 260rpx;
		border-radius: 20rpx;
	}
	.house-detail{
	font-size: 30rpx;
	display: -webkit-box;
	overflow: hidden;
	text-overflow: ellipsis;
	word-wrap: break-word;
	-webkit-line-clamp: 2;
	-webkit-box-orient: vertical;
	width: 200rpx;
	}
	.title{
		font-weight: bold;
		font-size: 30rpx;
	}
	.price{
		color: #FF3333;
	}
</style>

