<template>
	<!-- 房屋详情 -->
	<view class="info">
		<!-- 图片 -->
		<image :src="house_detail.houses.image" mode="widthFix"></image>
		<view class="info_head">
			<view class="title">
				<text>{{house_detail.houses.name}} - </text>
			</view>
			<view class="type">
				<text>{{house_detail.houses.type}}</text>
			</view>

		</view>
		<view class="info_content">
			<text>{{house_detail.houses.address}}</text>
			<text class="g">|</text>
			<text>{{house_detail.houses.area}}平方米</text>
			<text class="g">|</text>
			<text>{{house_detail.houses.description}}</text>
		</view>
		<text class="price">{{house_detail.houses.price}}/平方</text>
		<button class="pre">预定</button>
		<button class="fav" @click="addFav" :data-houseid="house_id">收藏</button>
	</view>
</template>
<script>
	export default {
		data(){
			return {
				house_id: null,
				house_detail: "",
				token: ""
			}
		},
		onLoad(e) {
			this.getDetail(e)
		},
		methods: {
			getDetail(e){
				let that = this
				// console.log(e.houseid)
				uni.request({
					url: 'http://localhost:5000/api/detail/?' +'house_id=' + e.houseid,
					method: 'GET',
					data: {},
					success: res => {
						that.house_detail=res.data.data
						that.house_id = e.house_id
					},
					fail() {
						that.getDetail(e)
					}
				});
			},
			addFav(e){
				let that = this
				that.token = getApp().globalData.globaltoken
				if(that.token){
					that.addData()
				}
				
			},
			addData(){
				let houseid = e.currentTarget.dataset.houseid;
				let that = this
				uni.request({
					url: 'http://localhost:5000/api/insert_collection/',
					method: 'POST',
					data: {
						house_id: houseid,
						token: that.token,
						},
					success: res => {
						if(that.token){
							console.log("+++++")
						}
						console.log(res)
					},
					fail: () => {},
					complete: () => {}
				});
			}
		}
	}
</script>

<style>
	.info{
		width: 700rpx;
		/* border: solid; */
		margin: 5rpx auto;
		border-radius: 20rpx;
		line-height: 100rpx;
	}
	image{
		border-radius: 20rpx;
		width: 700rpx;
		/* margin-left: 10rpx; */
	}
	.info_head{
		margin-top: 8rpx;
		display: flex;
		align-items: center;
		font-style: initial;
	}
	.title{
		font-size: 60rpx;
		font-weight: bold;
	}
	.type{
		font-size: 55rpx;
		font-weight: bold;
	}
	.info_content{
		display: flex;
		font-size: 35rpx;
		font-weight: bolder;
		color: #F0AD4E;
	}
	.g{
		font-weight: 0;
		color: #000000;
	}
	.price{
		color: #FF3333;
		font-weight: bold;
		font-size: 40rpx;
		font-style: normal;
	}
	.pre{
		width: 150rpx;
		background-color: #09BB07;
		margin-right: 20rpx;
		font-size: 30rpx;
	}
</style>
