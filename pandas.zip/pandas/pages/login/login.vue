<template>
    <view>
        <view>
            <form @submit="formSubmit" @reset="formReset" class="uni-form">
                <view class="uni-form-item">
                    <view class="title">用户名</view>
                    <input class="uni-input" name="username" placeholder="请输入用户名" />
                </view>
				<view class="uni-form-item">
				    <view class="title">密码</view>
				    <input class="uni-input" name="password" placeholder="请输入密码" />
				</view>
                <view class="uni-btn-v">
                    <button form-type="submit">登录</button>
                    <button type="default" form-type="reset">注册</button>
                </view>
            </form>
        </view>
    </view>
</template>
<script>
    export default {
        data() {
            return {
				
            }
        },
        methods: {
            formSubmit: function(e) {
                // console.log('form发生了submit事件，携带数据为：' + JSON.stringify(e.detail.value))
                let formdata = e.detail.value
                uni.showModal({
                    content: '表单数据内容：' + JSON.stringify(formdata),
                    showCancel: false
                });
				uni.request({
					url: 'http://localhost:5000/api/login/',
					method: 'POST',
					data: {
						nickname: formdata.username,
						password: formdata.password
					},
					success: res => {
						// console.log(res)
						if(res.data.state === 0){
							getApp().globalData.globalToken = res.data.token
							getApp().globalData.globalHead = res.data.head
							uni.switchTab({
								url:"../mine/mine"
							})
						}
					},
					fail: () => {},
					complete: () => {}
				});
            },
            formReset: function(e) {
                console.log('清空数据')
            }
        }
    }
</script>

<style>
	.uni-form {
		width: 80%;
		margin-top: 100rpx;
		margin-left: 20rpx;
	}
    .uni-form-item {
		display: flex;
    }
	.title{
		justify-content: space-between;
	}
	.uni-input {
		border: dashed;
	}
</style>

