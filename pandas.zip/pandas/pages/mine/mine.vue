<template>
	<view class="mine">
		<!-- 登录注册 -->
		 <view class="top">
			 <image :src="head"></image>
			 <view class="top-text">
				 <navigator hover-class="active">登录/注册</navigator>
			 </view>
		 </view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				head: "../../static/head/default.jpg"
			}
		},
		methods: {
			
		}
	}
</script>

<style>
	.mine{
		width: 700rpx;
		border: solid;
		margin: 20rpx auto;
	}
	.top{
		display: flex;
	}
	image{
		width: 140rpx;
		height: 140rpx;
		border-radius: 50%;
		margin-left: 20rpx;
	}
	.top-text{
		margin: 10rpx 40rpx;
		font-size: 30rpx;
	}
	.active{
		background-color: #FFFFFF;
		color: #FF3333;
	}
</style>
