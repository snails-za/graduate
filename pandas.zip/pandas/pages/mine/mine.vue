<template>
	<view class="mine">
		 <view class="top">
			 <image :src="head"></image>
			 <view class="top-text">
				 <!-- 登录注册 -->
				 <navigator class="login" hover-class="active" url="../login/login">登录</navigator>
				<!-- 成为房东 -->
				 <navigator class="member" hover-class="active" url="../member/member">进行实名认证</navigator>
			 </view>
		 </view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				token: "",
				head: ""
			}
		},
		onLoad() {
			this.head = getApp().globalData.globalHead
		},
		methods: {
			
		}
	}
</script>

<style>
	.mine{
		width: 700rpx;
		border: solid;
		margin: 20rpx auto;
	}
	.top{
		display: flex;
	}
	image{
		width: 140rpx;
		height: 140rpx;
		border-radius: 50%;
		margin-left: 20rpx;
	}
	.top-text{
		display: flex;
		width: 500rpx;
		margin: 10rpx 40rpx;
		font-size: 30rpx;
		justify-content: space-between;
	}
	.active{
		background-color: #FFFFFF;
		color: #FF3333;
	}
	.member{
		align-self: flex-end;
	}
</style>
